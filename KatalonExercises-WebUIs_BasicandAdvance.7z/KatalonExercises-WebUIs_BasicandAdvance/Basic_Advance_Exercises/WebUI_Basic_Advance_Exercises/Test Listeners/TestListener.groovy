import com.kms.katalon.core.annotation.AfterTestCase
import com.kms.katalon.core.annotation.BeforeTestCase
import com.kms.katalon.core.context.TestCaseContext
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.driver.WebUIDriverType
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import general_utilities.CommonLib as CommonLib
import general_utilities.Specified_utilities as Specified_utilities
import internal.GlobalVariable as GlobalVariable


class TestListener {
	@BeforeTestCase
	def BeforeTestCase(TestCaseContext testCaseContext) {
			'Open browser'
			WebUI.openBrowser('')
	}


	@AfterTestCase
	def AfterTestCase(TestCaseContext testCaseContext) {
		def var_TCID = testCaseContext.getTestCaseId()
		
		if (var_TCID.contains('BE')){
			if ((!var_TCID.contains('BE-01')) && (!var_TCID.contains('BE-02'))) {				
				
				'Setting Hotel Modules is enable by clicking the Module --> Hotel -->Disable'
				CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Modules', GlobalVariable.gl_objectWait)
				CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_PrimaryModules/btn_HotelModules_Enable', GlobalVariable.gl_objectWait)
				CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_PrimaryModules/Confirm_Dlg/btn_Yes', GlobalVariable.gl_objectWait)
				WebUI.delay(GlobalVariable.gl_objectWait2)
			}
		}		
		
		'Close browser'
		WebUI.closeBrowser()
	}
}