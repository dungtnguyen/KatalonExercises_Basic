import com.kms.katalon.core.annotation.AfterTestCase
import com.kms.katalon.core.annotation.BeforeTestCase
import com.kms.katalon.core.context.TestCaseContext
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.driver.WebUIDriverType
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

class TestListener {
	@BeforeTestCase
	def BeforeTestCase(TestCaseContext testCaseContext) {
			'Open browser'
			WebUI.openBrowser('')
	}


	@AfterTestCase
	def AfterTestCase(TestCaseContext testCaseContext) {
		'Close browser'
		//WebUI.closeBrowser()
	}
}