<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_FileUpload</name>
   <tag></tag>
   <elementGuidId>311f6704-d8aa-44fa-a60a-6fecbc910bb6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/ul/li[6]/a</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(@href, '/upload')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(@href, '/upload')]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <value>//a[contains(@href, '/checkboxes')]</value>
   </webElementXpaths>
</WebElementEntity>
