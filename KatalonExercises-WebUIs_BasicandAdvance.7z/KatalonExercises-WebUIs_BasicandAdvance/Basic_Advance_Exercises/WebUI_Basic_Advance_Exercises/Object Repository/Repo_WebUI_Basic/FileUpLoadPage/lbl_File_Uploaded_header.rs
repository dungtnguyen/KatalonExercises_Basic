<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_File_Uploaded_header</name>
   <tag></tag>
   <elementGuidId>5f9302fa-0c9e-4119-9f71-24d0f88a7441</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='checkboxes']/input[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[text()='File Uploaded!']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[text()='File Uploaded!']</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <value>//form[@id='checkboxes']/input[1]</value>
   </webElementXpaths>
</WebElementEntity>
