<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_Shopping_and_Fashion</name>
   <tag></tag>
   <elementGuidId>a53b7e9d-cf08-4b7f-9a9b-9a56cf14d7df</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(@href, 'www.phptravels.net/blog/category?cat=Shopping-and-Fashion')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(@href, 'www.phptravels.net/blog/category?cat=Shopping-and-Fashion')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(@href, 'www.phptravels.net/blog/category?cat=Shopping-and-Fashion')]</value>
   </webElementProperties>
</WebElementEntity>
