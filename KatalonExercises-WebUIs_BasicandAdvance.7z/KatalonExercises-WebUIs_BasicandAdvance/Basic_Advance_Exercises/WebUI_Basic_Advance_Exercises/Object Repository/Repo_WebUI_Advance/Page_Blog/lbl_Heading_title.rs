<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Heading_title</name>
   <tag></tag>
   <elementGuidId>9d117d94-2b78-4dfb-bf31-b234f17970f5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class='panel-heading title_rtl']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='panel-heading title_rtl']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='panel-heading title_rtl']</value>
   </webElementProperties>
</WebElementEntity>
