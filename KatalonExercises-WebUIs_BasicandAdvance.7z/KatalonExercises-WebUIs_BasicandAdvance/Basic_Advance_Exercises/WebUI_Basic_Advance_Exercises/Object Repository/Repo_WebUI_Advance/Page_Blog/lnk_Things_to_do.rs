<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_Things_to_do</name>
   <tag></tag>
   <elementGuidId>24ae3032-fc03-4077-9631-4552901bb93f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(@href, 'www.phptravels.net/blog/category?cat=Things-to-do')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(@href, 'www.phptravels.net/blog/category?cat=Things-to-do')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(@href, 'www.phptravels.net/blog/category?cat=Things-to-do')]</value>
   </webElementProperties>
</WebElementEntity>
