<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Total_of_ThingstoDo</name>
   <tag></tag>
   <elementGuidId>965dc2d9-2527-49cc-a8e3-8d8629bcfc47</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='list-group']/div[@class='panel panel-default']/a[@href]/span[@class='go-left badge badge-primary'])[4]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@class='list-group']/div[@class='panel panel-default']/a[@href]/span[@class='go-left badge badge-primary'])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='list-group']/div[@class='panel panel-default']/a[@href]/span[@class='go-left badge badge-primary'])[4]</value>
   </webElementProperties>
</WebElementEntity>
