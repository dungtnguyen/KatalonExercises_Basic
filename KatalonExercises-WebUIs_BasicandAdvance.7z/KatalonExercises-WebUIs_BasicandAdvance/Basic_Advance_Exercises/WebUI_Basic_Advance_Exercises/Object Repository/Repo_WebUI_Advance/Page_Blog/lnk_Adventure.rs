<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_Adventure</name>
   <tag></tag>
   <elementGuidId>9862ea63-aa20-49e1-af82-e5f67ea68292</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(@href, 'www.phptravels.net/blog/category?cat=Adventure')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(@href, 'www.phptravels.net/blog/category?cat=Adventure')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(@href, 'www.phptravels.net/blog/category?cat=Adventure')]</value>
   </webElementProperties>
</WebElementEntity>
