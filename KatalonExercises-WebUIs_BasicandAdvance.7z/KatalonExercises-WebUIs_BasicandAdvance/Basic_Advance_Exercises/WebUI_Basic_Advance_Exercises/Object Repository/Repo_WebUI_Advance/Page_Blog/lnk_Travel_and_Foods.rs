<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_Travel_and_Foods</name>
   <tag></tag>
   <elementGuidId>51395cc9-3518-4e3f-86a4-9d868c9a7e87</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(@href, 'www.phptravels.net/blog/category?cat=Travel-and-Foods')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(@href, 'www.phptravels.net/blog/category?cat=Travel-and-Foods')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(@href, 'www.phptravels.net/blog/category?cat=Travel-and-Foods')]</value>
   </webElementProperties>
</WebElementEntity>
