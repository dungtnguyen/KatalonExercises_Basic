<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>tbl_PageBody</name>
   <tag></tag>
   <elementGuidId>c279e625-7ac5-4365-8def-889b4255214f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class='panel-body']/div[@class='col-md-4 go-right']/div[@class='row']/a/img[@src]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='panel-body']/div[@class='col-md-4 go-right']/div[@class='row']/a/img[@src]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='panel-body']/div[@class='col-md-4 go-right']/div[@class='row']/a/img[@src]</value>
   </webElementProperties>
</WebElementEntity>
