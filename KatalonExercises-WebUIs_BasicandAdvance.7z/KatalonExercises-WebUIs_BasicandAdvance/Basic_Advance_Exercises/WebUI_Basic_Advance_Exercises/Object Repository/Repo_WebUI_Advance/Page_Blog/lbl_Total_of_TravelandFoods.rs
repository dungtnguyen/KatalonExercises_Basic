<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Total_of_TravelandFoods</name>
   <tag></tag>
   <elementGuidId>b3598b5d-7f1e-47b5-bce3-1b31e0a7595c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='list-group']/div[@class='panel panel-default']/a[@href]/span[@class='go-left badge badge-primary'])[1]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@class='list-group']/div[@class='panel panel-default']/a[@href]/span[@class='go-left badge badge-primary'])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='list-group']/div[@class='panel panel-default']/a[@href]/span[@class='go-left badge badge-primary'])[1]</value>
   </webElementProperties>
</WebElementEntity>
