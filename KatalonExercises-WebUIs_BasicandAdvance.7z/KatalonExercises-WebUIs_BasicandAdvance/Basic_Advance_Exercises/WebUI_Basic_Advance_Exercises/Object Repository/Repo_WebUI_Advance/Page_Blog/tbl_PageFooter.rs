<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>tbl_PageFooter</name>
   <tag></tag>
   <elementGuidId>2c11e64b-8a04-4e47-a8b5-68537ffddbe1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//ul[@class='nav nav-pills nav-justified'][@role='tablist']/li/a[@href])[3]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//ul[@class='nav nav-pills nav-justified'][@role='tablist']/li/a[@href])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//ul[@class='nav nav-pills nav-justified'][@role='tablist']/li/a[@href])[3]</value>
   </webElementProperties>
</WebElementEntity>
