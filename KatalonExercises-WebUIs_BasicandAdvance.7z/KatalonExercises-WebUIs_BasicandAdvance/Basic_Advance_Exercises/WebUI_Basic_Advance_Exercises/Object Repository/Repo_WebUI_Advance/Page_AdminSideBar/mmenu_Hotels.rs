<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mmenu_Hotels</name>
   <tag></tag>
   <elementGuidId>7f2ab7c9-2132-460c-b32c-e9af16ef80b2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(@href, '#Hotels')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(@href, '#Hotels')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(@href, '#Hotels')]</value>
   </webElementProperties>
</WebElementEntity>
