<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lst_Location</name>
   <tag></tag>
   <elementGuidId>d83f4b95-8bf6-43b9-88fb-4d53270eaeae</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class='select2-container locationlist']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='select2-container locationlist']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='select2-container locationlist']</value>
   </webElementProperties>
</WebElementEntity>
