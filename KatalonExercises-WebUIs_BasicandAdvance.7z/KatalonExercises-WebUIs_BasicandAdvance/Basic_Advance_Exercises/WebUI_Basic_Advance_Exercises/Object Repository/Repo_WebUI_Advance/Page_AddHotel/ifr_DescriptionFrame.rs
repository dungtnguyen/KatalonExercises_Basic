<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ifr_DescriptionFrame</name>
   <tag></tag>
   <elementGuidId>0e9592da-4021-4675-939f-0d1168672d03</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//iframe[@class='cke_wysiwyg_frame cke_reset'][@tabindex='0'])[1]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//iframe[@class='cke_wysiwyg_frame cke_reset'][@tabindex='0'])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//iframe[@class='cke_wysiwyg_frame cke_reset'][@tabindex='0'])[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//body</value>
   </webElementXpaths>
</WebElementEntity>
