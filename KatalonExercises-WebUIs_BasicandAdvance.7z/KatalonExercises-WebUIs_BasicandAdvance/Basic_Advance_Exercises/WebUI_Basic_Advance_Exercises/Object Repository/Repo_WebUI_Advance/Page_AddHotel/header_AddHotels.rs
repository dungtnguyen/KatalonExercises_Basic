<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>header_AddHotels</name>
   <tag></tag>
   <elementGuidId>73e717e9-82a6-41bc-b7c7-0a2225a398da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h3[@class='margin-top-0'][text()='Add Hotel']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//h3[@class='margin-top-0'][text()='Add Hotel']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//h3[@class='margin-top-0'][text()='Add Hotel']</value>
   </webElementProperties>
</WebElementEntity>
