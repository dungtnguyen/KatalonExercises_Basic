<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Read_More</name>
   <tag></tag>
   <elementGuidId>ab0e38ec-adb8-47cc-a5fc-c4421f9b651f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@class='btn btn-primary go-right loader']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//a[@class='btn btn-primary go-right loader']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[@class='btn btn-primary go-right loader']</value>
   </webElementProperties>
</WebElementEntity>
