<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_WarnMessage</name>
   <tag></tag>
   <elementGuidId>be08eacc-8bfc-4a1f-a590-c8db31cc757d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class = 'resultlogin']/div[contains(text()[normalize-space()], '${warnContentPara}')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class = 'resultlogin']/div[contains(text()[normalize-space()], '${warnContentPara}')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class = 'resultlogin']/div[contains(text()[normalize-space()], '${warnContentPara}')]</value>
   </webElementProperties>
</WebElementEntity>
