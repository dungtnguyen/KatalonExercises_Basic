<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_ErrorMessage</name>
   <tag></tag>
   <elementGuidId>9f40c982-dd48-41c1-9dfc-52811b071a4f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class = 'resultlogin']/div/p[contains(text()[normalize-space()], '${errorContentPara}')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class = 'resultlogin']/div/p[contains(text()[normalize-space()], '${errorContentPara}')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class = 'resultlogin']/div/p[contains(text()[normalize-space()], '${errorContentPara}')]</value>
   </webElementProperties>
</WebElementEntity>
