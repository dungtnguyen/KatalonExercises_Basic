<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_BACKUP</name>
   <tag></tag>
   <elementGuidId>820240b1-a4fb-4876-9f6b-468abd71c4f9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@type='submit'][@class='btn btn-default btn-block']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@type='submit'][@class='btn btn-default btn-block']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@type='submit'][@class='btn btn-default btn-block']</value>
   </webElementProperties>
</WebElementEntity>
