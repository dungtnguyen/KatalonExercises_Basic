<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_BLOG</name>
   <tag></tag>
   <elementGuidId>226498ad-57e3-471c-b42b-86af976d770d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@type='submit'][@class='btn btn-success btn-block']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@type='submit'][@class='btn btn-success btn-block']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@type='submit'][@class='btn btn-success btn-block']</value>
   </webElementProperties>
</WebElementEntity>
