<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_RecentBookings</name>
   <tag></tag>
   <elementGuidId>aafac12b-7621-4f36-9ce8-90bbbc98c36d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='panel-heading'])[3][contains(text()[normalize-space()],'Recent Bookings')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>
(//div[@class='panel-heading'])[3][contains(text()[normalize-space()],'Recent Bookings')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='panel-heading'])[3][contains(text()[normalize-space()],'Recent Bookings')]</value>
   </webElementProperties>
</WebElementEntity>
