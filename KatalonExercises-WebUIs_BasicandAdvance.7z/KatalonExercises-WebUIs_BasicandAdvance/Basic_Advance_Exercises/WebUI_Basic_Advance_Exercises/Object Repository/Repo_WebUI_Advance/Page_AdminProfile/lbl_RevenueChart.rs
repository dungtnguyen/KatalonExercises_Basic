<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_RevenueChart</name>
   <tag></tag>
   <elementGuidId>186e2651-d3c6-4a9d-86ac-ecf7b8c7155d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='panel-heading'])[2][contains(text()[normalize-space()],'Revenue Chart')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@class='panel-heading'])[2][contains(text()[normalize-space()],'Revenue Chart')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='panel-heading'])[2][contains(text()[normalize-space()],'Revenue Chart')]</value>
   </webElementProperties>
</WebElementEntity>
