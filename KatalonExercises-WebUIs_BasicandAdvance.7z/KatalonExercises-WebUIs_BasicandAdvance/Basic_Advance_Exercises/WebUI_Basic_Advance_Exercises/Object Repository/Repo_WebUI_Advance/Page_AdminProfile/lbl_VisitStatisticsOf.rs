<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_VisitStatisticsOf</name>
   <tag></tag>
   <elementGuidId>24b46947-5f0e-45d2-a739-7569d1c9efb6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='panel-heading'])[4]/div[@class='pull-left'][contains(text()[normalize-space()],'Visit Statistics of')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@class='panel-heading'])[4]/div[@class='pull-left'][contains(text()[normalize-space()],'Visit Statistics of')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='panel-heading'])[4]/div[@class='pull-left'][contains(text()[normalize-space()],'Visit Statistics of')]</value>
   </webElementProperties>
</WebElementEntity>
