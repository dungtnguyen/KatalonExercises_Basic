<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_BookingSummary</name>
   <tag></tag>
   <elementGuidId>7e254a7c-fbbe-4056-9770-01a176d18663</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='panel-heading'])[1][contains(text()[normalize-space()],'Booking Summary')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@class='panel-heading'])[1][contains(text()[normalize-space()],'Booking Summary')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='panel-heading'])[1][contains(text()[normalize-space()],'Booking Summary')]</value>
   </webElementProperties>
</WebElementEntity>
