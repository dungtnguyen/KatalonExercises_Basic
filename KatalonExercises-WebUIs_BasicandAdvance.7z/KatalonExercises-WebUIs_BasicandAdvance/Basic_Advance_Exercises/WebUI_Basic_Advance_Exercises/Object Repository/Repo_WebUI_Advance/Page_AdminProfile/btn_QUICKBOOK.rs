<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_QUICKBOOK</name>
   <tag></tag>
   <elementGuidId>5f9abb30-ae55-41c1-ac49-c7f6e71c2245</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@data-target='#quickbook'][@class='btn btn-danger btn-block']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@data-target='#quickbook'][@class='btn btn-danger btn-block']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@data-target='#quickbook'][@class='btn btn-danger btn-block']</value>
   </webElementProperties>
</WebElementEntity>
