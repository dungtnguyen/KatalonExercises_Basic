<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_BOOKINGS</name>
   <tag></tag>
   <elementGuidId>345d074f-325b-4300-9ad1-0c7466544cdf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@type='submit'][@class='btn btn-primary btn-block']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@type='submit'][@class='btn btn-primary btn-block']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@type='submit'][@class='btn btn-primary btn-block']</value>
   </webElementProperties>
</WebElementEntity>
