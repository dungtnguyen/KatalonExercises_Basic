<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_NEWSLETTER</name>
   <tag></tag>
   <elementGuidId>c0c46627-eab1-4d66-93ab-2f16329f275a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@type='submit'][@class='btn btn-warning btn-block']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@type='submit'][@class='btn btn-warning btn-block']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@type='submit'][@class='btn btn-warning btn-block']</value>
   </webElementProperties>
</WebElementEntity>
