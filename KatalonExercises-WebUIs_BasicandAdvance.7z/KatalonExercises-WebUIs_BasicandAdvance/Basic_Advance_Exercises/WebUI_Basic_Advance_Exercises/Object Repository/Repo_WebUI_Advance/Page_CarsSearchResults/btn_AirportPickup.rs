<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_AirportPickup</name>
   <tag></tag>
   <elementGuidId>c4affcd3-7cf0-434e-af73-04a22861181d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//table[@class='bgwhite table table-striped']/tbody/tr/td/div[@class='col-md-6 col-xs-4 go-right']/div[@class='row']/h4/button[@class='btn btn-success btn-xs'])[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(//table[@class='bgwhite table table-striped']/tbody/tr/td/div[@class='col-md-6 col-xs-4 go-right']/div[@class='row']/h4/button[@class='btn btn-success btn-xs'])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//table[@class='bgwhite table table-striped']/tbody/tr/td/div[@class='col-md-6 col-xs-4 go-right']/div[@class='row']/h4/button[@class='btn btn-success btn-xs'])[1]</value>
   </webElementProperties>
</WebElementEntity>
