<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_DropFile</name>
   <tag></tag>
   <elementGuidId>e146fc5f-d529-440b-8f6e-641bc8fca67c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@id='dropzone'][@class='dropzone dz-clickable']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='dropzone'][@class='dropzone dz-clickable']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@id='dropzone'][@class='dropzone dz-clickable']</value>
   </webElementProperties>
</WebElementEntity>
