<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_AddPhotos</name>
   <tag></tag>
   <elementGuidId>19a4fde2-450d-4d38-8339-1afaaeb1fa4b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(@href, 'UploadPhotos')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(@href, 'UploadPhotos')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(@href, 'UploadPhotos')]</value>
   </webElementProperties>
</WebElementEntity>
