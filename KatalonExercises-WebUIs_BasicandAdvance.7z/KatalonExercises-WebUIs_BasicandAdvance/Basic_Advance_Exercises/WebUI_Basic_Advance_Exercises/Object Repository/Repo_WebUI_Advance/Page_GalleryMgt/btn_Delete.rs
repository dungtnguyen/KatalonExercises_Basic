<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Delete</name>
   <tag></tag>
   <elementGuidId>ac9c324d-7300-4263-bb13-0151582ca086</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@class='btn btn-danger btn-block btn-md deleteImg'][contains(text(), 'Delete')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//button[@class='btn btn-danger btn-block btn-md deleteImg'][contains(text(), 'Delete')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@class='btn btn-danger btn-block btn-md deleteImg'][contains(text(), 'Delete')]</value>
   </webElementProperties>
</WebElementEntity>
