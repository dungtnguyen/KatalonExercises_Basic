<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_Search</name>
   <tag></tag>
   <elementGuidId>b6040613-6cda-442d-8963-f6b9ffaeac78</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class='xcrud-searchdata xcrud-search-active input-small form-control']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@class='xcrud-searchdata xcrud-search-active input-small form-control']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class='xcrud-searchdata xcrud-search-active input-small form-control']</value>
   </webElementProperties>
</WebElementEntity>
