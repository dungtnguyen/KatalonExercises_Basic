<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Search</name>
   <tag></tag>
   <elementGuidId>256c0f8c-ceb6-4745-83f1-606501c516cb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class='xcrud-search-toggle btn btn-default'][text()='Search']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@class='xcrud-search-toggle btn btn-default'][text()='Search']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class='xcrud-search-toggle btn btn-default'][text()='Search']</value>
   </webElementProperties>
</WebElementEntity>
