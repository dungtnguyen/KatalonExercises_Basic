<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Add</name>
   <tag></tag>
   <elementGuidId>eef69a46-e9c0-4eb5-a195-45db00ae6356</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//form[@class='add_button']/button[@type='submit'][@class='btn btn-success']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@class='add_button']/button[@type='submit'][@class='btn btn-success']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//form[@class='add_button']/button[@type='submit'][@class='btn btn-success']</value>
   </webElementProperties>
</WebElementEntity>
