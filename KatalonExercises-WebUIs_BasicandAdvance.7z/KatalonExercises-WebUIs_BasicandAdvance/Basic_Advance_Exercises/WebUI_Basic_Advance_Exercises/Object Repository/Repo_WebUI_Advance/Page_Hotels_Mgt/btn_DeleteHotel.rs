<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_DeleteHotel</name>
   <tag></tag>
   <elementGuidId>1ab8c38a-243f-4dce-bb99-784f03321247</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//a[@class='btn btn-default btn-xcrud btn-danger'])[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(//a[@class='btn btn-default btn-xcrud btn-danger'])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//a[@class='btn btn-default btn-xcrud btn-danger'])[1]</value>
   </webElementProperties>
</WebElementEntity>
