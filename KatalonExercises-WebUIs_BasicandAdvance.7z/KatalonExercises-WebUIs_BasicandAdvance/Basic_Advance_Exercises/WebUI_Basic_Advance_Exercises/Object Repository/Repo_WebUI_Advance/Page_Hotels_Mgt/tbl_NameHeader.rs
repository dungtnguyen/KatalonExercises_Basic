<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>tbl_NameHeader</name>
   <tag></tag>
   <elementGuidId>5712e921-c8cd-4d80-af81-b1211798b39a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//th[@class='xcrud-column xcrud-action'][3]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//th[@class='xcrud-column xcrud-action'][3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//th[@class='xcrud-column xcrud-action'][3]</value>
   </webElementProperties>
</WebElementEntity>
