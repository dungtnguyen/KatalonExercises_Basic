<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>tbl_LocationHeader</name>
   <tag></tag>
   <elementGuidId>520e44a6-f1bb-4836-a92c-92cfa3070965</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//th[@class='xcrud-column xcrud-action'][5]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//th[@class='xcrud-column xcrud-action'][5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//th[@class='xcrud-column xcrud-action'][5]</value>
   </webElementProperties>
</WebElementEntity>
