<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>tbl_TableBody</name>
   <tag></tag>
   <elementGuidId>3190defc-5b08-40d0-9859-dfcf98b570d7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//table[@class='xcrud-list table table-striped table-hover']/tbody</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//table[@class='xcrud-list table table-striped table-hover']/tbody</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//table[@class='xcrud-list table table-striped table-hover']/tbody</value>
   </webElementProperties>
</WebElementEntity>
