<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>tbl_NameHeader_Desc</name>
   <tag></tag>
   <elementGuidId>b0c30fd2-e7c9-4c68-a827-a4ee44b10774</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//th[@class='xcrud-column xcrud-action xcrud-current xcrud-desc']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//th[@class='xcrud-column xcrud-action xcrud-current xcrud-desc']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//th[@class='xcrud-column xcrud-action xcrud-current xcrud-desc']</value>
   </webElementProperties>
</WebElementEntity>
