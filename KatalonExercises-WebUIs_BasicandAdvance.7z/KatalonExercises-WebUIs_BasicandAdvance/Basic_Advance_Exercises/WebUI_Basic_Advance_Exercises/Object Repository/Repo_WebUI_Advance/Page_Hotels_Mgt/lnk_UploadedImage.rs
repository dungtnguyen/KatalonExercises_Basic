<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_UploadedImage</name>
   <tag></tag>
   <elementGuidId>2e5135d9-883a-4fca-91cf-da0e1a5fdc9f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//tbody/tr[@class='xcrud-row xcrud-row-0']/td[@class='zoom_img']/img)[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(//tbody/tr[@class='xcrud-row xcrud-row-0']/td[@class='zoom_img']/img)[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//tbody/tr[@class='xcrud-row xcrud-row-0']/td[@class='zoom_img']/img)[1]</value>
   </webElementProperties>
</WebElementEntity>
