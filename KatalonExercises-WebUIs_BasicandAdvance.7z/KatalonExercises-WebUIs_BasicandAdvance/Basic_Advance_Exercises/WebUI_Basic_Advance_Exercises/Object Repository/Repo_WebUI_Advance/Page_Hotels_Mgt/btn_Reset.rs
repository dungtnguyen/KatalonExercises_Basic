<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Reset</name>
   <tag></tag>
   <elementGuidId>f407ce79-e66e-4c2d-a6b6-c33da47442ae</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class='xcrud-action btn btn-default'][text()='Reset']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@class='xcrud-action btn btn-default'][text()='Reset']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class='xcrud-action btn btn-default'][text()='Reset']</value>
   </webElementProperties>
</WebElementEntity>
