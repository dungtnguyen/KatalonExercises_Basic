<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>tbl_LocationHeader_Asc</name>
   <tag></tag>
   <elementGuidId>5b8e937a-2ee8-4ee9-b5ff-6f6e6b3a4c68</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//th[@class='xcrud-column xcrud-action xcrud-current xcrud-asc']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//th[@class='xcrud-column xcrud-action xcrud-current xcrud-asc']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//th[@class='xcrud-column xcrud-action xcrud-current xcrud-asc']</value>
   </webElementProperties>
</WebElementEntity>
