<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_GO</name>
   <tag></tag>
   <elementGuidId>cf44a473-9205-4650-a027-f88a8bcd0714</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class='xcrud-action btn btn-primary'][text()='Go']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@class='xcrud-action btn btn-primary'][text()='Go']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class='xcrud-action btn btn-primary'][text()='Go']</value>
   </webElementProperties>
</WebElementEntity>
