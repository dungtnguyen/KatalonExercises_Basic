<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_Upload</name>
   <tag></tag>
   <elementGuidId>40f0b463-3b94-4e46-80ca-b1cb86ce28e7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(@href, 'VN')])[2][contains(text(), 'Upload')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(//a[contains(@href, 'VN')])[2][contains(text(), 'Upload')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'VN')])[2][contains(text(), 'Upload')]</value>
   </webElementProperties>
</WebElementEntity>
