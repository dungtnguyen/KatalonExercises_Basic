<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>slider_PriceRange</name>
   <tag></tag>
   <elementGuidId>87d8fc90-dbd5-41b8-b773-f8a4a2a94ef6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='slider-track']/div[@class='slider-handle round'][@style='left: 100%;']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//div[@class='slider-track']/div[@class='slider-handle round'][@style='left: 100%;']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='slider-track']/div[@class='slider-handle round'][@style='left: 100%;']</value>
   </webElementProperties>
</WebElementEntity>
