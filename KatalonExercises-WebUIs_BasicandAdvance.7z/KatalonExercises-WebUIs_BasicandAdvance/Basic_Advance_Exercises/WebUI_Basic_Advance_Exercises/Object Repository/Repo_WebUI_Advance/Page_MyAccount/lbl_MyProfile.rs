<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_MyProfile</name>
   <tag></tag>
   <elementGuidId>e002514b-358c-4e77-b29a-c86c2cce3220</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/a[contains(@href, '#profile')][text()[normalize-space()='My Profile']]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li/a[contains(@href, '#profile')][text()[normalize-space()='My Profile']]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/a[contains(@href, '#profile')][text()[normalize-space()='My Profile']]</value>
   </webElementProperties>
</WebElementEntity>
