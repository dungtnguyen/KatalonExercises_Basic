<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>icon_Bookings</name>
   <tag></tag>
   <elementGuidId>ecea7610-6016-474b-a201-d32b52e4d561</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li[@class='active']/a[contains(@href, '#bookings')][text()[normalize-space()='Bookings']]/span[@class='bookings-icon']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@class='active']/a[contains(@href, '#bookings')][text()[normalize-space()='Bookings']]/span[@class='bookings-icon']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li[@class='active']/a[contains(@href, '#bookings')][text()[normalize-space()='Bookings']]/span[@class='bookings-icon']</value>
   </webElementProperties>
</WebElementEntity>
