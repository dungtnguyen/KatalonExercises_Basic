<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_UserName</name>
   <tag></tag>
   <elementGuidId>5282d50f-1cf0-4e66-a4b7-c7cc41642ca4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class='col-md-6 go-right RTL']/h3[@class='RTL']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='col-md-6 go-right RTL']/h3[@class='RTL']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='col-md-6 go-right RTL']/h3[@class='RTL']</value>
   </webElementProperties>
</WebElementEntity>
