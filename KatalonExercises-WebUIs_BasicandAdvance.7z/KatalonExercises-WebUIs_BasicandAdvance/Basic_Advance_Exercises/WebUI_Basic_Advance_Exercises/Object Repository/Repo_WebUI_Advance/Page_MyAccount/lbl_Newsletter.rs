<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Newsletter</name>
   <tag></tag>
   <elementGuidId>a418e98b-091d-4144-ad9d-337451236569</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/a[contains(@href, '#newsletter')][text()[normalize-space()='Newsletter']]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li/a[contains(@href, '#newsletter')][text()[normalize-space()='Newsletter']]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/a[contains(@href, '#newsletter')][text()[normalize-space()='Newsletter']]</value>
   </webElementProperties>
</WebElementEntity>
