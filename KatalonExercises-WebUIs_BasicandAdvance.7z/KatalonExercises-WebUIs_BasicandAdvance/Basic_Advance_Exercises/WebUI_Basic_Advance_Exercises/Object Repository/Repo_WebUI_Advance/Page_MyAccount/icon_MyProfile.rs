<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>icon_MyProfile</name>
   <tag></tag>
   <elementGuidId>5e2c8d4f-e3d6-4dc4-8e34-11049a4326a8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/a[contains(@href, '#profile')][text()[normalize-space()='My Profile']]/span[@class='profile-icon']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li/a[contains(@href, '#profile')][text()[normalize-space()='My Profile']]/span[@class='profile-icon']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/a[contains(@href, '#profile')][text()[normalize-space()='My Profile']]/span[@class='profile-icon']</value>
   </webElementProperties>
</WebElementEntity>
