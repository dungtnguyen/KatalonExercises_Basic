<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Wishlist</name>
   <tag></tag>
   <elementGuidId>0a5f393b-bd92-4cdb-b32a-5db7b454fce1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/a[contains(@href, '#wishlist')][text()[normalize-space()='Wishlist']]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li/a[contains(@href, '#wishlist')][text()[normalize-space()='Wishlist']]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/a[contains(@href, '#wishlist')][text()[normalize-space()='Wishlist']]</value>
   </webElementProperties>
</WebElementEntity>
