<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>icon_Wishlist</name>
   <tag></tag>
   <elementGuidId>87ec5895-28f5-48b9-87f1-cbd7d35e8f47</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li/a[contains(@href, '#wishlist')][text()[normalize-space()='Wishlist']]/span[@class='wishlist-icon']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li/a[contains(@href, '#wishlist')][text()[normalize-space()='Wishlist']]/span[@class='wishlist-icon']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li/a[contains(@href, '#wishlist')][text()[normalize-space()='Wishlist']]/span[@class='wishlist-icon']</value>
   </webElementProperties>
</WebElementEntity>
