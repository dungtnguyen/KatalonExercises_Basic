<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Bookings</name>
   <tag></tag>
   <elementGuidId>97fca9ae-6a0d-4f79-9340-2fe3007a04f7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li[@class='active']/a[contains(@href, '#bookings')][text()[normalize-space()='Bookings']]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@class='active']/a[contains(@href, '#bookings')][text()[normalize-space()='Bookings']]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li[@class='active']/a[contains(@href, '#bookings')][text()[normalize-space()='Bookings']]</value>
   </webElementProperties>
</WebElementEntity>
