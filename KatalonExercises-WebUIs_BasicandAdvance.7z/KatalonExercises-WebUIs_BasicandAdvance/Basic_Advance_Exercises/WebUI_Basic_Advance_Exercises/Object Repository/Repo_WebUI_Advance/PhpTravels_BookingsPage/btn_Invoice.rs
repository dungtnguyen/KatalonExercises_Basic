<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Invoice</name>
   <tag></tag>
   <elementGuidId>05bd3fd0-e05c-4071-b441-8426fa089941</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@id='bookings']/div[@class='row'])[1]/div[@class='col-md-2 offset-0 go-right']/a[@class='btn btn-action btn-block']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id='bookings']/div[@class='row'])[1]/div[@class='col-md-2 offset-0 go-right']/a[@class='btn btn-action btn-block']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@id='bookings']/div[@class='row'])[1]/div[@class='col-md-2 offset-0 go-right']/a[@class='btn btn-action btn-block']</value>
   </webElementProperties>
</WebElementEntity>
