<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>submnu_Login</name>
   <tag></tag>
   <elementGuidId>554132fd-12ad-4bbb-ac89-dd61aecd3789</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li[@id='li_myaccount'][@class='open']/ul[@class='dropdown-menu']/li/a[contains(@href, 'https://www.phptravels.net/login')][text()=' Login']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='li_myaccount'][@class='open']/ul[@class='dropdown-menu']/li/a[contains(@href, 'https://www.phptravels.net/login')][text()=' Login']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li[@id='li_myaccount'][@class='open']/ul[@class='dropdown-menu']/li/a[contains(@href, 'https://www.phptravels.net/login')][text()=' Login']</value>
   </webElementProperties>
</WebElementEntity>
