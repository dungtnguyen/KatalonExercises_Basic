<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mnuitem_HotelsSettings</name>
   <tag></tag>
   <elementGuidId>32471c0d-db17-439f-978f-1f0ff4549b1b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels/settings')][text()='Hotels Settings']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels/settings')][text()='Hotels Settings']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels/settings')][text()='Hotels Settings']</value>
   </webElementProperties>
</WebElementEntity>
