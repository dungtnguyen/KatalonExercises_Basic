<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mmenu_Hotels</name>
   <tag></tag>
   <elementGuidId>143908ca-c03b-4742-af0f-586eff44ee55</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(@href, '#Hotels')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(@href, '#Hotels')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(@href, '#Hotels')]</value>
   </webElementProperties>
</WebElementEntity>
