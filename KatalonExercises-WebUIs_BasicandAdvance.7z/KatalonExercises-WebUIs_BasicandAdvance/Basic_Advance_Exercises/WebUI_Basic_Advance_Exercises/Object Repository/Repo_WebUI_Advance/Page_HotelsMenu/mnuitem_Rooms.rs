<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mnuitem_Rooms</name>
   <tag></tag>
   <elementGuidId>0b30dafa-16eb-4fef-bb4b-db8985b2dc45</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels/rooms')][text()='Rooms']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels/rooms')][text()='Rooms']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels/rooms')][text()='Rooms']</value>
   </webElementProperties>
</WebElementEntity>
