<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mnuitem_Hotels</name>
   <tag></tag>
   <elementGuidId>89f12206-a6fe-4f53-80b5-2b7f3400d045</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels')][text()='Hotels']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels')][text()='Hotels']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels')][text()='Hotels']</value>
   </webElementProperties>
</WebElementEntity>
