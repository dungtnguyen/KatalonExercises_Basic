<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mnuitem_Reviews</name>
   <tag></tag>
   <elementGuidId>7c8044bc-296a-4a70-962f-5942e30217ee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels/reviews')][text()='Reviews']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels/reviews')][text()='Reviews']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels/reviews')][text()='Reviews']</value>
   </webElementProperties>
</WebElementEntity>
