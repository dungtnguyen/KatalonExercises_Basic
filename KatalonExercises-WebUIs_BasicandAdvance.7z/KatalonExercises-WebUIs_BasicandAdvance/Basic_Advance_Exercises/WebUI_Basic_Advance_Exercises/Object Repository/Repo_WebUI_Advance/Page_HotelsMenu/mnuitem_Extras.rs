<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mnuitem_Extras</name>
   <tag></tag>
   <elementGuidId>410cf724-2d85-4e71-8691-161331debfd1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels/extras')][text()='Extras']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels/extras')][text()='Extras']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//ul[@id='Hotels']/li/a[contains(@href, 'https://www.phptravels.net/admin/hotels/extras')][text()='Extras']</value>
   </webElementProperties>
</WebElementEntity>
