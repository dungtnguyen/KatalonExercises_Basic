<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lst_AirportPickup</name>
   <tag></tag>
   <elementGuidId>2ca75a97-d289-4d5a-ab78-3819e36c84cd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//select[@name = 'pickup']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@name='pickup']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//select[@name = 'pickup']</value>
   </webElementProperties>
</WebElementEntity>
