<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_HotelModules</name>
   <tag></tag>
   <elementGuidId>67b1c839-a318-49c4-b447-338218ae2714</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@class='btn btn-xs btn-disable'][@data-modulename='Hotels']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@class='btn btn-xs btn-disable'][@data-modulename='Hotels']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@class='btn btn-xs btn-disable'][@data-modulename='Hotels']</value>
   </webElementProperties>
</WebElementEntity>
