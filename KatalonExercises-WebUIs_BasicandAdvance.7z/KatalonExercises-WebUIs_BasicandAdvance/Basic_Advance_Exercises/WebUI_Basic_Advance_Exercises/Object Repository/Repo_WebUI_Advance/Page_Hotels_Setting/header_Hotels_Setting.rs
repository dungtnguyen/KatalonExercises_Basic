<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>header_Hotels_Setting</name>
   <tag></tag>
   <elementGuidId>93605dbd-d4c5-4dc9-b4b3-121a496f684b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//h3[@class='margin-top-0'][text()='Hotels Settings']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//h3[@class='margin-top-0'][text()='Hotels Settings']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//h3[@class='margin-top-0'][text()='Hotels Settings']</value>
   </webElementProperties>
</WebElementEntity>
