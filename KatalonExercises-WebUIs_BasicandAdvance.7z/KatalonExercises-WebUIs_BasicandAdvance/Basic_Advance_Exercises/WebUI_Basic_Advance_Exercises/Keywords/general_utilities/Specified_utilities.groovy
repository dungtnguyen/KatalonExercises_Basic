package general_utilities

import org.openqa.selenium.By
import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.interactions.Action
import org.openqa.selenium.interactions.Actions
import com.kms.katalon.core.configuration.RunConfiguration
import static org.testng.reporters.Files.readFile

import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.webui.common.WebUiCommonHelper

import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.testobject.TestObject as TestObject
//import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.model.FailureHandling as FailureHandling

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.driver.WebUIDriverType
import org.openqa.selenium.Keys as Keys
import java.awt.Robot
import java.awt.event.KeyEvent
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import java.util.Random
import org.openqa.selenium.support.Color

/*
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 The function list and meanings:
 1. selectSubMenuItemInlevelOneAndVerifyOpeningPage(String mainMenuName, String menuItemName, String nextTitlePage, int timeOut)
 to be used for selecting main menu then sub menu item then verify that the relevant page is opened.
 2. inputUsernameAndPasswordPressingButton(String userName, String userNameData, String passwordName, String passData, String buttonName, int timeOut):
 to be used for verifying and inputting the email of a User name, password then pressing the Login button
 3. verifyElementTextAndRelevantIcon(String elementName, String expText, String iconObjName, int timeOut):
 to be used for verifying the text of element and its relevant icon
 4. getAttributeAndVerify(String elementName, String attrName, String expAttr):
 to be used for getting the attribute of element and verifying it with expectation attribute			
 5. getTextAndVerify(String elementName, String expText, int timeOut):
 to be used for getting the text of element and verifying it with expectation text
 6. verifyExistAndClicking(String elementName, int timeOut):
 to be used for verifying the visible of element then clicking it 		
 7. modifyAttributeWebElemntAndClicking(String xpathValue):
 to be used for modifying the attribute of web element and then clicking it		
 8. clickHyperlinkTextAndVerifyTitleOfPage(String linkTestObject, String pageTitleTestObject, String expPageTitle, int waitTime):)
 to be used for clicking the hyperlink text and then verifying the relevant page title
 9	countAllItemsInPageList(int expValue):
 to be used for counting all items in the page list and return the number of item
 10. countAllItemsInPageAndClickAnItemUnderRandom(String xPathName, String objName):
 to be used for counting all items in the page list and then selecting an item in random then clicking on it		
 11. movingMouseOverOverTestObjectAndVerifyOtherObjExisting(String firstObjName, String secondObjName, int timeOut):
 to be used for moving the mouse over a test object and verify that other object is  displayed		
 12. clickonTestObjectAndVerifyOtherObjExisting(String firstObjName, String secondObjName, int timeOut):
 to be used for moving the mouse over a test object and verify that other object is  displayed
 */


public class Specified_utilities {

	/**
	 * to be used for selecting main menu then sub menu item on the PHP Travels application then verify that 
	 * the relevant page is opened.
	 */
	@Keyword
	def selectSubMenuItemInlevelOneAndVerifyOpeningPage(String mainMenuName, String menuItemName, String nextTitlePage, int timeOut) {

		WebUI.waitForElementVisible(findTestObject(mainMenuName), timeOut)
		WebUI.click(findTestObject(mainMenuName))

		WebUI.waitForElementVisible(findTestObject(menuItemName), timeOut)
		WebUI.click(findTestObject(menuItemName))

		WebUI.waitForElementVisible(findTestObject(nextTitlePage), timeOut)
	}

	/**
	 * to be used for verifying and inputting the email of a User name, password then pressing the Login button on the PHP Travels application
	 */
	@Keyword
	def inputUsernameAndPasswordPressingButton(String userName, String userNameData, String passwordName, String passData, String buttonName, int timeOut) {

		WebUI.waitForElementVisible(findTestObject(userName), timeOut)
		WebUI.setText(findTestObject(userName), userNameData)

		WebUI.waitForElementVisible(findTestObject(passwordName), timeOut)
		WebUI.setText(findTestObject(passwordName), passData)

		WebUI.waitForElementVisible(findTestObject(buttonName), timeOut)
		WebUI.sendKeys(findTestObject(buttonName), Keys.chord(Keys.ENTER))
		//WebUI.click(findTestObject(buttonName))
	}

	/**
	 * to be used for verifying the text of element and its relevant icon on the PHP Travels application
	 */
	@Keyword
	def verifyElementTextAndRelevantIcon(String elementName, String expText, String iconObjName, int timeOut) {

		WebUI.waitForElementVisible(findTestObject(elementName), timeOut)
		String actText = WebUI.getText(findTestObject(elementName))
		WebUI.verifyEqual(actText, expText)

		WebUI.verifyElementPresent(findTestObject(iconObjName), timeOut)
	}

	/**
	 * to be used for getting the attribute of element and verifying it with expectation attribute on the PHP Travels application
	 */
	@Keyword
	def getAttributeAndVerify(String elementName, String attrName, String expAttr) {

		'Get an attribute value of the identified element'
		String actAttr = WebUI.getAttribute(findTestObject(elementName), attrName)

		KeywordLogger log = new KeywordLogger()
		log.logInfo('The attribute value of User: ' + actAttr)

		'Verify actual attribute value is correct the expectation'
		WebUI.verifyEqual(actAttr, expAttr)
	}

	/**
	 * to be used for getting the text of element and verifying it with expectation text on the PHP Travels application
	 */
	@Keyword
	def getTextAndVerify(String elementName, String expText, int timeOut) {
		WebUI.waitForElementVisible(findTestObject(elementName), timeOut)
		String actText = WebUI.getText(findTestObject(elementName))
		WebUI.verifyEqual(actText.trim(), expText)


	}

	/**
	 * to be used for verifying the visible of element then clicking it on the PHP Travels application
	 */
	@Keyword
	def verifyExistAndClicking(String elementName, int timeOut) {
		//if (WebUI.verifyElementPresent(findTestObject(elementName), timeOut)){
		if (WebUI.waitForElementVisible(findTestObject(elementName), timeOut, FailureHandling.CONTINUE_ON_FAILURE)){
			WebUI.click(findTestObject(elementName))
		}

	}

	/**
	 * to be used for modifying the attribute of web element and then clicking it on the PHP Travels application
	 */
	@Keyword
	def modifyAttributeWebElemntAndClicking(String xpathValue) {
		'Modify property: \'xpath\' of \'PriceRange\' Object and click on it'
		WebDriver driver = DriverFactory.getWebDriver()
		JavascriptExecutor js = (JavascriptExecutor) driver;

		//WebElement new_PriceRange = driver.findElement(By.xpath("//div[@class=\'slider-track\']/div[@class=\'slider-handle round\'][@style=\'left: 100%;\']"));
		WebElement new_PriceRange = driver.findElement(By.xpath(xpathValue));
		js.executeScript("arguments[0].setAttribute('style', 'left: 60%;')",new_PriceRange);


	}

	/**
	 * to be used for clicking the hyperlink text and then verifying the relevant page title on the PHP Travels application
	 */
	@Keyword
	public boolean clickHyperlinkTextAndVerifyTitleOfPage(String linkTestObject, String pageTitleTestObject, String expPageTitle, int waitTime){
		boolean returnValue = true

		returnValue = WebUI.verifyElementPresent(findTestObject(linkTestObject), waitTime)
		if(returnValue){
			WebUI.click(findTestObject(linkTestObject))

			'Wait and verify the header title of page is displayed '
			String Act_pageTitle = WebUI.getText(findTestObject(pageTitleTestObject))
			returnValue = WebUI.verifyEqual(Act_pageTitle, expPageTitle)
			return returnValue

		} else {
			return false
		}

	}

	/**
	 * to be used for counting all items in the page list on the PHP Travels application and return the number of item 
	 */
	@Keyword
	def countAllItemsInPageList(int expValue) {

		WebDriver driver = DriverFactory.getWebDriver()
		KeywordLogger log = new KeywordLogger()

		'Get all items in the displayed page'
		int myCount = driver.findElements(By.xpath("//div[@class='panel-body']/div[@class='col-md-4 go-right']/div[@class='row']/a/img[@src]")).size();
		log.logInfo("The value of displayed page is : " + myCount)

		if (expValue > 5){
			'Get total page if any'
			int myFooterPageCount = driver.findElements(By.xpath("//ul[@class='nav nav-pills nav-justified'][@role='tablist']/li/a[@href]")).size();


			for(int j=2;j<=myFooterPageCount-2;j++){
				'Change the attribute: xpath before clicking the new tbl_PageFoote.'
				String localvar_XpathFooterPage = "(//ul[@class='nav nav-pills nav-justified'][@role='tablist']/li/a[@href])[" + (j+1).toString() + "]"

				'Modify property: \'xpath\' of \'tbl_PageFooter\' and get per pickup'
				TestObject new_tbl_PageFooter = WebUI.modifyObjectProperty(findTestObject('Repo_WebUI_Advance/Page_Blog/tbl_PageFooter'), 'xpath', 'equals', localvar_XpathFooterPage, true)

				'Click on the next page'
				WebUI.click(new_tbl_PageFooter)
				WebUI.delay(GlobalVariable.gl_objectWait5)

				'Count the current page which just clicked before'
				int myCountNextPage = driver.findElements(By.xpath("//div[@class='panel-body']/div[@class='col-md-4 go-right']/div[@class='row']/a/img[@src]")).size();
				myCount = myCount + myCountNextPage
				log.logInfo("The  updated value of total item is : " + myCount)
			}
		}
		return myCount
	}



	/**
	 * to be used for counting all items in the page list on the PHP Travels application and then selecting an item in random then clicking on it
	 */
	@Keyword
	def countAllItemsInPageAndClickAnItemUnderRandom(String xPathName, String objName) {

		WebDriver driver = DriverFactory.getWebDriver()
		KeywordLogger log = new KeywordLogger()

		'Get all items in the displayed page'
		int myCount = driver.findElements(By.xpath(xPathName)).size();
		log.logInfo("The value of displayed page is : " + myCount)

		if (myCount > 0){
			'Creating a value by generating under random '
			Random rnd = new Random()
			int RandomValue = rnd.nextInt(myCount)

			'Creating an Xpath for this object'
			String localvar_Xpath = "(" + xPathName + ")[" + RandomValue.toString() + "]"

			'Modify property: \'xpath\' of \'tbl_PageFooter\' and get per pickup'
			TestObject new_TextObject = WebUI.modifyObjectProperty(findTestObject(objName), 'xpath', 'equals', localvar_Xpath, true)

			'Click on the next page'
			WebUI.click(new_TextObject)
			WebUI.delay(GlobalVariable.gl_objectWait5)
		}
	}

	/**
	 * to be used for moving the mouse over a test object and verify that other object is  displayed on the PHP Travels application
	 */
	@Keyword
	def movingMouseOverOverTestObjectAndVerifyOtherObjExisting(String firstObjName, String secondObjName, int timeOut) {
		WebUI.waitForElementVisible(findTestObject(firstObjName), timeOut)
		WebUI.mouseOverOffset(findTestObject(firstObjName), 20,30)

		WebUI.waitForElementVisible(findTestObject(secondObjName), timeOut)
	}

	/**
	 * to be used for clicking on test object and verify that other object is  displayed on the PHP Travels application
	 */
	@Keyword
	def clickonTestObjectAndVerifyOtherObjExisting(String firstObjName, String secondObjName, int timeOut) {
		WebUI.waitForElementVisible (findTestObject(firstObjName), timeOut)
		WebUI.click(findTestObject(firstObjName))
		WebUI.delay(timeOut)
		//WebUI.click(findTestObject(firstObjName))

		WebUI.waitForElementVisible(findTestObject(secondObjName), timeOut)
	}

	/**
	 * to be used for clicking on test object and verify that other object is  displayed on the PHP Travels application
	 */
	@Keyword
	def verifyBackgroundColorOfTestObjectExisting(String firstObjName, String expColor) {

		'Get the color of the test object'
		String var_returnBgColor = WebUI.getCSSValue(findTestObject(firstObjName), 'background-color')

		'Chang the gotten value to Hex and compare with expected color'
		String act_HexColor = Color.fromString(var_returnBgColor).asHex()
		WebUI.verifyEqual(act_HexColor, expColor)
	}

	/**
	 * to be used for inputting data from keyboard on the PHP Travels application by using Rotbot
	 */
	@Keyword
	def inputTextByRobot(String inputText) {
		char character
		//Robot robot = new Robot()

		for(int i=0; i<= inputText.length()-1; i++) {
			character = inputText.charAt(i)
			switch (character) {
				case 'a': typeOnePara(KeyEvent.VK_A); break;
				case 'b': typeOnePara(KeyEvent.VK_B); break;
				case 'c': typeOnePara(KeyEvent.VK_C); break;
				case 'd': typeOnePara(KeyEvent.VK_D); break;
				case 'e': typeOnePara(KeyEvent.VK_E); break;
				case 'f': typeOnePara(KeyEvent.VK_F); break;
				case 'g': typeOnePara(KeyEvent.VK_G); break;
				case 'h': typeOnePara(KeyEvent.VK_H); break;
				case 'i': typeOnePara(KeyEvent.VK_I); break;
				case 'j': typeOnePara(KeyEvent.VK_J); break;
				case 'k': typeOnePara(KeyEvent.VK_K); break;
				case 'l': typeOnePara(KeyEvent.VK_L); break;
				case 'm': typeOnePara(KeyEvent.VK_M); break;
				case 'n': typeOnePara(KeyEvent.VK_N); break;
				case 'o': typeOnePara(KeyEvent.VK_O); break;
				case 'p': typeOnePara(KeyEvent.VK_P); break;
				case 'q': typeOnePara(KeyEvent.VK_Q); break;
				case 'r': typeOnePara(KeyEvent.VK_R); break;
				case 's': typeOnePara(KeyEvent.VK_S); break;
				case 't': typeOnePara(KeyEvent.VK_T); break;
				case 'u': typeOnePara(KeyEvent.VK_U); break;
				case 'v': typeOnePara(KeyEvent.VK_V); break;
				case 'w': typeOnePara(KeyEvent.VK_W); break;
				case 'x': typeOnePara(KeyEvent.VK_X); break;
				case 'y': typeOnePara(KeyEvent.VK_Y); break;
				case 'z': typeOnePara(KeyEvent.VK_Z); break;
				case 'A': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_A); break;
				case 'B': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_B); break;
				case 'C': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_C); break;
				case 'D': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_D); break;
				case 'E': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_E); break;
				case 'F': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_F); break;
				case 'G': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_G); break;
				case 'H': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_H); break;
				case 'I': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_I); break;
				case 'J': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_J); break;
				case 'K': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_K); break;
				case 'L': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_L); break;
				case 'M': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_M); break;
				case 'N': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_N); break;
				case 'O': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_O); break;
				case 'P': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_P); break;
				case 'Q': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_Q); break;
				case 'R': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_R); break;
				case 'S': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_S); break;
				case 'T': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_T); break;
				case 'U': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_U); break;
				case 'V': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_V); break;
				case 'W': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_W); break;
				case 'X': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_X); break;
				case 'Y': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_Y); break;
				case 'Z': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_Z); break;
				case '`': typeOnePara(KeyEvent.VK_BACK_QUOTE); break;
				case '0': typeOnePara(KeyEvent.VK_0); break;
				case '1': typeOnePara(KeyEvent.VK_1); break;
				case '2': typeOnePara(KeyEvent.VK_2); break;
				case '3': typeOnePara(KeyEvent.VK_3); break;
				case '4': typeOnePara(KeyEvent.VK_4); break;
				case '5': typeOnePara(KeyEvent.VK_5); break;
				case '6': typeOnePara(KeyEvent.VK_6); break;
				case '7': typeOnePara(KeyEvent.VK_7); break;
				case '8': typeOnePara(KeyEvent.VK_8); break;
				case '9': typeOnePara(KeyEvent.VK_9); break;
				case '-': typeOnePara(KeyEvent.VK_MINUS); break;
				case '=': typeOnePara(KeyEvent.VK_EQUALS); break;
				case '~': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_BACK_QUOTE); break;
				case '!': typeOnePara(KeyEvent.VK_EXCLAMATION_MARK); break;
				case '@': typeOnePara(KeyEvent.VK_AT); break;
				case '#': typeOnePara(KeyEvent.VK_NUMBER_SIGN); break;
				case '$': typeOnePara(KeyEvent.VK_DOLLAR); break;
				case '%': typeOnePara(KeyEvent.VK_SHIFT, KeyEvent.VK_5); break;
				case '^': typeOnePara(KeyEvent.VK_CIRCUMFLEX); break;
				case '&': typeOnePara(KeyEvent.VK_AMPERSAND); break;
				case '*': typeOnePara(KeyEvent.VK_ASTERISK); break;
				case '(': typeOnePara(KeyEvent.VK_LEFT_PARENTHESIS); break;
				case ')': typeOnePara(KeyEvent.VK_RIGHT_PARENTHESIS); break;
				case '_': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_MINUS); break;
				case '+': typeOnePara(KeyEvent.VK_PLUS); break;
				case '\t': typeOnePara(KeyEvent.VK_TAB); break;
				case '\n': typeOnePara(KeyEvent.VK_ENTER); break;
				case '[': typeOnePara(KeyEvent.VK_OPEN_BRACKET); break;
				case ']': typeOnePara(KeyEvent.VK_CLOSE_BRACKET); break;
				case '\\': typeOnePara(KeyEvent.VK_BACK_SLASH); break;
				case '{': doType(KeyEvent.VK_SHIFT, KeyEvent. VK_OPEN_BRACKET); break;
				case '}': doType(KeyEvent.VK_SHIFT, KeyEvent. VK_CLOSE_BRACKET); break;
				case '|': doType(KeyEvent.VK_SHIFT, KeyEvent. VK_BACK_SLASH); break;
				case ';': typeOnePara(KeyEvent.VK_SEMICOLON); break;
				case ':': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_SEMICOLON); break;
				case '\'': typeOnePara(KeyEvent.VK_QUOTE); break;
				case '"': typeOnePara(KeyEvent.VK_QUOTEDBL); break;
				case ',': typeOnePara(KeyEvent.VK_COMMA); break;
				case '<': typeOnePara(KeyEvent.VK_LESS); break;
				case '.': typeOnePara(KeyEvent.VK_PERIOD); break;
				case '>': typeOnePara(KeyEvent.VK_GREATER); break;
				case '/': typeOnePara(KeyEvent.VK_SLASH); break;
				case '?': typeTwoPara(KeyEvent.VK_SHIFT, KeyEvent.VK_SLASH); break;
				case ' ': typeOnePara(KeyEvent.VK_SPACE); break;
				default:
					throw new IllegalArgumentException("Cannot type character " + character);
			}
		}

	}


	private typeOnePara(int keyCode){
		Robot robot = new Robot()
		try {
			robot.keyPress(keyCode);
			robot.keyRelease(keyCode);
		} catch(Exception e) {
			System.out.println("Invalid key code(s) for above character");
		}
	}

	private typeTwoPara(int keyCode1, int keyCode2){
		Robot robot = new Robot()
		try {
			robot.keyPress(keyCode1);
			robot.keyPress(keyCode2);
			robot.keyRelease(keyCode2);
			robot.keyRelease(keyCode1);
		} catch(Exception e) {
			System.out.println("Invalid key code(s) for above character");
		}
	}

	/**
	 * to be used for pressing Enter key from keyboard on the PHP Travels application by using Rotbot
	 */
	@Keyword
	def pressEnterByRobot(int timeOut) {
		Robot robot = new Robot()
		try {
			robot.keyPress(KeyEvent.VK_ENTER);
			WebUI.delay(timeOut)
			robot.keyRelease(KeyEvent.VK_ENTER);
			WebUI.delay(timeOut)
		} catch(Exception e) {
			System.out.println("Invalid key code(s) for above character");
		}
	}

	/**
	 * to be used for pressing Tab key from keyboard on the PHP Travels application by using Rotbot
	 */
	@Keyword
	def pressTABByRobot(int timeOut) {
		Robot robot = new Robot()
		try {
			robot.keyPress(KeyEvent.VK_TAB);
			WebUI.delay(timeOut)
			robot.keyRelease(KeyEvent.VK_TAB);
			WebUI.delay(timeOut)
		} catch(Exception e) {
			System.out.println("Invalid key code(s) for above character");
		}
	}

	/**
	 * to be used for pressing Page Down key from keyboard on the PHP Travels application by using Rotbot
	 */
	@Keyword
	def pressNarrowDownByRobot(int timeOut) {
		Robot robot = new Robot()
		try {
			robot.keyPress(KeyEvent.VK_DOWN);
			WebUI.delay(timeOut)
			robot.keyRelease(KeyEvent.VK_DOWN);
			WebUI.delay(timeOut)
		} catch(Exception e) {
			System.out.println("Invalid key code(s) for above character");
		}
	}

	/**
	 * to be used for pressing Page Down key from keyboard on the PHP Travels application by using Rotbot
	 */
	@Keyword
	def pressPageDownByRobot(int timeOut) {
		Robot robot = new Robot()
		try {
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			WebUI.delay(timeOut)
			robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
			WebUI.delay(timeOut)
		} catch(Exception e) {
			System.out.println("Invalid key code(s) for above character");
		}
	}

	/**
	 * to be used for verifying the visible of check box then clicking it on the PHP Travels application
	 */
	@Keyword
	def verifyExistAndChecking(String elementName, int timeOut) {
		//if (WebUI.verifyElementPresent(findTestObject(elementName), timeOut)){
		if (WebUI.waitForElementVisible(findTestObject(elementName), timeOut, FailureHandling.CONTINUE_ON_FAILURE)){
			WebUI.check(findTestObject(elementName))
		}

	}

}
