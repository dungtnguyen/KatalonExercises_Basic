package general_utilities

import org.openqa.selenium.By
import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.interactions.Action
import org.openqa.selenium.interactions.Actions
import com.kms.katalon.core.configuration.RunConfiguration
import static org.testng.reporters.Files.readFile

import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.webui.common.WebUiCommonHelper

import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.testobject.TestObject as TestObject
//import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.model.FailureHandling as FailureHandling

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.driver.WebUIDriverType
import org.openqa.selenium.Keys as Keys
import java.awt.Robot
import java.awt.event.KeyEvent
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import java.util.Random
import org.openqa.selenium.support.Color

/*
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 The function list and meanings:
 1. selectSubMenuItemInlevelOneAndVerifyOpeningPage(String mainMenuName, String menuItemName, String nextTitlePage, int timeOut)
 to be used for selecting main menu then sub menu item then verify that the relevant page is opened.
 2. inputUsernameAndPasswordPressingButton(String userName, String userNameData, String passwordName, String passData, String buttonName, int timeOut):
 to be used for verifying and inputting the email of a User name, password then pressing the Login button
 3. verifyElementTextAndRelevantIcon(String elementName, String expText, String iconObjName, int timeOut):
 to be used for verifying the text of element and its relevant icon
 4. getAttributeAndVerify(String elementName, String attrName, String expAttr):
 to be used for getting the attribute of element and verifying it with expectation attribute			
 5. getTextAndVerify(String elementName, String expText, int timeOut):
 to be used for getting the text of element and verifying it with expectation text
 6. verifyExistAndClicking(String elementName, int timeOut):
 to be used for verifying the visible of element then clicking it 		
 7. modifyAttributeWebElemntAndClicking(String xpathValue):
 to be used for modifying the attribute of web element and then clicking it		
 8. clickHyperlinkTextAndVerifyTitleOfPage(String linkTestObject, String pageTitleTestObject, String expPageTitle, int waitTime):)
 to be used for clicking the hyperlink text and then verifying the relevant page title
 9	countAllItemsInPageList(int expValue):
 to be used for counting all items in the page list and return the number of item
 10. countAllItemsInPageAndClickAnItemUnderRandom(String xPathName, String objName):
 to be used for counting all items in the page list and then selecting an item in random then clicking on it		
 11. movingMouseOverOverTestObjectAndVerifyOtherObjExisting(String firstObjName, String secondObjName, int timeOut):
 to be used for moving the mouse over a test object and verify that other object is  displayed		
 12.	clickonTestObjectAndVerifyOtherObjExisting(String firstObjName, String secondObjName, int timeOut):
 to be used for moving the mouse over a test object and verify that other object is  displayed
 */
public class Specified_utilities {

	/**
	 * to be used for selecting main menu then sub menu item on the PHP Travels application then verify that 
	 * the relevant page is opened.
	 */
	@Keyword
	def selectSubMenuItemInlevelOneAndVerifyOpeningPage(String mainMenuName, String menuItemName, String nextTitlePage, int timeOut) {

		WebUI.waitForElementVisible(findTestObject(mainMenuName), timeOut)
		WebUI.click(findTestObject(mainMenuName))

		WebUI.waitForElementVisible(findTestObject(menuItemName), timeOut)
		WebUI.click(findTestObject(menuItemName))

		WebUI.waitForElementVisible(findTestObject(nextTitlePage), timeOut)
	}

	/**
	 * to be used for verifying and inputting the email of a User name, password then pressing the Login button on the PHP Travels application
	 */
	@Keyword
	def inputUsernameAndPasswordPressingButton(String userName, String userNameData, String passwordName, String passData, String buttonName, int timeOut) {

		WebUI.waitForElementVisible(findTestObject(userName), timeOut)
		WebUI.setText(findTestObject(userName), userNameData)

		WebUI.waitForElementVisible(findTestObject(passwordName), timeOut)
		WebUI.setText(findTestObject(passwordName), passData)

		WebUI.waitForElementVisible(findTestObject(buttonName), timeOut)
		WebUI.sendKeys(findTestObject(buttonName), Keys.chord(Keys.ENTER))
		//WebUI.click(findTestObject(buttonName))
	}

	/**
	 * to be used for verifying the text of element and its relevant icon on the PHP Travels application
	 */
	@Keyword
	def verifyElementTextAndRelevantIcon(String elementName, String expText, String iconObjName, int timeOut) {

		WebUI.waitForElementVisible(findTestObject(elementName), timeOut)
		String actText = WebUI.getText(findTestObject(elementName))
		WebUI.verifyEqual(actText, expText)

		WebUI.verifyElementPresent(findTestObject(iconObjName), timeOut)
	}

	/**
	 * to be used for getting the attribute of element and verifying it with expectation attribute on the PHP Travels application
	 */
	@Keyword
	def getAttributeAndVerify(String elementName, String attrName, String expAttr) {

		'Get an attribute value of the identified element'
		String actAttr = WebUI.getAttribute(findTestObject(elementName), attrName)

		KeywordLogger log = new KeywordLogger()
		log.logInfo('The attribute value of User: ' + actAttr)

		'Verify actual attribute value is correct the expectation'
		WebUI.verifyEqual(actAttr, expAttr)
	}

	/**
	 * to be used for getting the text of element and verifying it with expectation text on the PHP Travels application
	 */
	@Keyword
	def getTextAndVerify(String elementName, String expText, int timeOut) {
		WebUI.waitForElementVisible(findTestObject(elementName), timeOut)
		String actText = WebUI.getText(findTestObject(elementName))
		WebUI.verifyEqual(actText.trim(), expText)


	}

	/**
	 * to be used for verifying the visible of element then clicking it on the PHP Travels application
	 */
	@Keyword
	def verifyExistAndClicking(String elementName, int timeOut) {
		WebUI.verifyElementPresent(findTestObject(elementName), timeOut)
		WebUI.click(findTestObject(elementName))
	}

	/**
	 * to be used for modifying the attribute of web element and then clicking it on the PHP Travels application
	 */
	@Keyword
	def modifyAttributeWebElemntAndClicking(String xpathValue) {
		'Modify property: \'xpath\' of \'PriceRange\' Object and click on it'
		WebDriver driver = DriverFactory.getWebDriver()
		JavascriptExecutor js = (JavascriptExecutor) driver;

		//WebElement new_PriceRange = driver.findElement(By.xpath("//div[@class=\'slider-track\']/div[@class=\'slider-handle round\'][@style=\'left: 100%;\']"));
		WebElement new_PriceRange = driver.findElement(By.xpath(xpathValue));
		js.executeScript("arguments[0].setAttribute('style', 'left: 60%;')",new_PriceRange);


	}

	/**
	 * to be used for clicking the hyperlink text and then verifying the relevant page title on the PHP Travels application
	 */
	@Keyword
	public boolean clickHyperlinkTextAndVerifyTitleOfPage(String linkTestObject, String pageTitleTestObject, String expPageTitle, int waitTime){
		boolean returnValue = true

		returnValue = WebUI.verifyElementPresent(findTestObject(linkTestObject), waitTime)
		if(returnValue){
			WebUI.click(findTestObject(linkTestObject))

			'Wait and verify the header title of page is displayed '
			String Act_pageTitle = WebUI.getText(findTestObject(pageTitleTestObject))
			returnValue = WebUI.verifyEqual(Act_pageTitle, expPageTitle)
			return returnValue

		} else {
			return false
		}

	}

	/**
	 * to be used for counting all items in the page list on the PHP Travels application and return the number of item 
	 */
	@Keyword
	def countAllItemsInPageList(int expValue) {

		WebDriver driver = DriverFactory.getWebDriver()
		KeywordLogger log = new KeywordLogger()

		'Get all items in the displayed page'
		int myCount = driver.findElements(By.xpath("//div[@class='panel-body']/div[@class='col-md-4 go-right']/div[@class='row']/a/img[@src]")).size();
		log.logInfo("The value of displayed page is : " + myCount)

		if (expValue > 5){
			'Get total page if any'
			int myFooterPageCount = driver.findElements(By.xpath("//ul[@class='nav nav-pills nav-justified'][@role='tablist']/li/a[@href]")).size();


			for(int j=2;j<=myFooterPageCount-2;j++){
				'Change the attribute: xpath before clicking the new tbl_PageFoote.'
				String localvar_XpathFooterPage = "(//ul[@class='nav nav-pills nav-justified'][@role='tablist']/li/a[@href])[" + (j+1).toString() + "]"

				'Modify property: \'xpath\' of \'tbl_PageFooter\' and get per pickup'
				TestObject new_tbl_PageFooter = WebUI.modifyObjectProperty(findTestObject('Repo_WebUI_Advance/Page_Blog/tbl_PageFooter'), 'xpath', 'equals', localvar_XpathFooterPage, true)

				'Click on the next page'
				WebUI.click(new_tbl_PageFooter)
				WebUI.delay(GlobalVariable.gl_objectWait5)

				'Count the current page which just clicked before'
				int myCountNextPage = driver.findElements(By.xpath("//div[@class='panel-body']/div[@class='col-md-4 go-right']/div[@class='row']/a/img[@src]")).size();
				myCount = myCount + myCountNextPage
				log.logInfo("The  updated value of total item is : " + myCount)
			}
		}
		return myCount
	}



	/**
	 * to be used for counting all items in the page list on the PHP Travels application and then selecting an item in random then clicking on it
	 */
	@Keyword
	def countAllItemsInPageAndClickAnItemUnderRandom(String xPathName, String objName) {

		WebDriver driver = DriverFactory.getWebDriver()
		KeywordLogger log = new KeywordLogger()

		'Get all items in the displayed page'
		int myCount = driver.findElements(By.xpath(xPathName)).size();
		log.logInfo("The value of displayed page is : " + myCount)

		if (myCount > 0){
			'Creating a value by generating under random '
			Random rnd = new Random()
			int RandomValue = rnd.nextInt(myCount)

			'Creating an Xpath for this object'
			String localvar_Xpath = "(" + xPathName + ")[" + RandomValue.toString() + "]"

			'Modify property: \'xpath\' of \'tbl_PageFooter\' and get per pickup'
			TestObject new_TextObject = WebUI.modifyObjectProperty(findTestObject(objName), 'xpath', 'equals', localvar_Xpath, true)

			'Click on the next page'
			WebUI.click(new_TextObject)
			WebUI.delay(GlobalVariable.gl_objectWait5)
		}
	}

	/**
	 * to be used for moving the mouse over a test object and verify that other object is  displayed on the PHP Travels application
	 */
	@Keyword
	def movingMouseOverOverTestObjectAndVerifyOtherObjExisting(String firstObjName, String secondObjName, int timeOut) {
		WebUI.verifyElementPresent(findTestObject(firstObjName), timeOut)
		WebUI.mouseOverOffset(findTestObject(firstObjName), 20,30)

		WebUI.verifyElementPresent(findTestObject(secondObjName), timeOut)
	}

	/**
	 * to be used for clicking on test object and verify that other object is  displayed on the PHP Travels application
	 */
	@Keyword
	def clickonTestObjectAndVerifyOtherObjExisting(String firstObjName, String secondObjName, int timeOut) {
		WebUI.verifyElementPresent(findTestObject(firstObjName), timeOut)
		WebUI.click(findTestObject(firstObjName))
		WebUI.delay(timeOut)
		WebUI.click(findTestObject(firstObjName))

		WebUI.verifyElementPresent(findTestObject(secondObjName), timeOut)
	}

	/**
	 * to be used for clicking on test object and verify that other object is  displayed on the PHP Travels application
	 */
	@Keyword
	def verifyBackgroundColorOfTestObjectExisting(String firstObjName, String expColor) {

		'Get the color of the test object'
		String var_returnBgColor = WebUI.getCSSValue(findTestObject(firstObjName), 'background-color')

		'Chang the gotten value to Hex and compare with expected color'
		String act_HexColor = Color.fromString(var_returnBgColor).asHex()
		WebUI.verifyEqual(act_HexColor, expColor)
	}
}
