<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>WebUI_AdvancedTestSuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>674e91bb-dfb3-4457-8106-6810b2817f4f</testSuiteGuid>
   <testCaseLink>
      <guid>1f1ab954-335c-4336-936a-7c9f59209c9c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/BE-01_Login_LoginAmin_to_page_successful</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1be83ab2-eb32-4d74-a802-3348578fd46c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/BE-02_Login_Login_to_page_unsuccessful</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0ca1db3b-856f-49f0-bea6-c38995392cb5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/BE-03_Hotels_Navigate_to_subitem_of_Hotels</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7c45b323-7426-4624-9222-0fb1ed869555</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/BE-04_Hotels_Create_a_new_hotel_successful</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8a87212c-c9c2-4f48-8e83-c1a809a6a92a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/BE-05_Hotels_Modify_Hotel_Information</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d5b2eee5-a1b8-4d4b-96f5-f93e6abb220f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/BE-06_Hotels_Upload_gallery</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>152adcc8-7999-47f7-993f-23624a63aea6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/BE-07_Hotels_Delete_Hotels_by_icon</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d59971d9-595a-4020-af80-59668fd2ed88</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/BE-08_Hotels_Delete_Hotels_by_Delete_Selected_button</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>56be4933-e4ca-4000-98ed-a3bda48de14a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/BE-09_Hotels_Search_hotel_by_Name</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2f79e90e-2cbc-486a-9d30-e6bf4f07b171</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/BE-10_Hotels_Sort_hotel</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
