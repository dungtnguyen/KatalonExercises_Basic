<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>WebUI_BasicTestSuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>6977a439-f2d5-46ef-900d-39d8b6665b29</testSuiteGuid>
   <testCaseLink>
      <guid>9eb47b2a-d422-4107-a5d0-efa2494168c9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Basic/UIB-01_Verify_Checkboxes</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>23d2dda9-76b7-4f7b-8619-7be7647ae42d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Basic/UIB-11_Verify_Table</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1a277242-8647-4620-8500-6e3db1805bd0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Basic/UIB-02_Verify_Drag_and_Drop</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8bc38db2-b701-4493-a7f4-dfcab8c4a89e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Basic/UIB-03_Verify_Dropdown</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>be3562a9-e431-4642-ad8e-5b83aa463710</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Basic/UIB-04-Verify_File_Upload</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>e7d2671f-967b-4f4a-aa57-24e7b943bc0e</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>500943bc-d56e-4d69-8ef9-ae85533c597c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Basic/UIB-05_Verify_Frames</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>33739d0a-eb64-4930-a4aa-9c1d80522ae4</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>f5b727ea-972d-4420-976a-77ff9c9079e0</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>c0ca968c-f295-48f0-b5f3-596ce3ea903c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Basic/UIB-06_Verify_Alerts</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>be06b90f-252c-4281-8ce6-217feb0f9db5</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>7c6e8ca9-8f93-41a6-892c-99eb29a22594</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Basic/UIB-07_Verify_Key_Presses</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e6bbe5e2-d7af-4034-b609-affcea86d430</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Basic/UIB-08-Verify_Color_and_Font</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f624a958-326c-4830-b67d-36cac002223c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Basic/UIB-09_Verify_Slider</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7f79b79b-cf3b-4a26-a95a-5c901867b8a4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Basic/UIB-10_Verify_Menu</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
