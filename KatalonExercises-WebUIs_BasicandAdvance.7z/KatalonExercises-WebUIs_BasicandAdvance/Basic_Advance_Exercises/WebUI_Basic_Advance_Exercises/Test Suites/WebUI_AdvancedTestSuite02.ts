<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>WebUI_AdvancedTestSuite02</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>02110ad8-f3b6-44ac-ae39-520ca17331cd</testSuiteGuid>
   <testCaseLink>
      <guid>39932f73-565f-428c-adbe-dcdf5754481f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/FE-01_Login_Login_sucessful</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>98bb909b-265c-4282-a290-4ffa28082c78</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/FE-02_Tours_Verify_Tours_Filter</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>88c99814-cf5f-4ae4-921c-e008488f8c55</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/FE-03_Cars_Verify_Cars_Filter</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f9444f94-6a0b-4626-8b8b-18a36f783c7e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/FE-06_Blog_Verify_Categories_and_Posts</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6a412b63-6b84-4d65-9b0f-eba9fcc2dc6d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/FE-07_Offers_Verify_maximize_image</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d65305a7-2ad6-4728-86a2-8ae08e959317</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/WebUI_Advance/FE-10_Booking_Verify_Invoice_Booking_details</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
