import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.TearDown
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import general_utilities.CommonLib

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: UIB-05 - Verify Frames
//	Description Details:
//	Actions:
//	1	"Go to https://the-internet.herokuapp.com/
//		Select 'WYSIWYG Editor' link"
//	2	Verify the deafult content
//	3	Set new content "Hello, how are you?"
//
//	Expected Results:
//	1	An iFrame containing the TinyMCE WYSIWYG Editor title is displayed
//	2	The deafult content body is 'Your content goes here.'
//	3	The content body is 'Hello, how are you?'
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////

'Step 1: Open Browser and Go to https://the-internet.herokuapp.com/, click on the hyperlink: WYSIWYG Editor and verify that the page: WYSIWYG Editor Page is displayed'
CustomKeywords.'general_utilities.CommonLib.openHomePage'(GlobalVariable.gl_Url)
CustomKeywords.'general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle'('Repo_WebUI_Basic/MainPage/lnk_WYSIWYG_Editor', 'Repo_WebUI_Basic/WYSIWYGEditorPage/lbl_WYSIWYG_Editor_header', GlobalVariable.gl_objectWait)

'Step 2: Verify the default content body is: Your content goes here.'
WebUI.switchToFrame(findTestObject('Repo_WebUI_Basic/WYSIWYGEditorPage/ifr_WYSIWYGEditor'), GlobalVariable.gl_objectWait)
WebUI.verifyTextPresent(localvar_iFrameDefaultValue, false)


'Step 3: Set new content "Hello, how are you?" and verify that the content body is Hello, how are you?'
CustomKeywords.'general_utilities.CommonLib.setTextForIframeAndVerify'('Repo_WebUI_Basic/WYSIWYGEditorPage/ifr_WYSIWYGEditoe_TextArea', localvar_iFrameNewValue, GlobalVariable.gl_objectWait)
