import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.support.Color

/*
 TC Name: BE-10-Hotels-Sort hotel
 Description Details:
 Actions:
	 1	Navigate and login as Admin to page https://www.phptravels.net/admin/hotels
	 2	Click on 'Name' column
	 3	Click on 'Name' column
	 4	Click on 'Location' column
	 5	Click on 'Location' column

 Expected Results:
	 2	The Hotel name sort by alphabetical from Z-A
	 3	The Hotel name sort by alphabetical from A-Z
	 4	The Hotel location sort by alphabetical from Z-A
	 5	The Hotel location sort by alphabetical from A-Z

*/

'Step 1:Navigate and login as Admin to page https://www.phptravels.net/admin/hotels'
CustomKeywords.'general_utilities.CommonLib.openHomePage'('https://www.phptravels.net/admin')

CustomKeywords.'general_utilities.Specified_utilities.inputUsernameAndPasswordPressingButton'('Repo_WebUI_Advance/Page_Admin/txt_Email',
	GlobalVariable.gl_AdminEmail, 'Repo_WebUI_Advance/Page_Admin/txt_Password', GlobalVariable.gl_AdminPass, 'Repo_WebUI_Advance/Page_Admin/btn_Login',
	GlobalVariable.gl_objectWait)

'Setting Hotel Modules is enable by clicking the Module --> Hotel -->Enable'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Modules',
	GlobalVariable.gl_objectWait)

CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_PrimaryModules/btn_HotelModules',
	GlobalVariable.gl_objectWait)

CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_PrimaryModules/Confirm_Dlg/btn_Yes',
	GlobalVariable.gl_objectWait)

WebUI.delay(GlobalVariable.gl_objectWait2)

'Click on \'HOTELS\' of Menu bar on the left side of the screen'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Hotels',
	GlobalVariable.gl_objectWait)

'Verify the page: Hotels Management is displayed'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_HotelsMenu/mnuitem_Hotels',
	GlobalVariable.gl_objectWait)

WebUI.verifyElementPresent(findTestObject('Repo_WebUI_Advance/Page_Hotels_Mgt/header_Hotels_Mgt', [('headerNamePara') : 'Hotels Management']),
	GlobalVariable.gl_objectWait)

'Step 2: Click on the column: Name and verify that The Hotel name is sorted by alphabetical from Z-A'
'Click on the header column: Name'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_Hotels_Mgt/tbl_NameHeader', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)

'Verify The Hotel name is sorted by alphabetical from Z-A'
CustomKeywords.'general_utilities.CommonLib.verifySpecificColSorted'(findTestObject('Repo_WebUI_Advance/Page_Hotels_Mgt/tbl_TableBody'), "3")

WebUI.delay(GlobalVariable.gl_objectWait2)

'Step 3: Click on the column: Name and verify that The Hotel name is sorted by alphabetical from A-Z'
'Click on the header column: Name'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_Hotels_Mgt/tbl_NameHeader_Desc', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)

'The Hotel name is sorted by alphabetical from A-Z'
CustomKeywords.'general_utilities.CommonLib.verifySpecificColSorted'(findTestObject('Repo_WebUI_Advance/Page_Hotels_Mgt/tbl_TableBody'), "3")

'Step 4: Click on the column: Location and verify that The Country name is sorted by alphabetical from Z-A'
'Click on the header column: Location'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_Hotels_Mgt/tbl_LocationHeader', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)

'The Country name is sorted by alphabetical from Z-A'
CustomKeywords.'general_utilities.CommonLib.verifySpecificColSorted'(findTestObject('Repo_WebUI_Advance/Page_Hotels_Mgt/tbl_TableBody'), "5")

'Step 5: Click on the column: Location and verify that The Country name is sorted by alphabetical from A-Z'
'Click on the header column: Location'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_Hotels_Mgt/tbl_LocationHeader_Asc', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)

'The Country name is sorted by alphabetical from A-Z'
CustomKeywords.'general_utilities.CommonLib.verifySpecificColSorted'(findTestObject('Repo_WebUI_Advance/Page_Hotels_Mgt/tbl_TableBody'), "6")
