import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.support.Color

'Step 1: Go to https://www.phptravels.net/admin'
CustomKeywords.'general_utilities.CommonLib.openHomePage'('https://www.phptravels.net/admin')

'\'Step 2: Input to Email and Password text-boxes. Ex: admin@phptravels.com/demoadmin\'\r\nStep 3: Click on the button: LOGIN '
CustomKeywords.'general_utilities.Specified_utilities.inputUsernameAndPasswordPressingButton'('Repo_WebUI_Advance/Page_Admin/txt_Email', GlobalVariable.gl_AdminEmail, 'Repo_WebUI_Advance/Page_Admin/txt_Password', GlobalVariable.gl_AdminPass, 'Repo_WebUI_Advance/Page_Admin/btn_Login', GlobalVariable.gl_objectWait)

'Verify that Login successful. The page has:\r\n- \'First name + Last name\'of Account displays on the left menu bar. Ex: \'Super Admin Admin\'.\r\n- 6 buttons: \r\n   + \'QUICK BOOKING\' has red color\r\n   +\'BOOKINGS\' has blue color\r\n   +\'CMS PAGES\' has  light-blue color\r\n   +\'BLOG\' has green color\r\n   +\'SEND NEWSLETTER\' has yellow color\r\n   +\'BACKUP DATABASE\' has white color\r\n- 4 Sessions:\r\n   +\'BOOKING SUMMARY\'\r\n   +\'REVENUE CHART\'\r\n   +\'RECENT BOOKINGS\'\r\n   +\'VISIT STATISTICS OF <MONTH>\''
'First name + Last nameof Account displays on the left menu bar. Ex: Super Admin Admin'
WebUI.verifyElementVisible(findTestObject('Repo_WebUI_Advance/Page_AdminProfile/lbl_UserProfile'))

'verify that the button: QUICK BOOKING has red color'
CustomKeywords.'general_utilities.Specified_utilities.verifyBackgroundColorOfTestObjectExisting'('Repo_WebUI_Advance/Page_AdminProfile/btn_QUICKBOOK', '#ee5f5b')

'verify that the button: BOOKINGS has blue color'
CustomKeywords.'general_utilities.Specified_utilities.verifyBackgroundColorOfTestObjectExisting'('Repo_WebUI_Advance/Page_AdminProfile/btn_BOOKINGS', '#466df1')

'verify that the button: CMS PAGES has  light-blue color'
CustomKeywords.'general_utilities.Specified_utilities.verifyBackgroundColorOfTestObjectExisting'('Repo_WebUI_Advance/Page_AdminProfile/btn_CMS_PAGES', '#5bc0de')

'verify that the button: BLOG has green color'
CustomKeywords.'general_utilities.Specified_utilities.verifyBackgroundColorOfTestObjectExisting'('Repo_WebUI_Advance/Page_AdminProfile/btn_BLOG', '#62c462')

'verify that the button: SEND NEWSLETTER has yellow color'
CustomKeywords.'general_utilities.Specified_utilities.verifyBackgroundColorOfTestObjectExisting'('Repo_WebUI_Advance/Page_AdminProfile/btn_NEWSLETTER', '#fbb450')

'verify that the button: BACKUP DATABASE has white color'
CustomKeywords.'general_utilities.Specified_utilities.verifyBackgroundColorOfTestObjectExisting'('Repo_WebUI_Advance/Page_AdminProfile/btn_BACKUP', '#ffffff')

'4 Sessions: BOOKING SUMMARY, REVENUE CHART, RECENT BOOKINGS, VISIT STATISTICS OF <MONTH>'
WebUI.verifyElementVisible(findTestObject('Repo_WebUI_Advance/Page_AdminProfile/lbl_BookingSummary'))
WebUI.verifyElementVisible(findTestObject('Repo_WebUI_Advance/Page_AdminProfile/lbl_RevenueChart'))
WebUI.verifyElementVisible(findTestObject('Repo_WebUI_Advance/Page_AdminProfile/lbl_RecentBookings'))
WebUI.verifyElementVisible(findTestObject('Repo_WebUI_Advance/Page_AdminProfile/lbl_VisitStatisticsOf'))