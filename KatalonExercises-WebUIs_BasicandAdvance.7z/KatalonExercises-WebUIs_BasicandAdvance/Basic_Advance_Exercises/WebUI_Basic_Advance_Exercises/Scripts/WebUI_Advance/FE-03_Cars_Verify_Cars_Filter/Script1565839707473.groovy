import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import java.awt.Robot as Robot
import java.awt.event.KeyEvent as KeyEvent
import org.openqa.selenium.By as By
import org.openqa.selenium.JavascriptExecutor as JavascriptExecutor
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.interactions.Action as Action
import org.openqa.selenium.interactions.Actions as Actions
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import org.openqa.selenium.support.Color


'Step 1: Navigate to url \'https://www.phptravels.net/\''
CustomKeywords.'general_utilities.CommonLib.openHomePage'('https://www.phptravels.net/cars')

'Step 2: Filter Search:\r\n+ Star grade : 4/5\r\n+ Airport Pickup: Yes\r\nClicking on \'SEARCH\' button'
'Star grade : 4/5'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_CarsListings/opt_StarGrade', 
    GlobalVariable.gl_objectWait)

'+ Airport Pickup: Yes'
Robot robot = new Robot()

robot.keyPress(KeyEvent.VK_PAGE_DOWN)

WebUI.delay(GlobalVariable.gl_objectWait2)

WebUI.selectOptionByValue(findTestObject('Repo_WebUI_Advance/Page_CarsListings/lst_AirportPickup'), 'yes', true)

'Clicking on the button: SEARCH'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_CarsListings/button_Search', 
    GlobalVariable.gl_objectWait)

'Verify all of Cars list: + Airport Pickup displays for each Casr with green backgourd-color'
WebDriver driver = DriverFactory.getWebDriver()
KeywordLogger log = new KeywordLogger()

int localvar_myCount = driver.findElements(By.xpath("//table[@class='bgwhite table table-striped']/tbody/tr/td/div[@class='col-md-6 col-xs-4 go-right']/div[@class='row']/h4/button[@class='btn btn-success btn-xs']")).size();
//log.logInfo("The value of localvar_myCount is : " + localvar_myCount)

if (localvar_myCount !=0){
	for(int j=1;j<=localvar_myCount;j++){		
		'Change the attribute: xpath before getting the background value.'
		String localvar_PickupList = "(//table[@class='bgwhite table table-striped']/tbody/tr/td/div[@class='col-md-6 col-xs-4 go-right']/div[@class='row']/h4/button[@class='btn btn-success btn-xs'])[" + j.toString() + "]"
		//log.logInfo("The number of Pickup List is : " + localvar_PickupList)
		
		'Modify property: \'xpath\' of \'Pickup List\' and get per pickup'
		TestObject new_emailList = WebUI.modifyObjectProperty(findTestObject('Repo_WebUI_Advance/Page_CarsSearchResults/btn_AirportPickup'), 'xpath', 'equals', localvar_PickupList, true)
		String var_returnBgColor = WebUI.getCSSValue(findTestObject('Repo_WebUI_Advance/Page_CarsSearchResults/btn_AirportPickup'), 'background-color')
		 
		//log.logInfo("The value of var_returnBgColor is : " + var_returnBgColor)
		
		'Verify the green backgourd-color for each button'
		String var_Hex = Color.fromString(var_returnBgColor).asHex()
		WebUI.verifyEqual(var_Hex, '#5cb85c')
	 }
 }else{
 	log.logWarning("There is no any Pickup based on the searched criteria.")
 }

