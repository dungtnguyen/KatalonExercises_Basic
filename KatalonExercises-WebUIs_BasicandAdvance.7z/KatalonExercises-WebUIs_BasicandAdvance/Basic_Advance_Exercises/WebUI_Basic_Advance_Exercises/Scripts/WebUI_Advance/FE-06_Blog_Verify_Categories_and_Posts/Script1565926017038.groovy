import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

/*
 TC Name: FE-06-Blog - Verify Categories and Posts
 Description Details:
 Actions:
	 1	Navigate to url 'https://www.phptravels.net/blog'
	 2	Clicking on Travel and Foods item under Categories and Posts section
	 3	Clicking on  Adventure item under Categories and Posts section
	 4	Clicking on Shopping and Fashion item under Categories and Posts section
	 5	Clicking on Things to do item under Categories and Posts section

 Expected Results:
	 1	Heading title is 'Latest Posts'
	 2	"+ Heading title is 'Posts from category - Travel and Foods'
		 + Total Post items are match with number of Travel and Foods"
	 3	"+ Heading title is 'Posts from category - Adventure'
		 + Total Post items are match with number of Adventure"
	 4	"+ Heading title is 'Posts from category - Shopping and Fashion'
		 + Total Post items are match with number of Shopping and Fashion"
	 5	"+ Heading title is 'Posts from category - Things to do'
		 + Total Post items are match with number of Things to do"
*/

'Step 1: Navigate to url \'https://www.phptravels.net/ and verify that Heading title is Latest Posts'
CustomKeywords.'general_utilities.CommonLib.openHomePage'('https://www.phptravels.net/blog')

'Verify that Heading title is Latest Posts'
String Act_TitlePage = WebUI.getText(findTestObject('Repo_WebUI_Advance/Page_Blog/lbl_Heading_title'))
WebUI.verifyEqual(Act_TitlePage, 'LATEST POSTS')

'Step 2: Clicking on Travel and Foods item under Categories and Posts section and verify that \'+ Heading title is \'Posts from category - Travel and Foods\'\r\n+ Total Post items are match with number of Travel and Foods'
CustomKeywords.'general_utilities.Specified_utilities.clickHyperlinkTextAndVerifyTitleOfPage'('Repo_WebUI_Advance/Page_Blog/lnk_Travel_and_Foods', 'Repo_WebUI_Advance/Page_Blog/lbl_Heading_title', 'POSTS FROM CATEGORY - TRAVEL AND FOODS', GlobalVariable.gl_objectWait5)

'Get the number of item of the Travels and Foods'
String Exp_Value = WebUI.getText(findTestObject('Repo_WebUI_Advance/Page_Blog/lbl_Total_of_TravelandFoods'))

'Get the number of item of the posts from category - Travels and Foods'
int Act_Value = CustomKeywords.'general_utilities.Specified_utilities.countAllItemsInPageList'(Integer.parseInt(Exp_Value))

'Compare Total Post items are match with number of Travels and Foods'
WebUI.verifyEqual(Act_Value, Exp_Value.toString())


'Step 3: Clicking on  Adventure item under Categories and Posts section and verify that \'+ Heading title is \'Posts from category - Adventure\'\r\n+ Total Post items are match with number of Adventure'
CustomKeywords.'general_utilities.Specified_utilities.clickHyperlinkTextAndVerifyTitleOfPage'('Repo_WebUI_Advance/Page_Blog/lnk_Adventure', 'Repo_WebUI_Advance/Page_Blog/lbl_Heading_title', 'POSTS FROM CATEGORY - ADVENTURE', GlobalVariable.gl_objectWait5)
'Get the number of item of the Adventure'
Exp_Value = WebUI.getText(findTestObject('Repo_WebUI_Advance/Page_Blog/lbl_Total_of_Adventure'))

'Get the number of item of the posts from category - Adventure'
Act_Value = CustomKeywords.'general_utilities.Specified_utilities.countAllItemsInPageList'(Integer.parseInt(Exp_Value))

'Compare Total Post items are match with number of Adventure'
WebUI.verifyEqual(Act_Value, Exp_Value.toString())


'Step 4: Clicking on Shopping and Fashion item under Categories and Posts section and verify that \'+ Heading title is \'Posts from category - Shopping and Fashion\'\r\n+ Total Post items are match with number of Shopping and Fashion'
CustomKeywords.'general_utilities.Specified_utilities.clickHyperlinkTextAndVerifyTitleOfPage'('Repo_WebUI_Advance/Page_Blog/lnk_Shopping_and_Fashion', 'Repo_WebUI_Advance/Page_Blog/lbl_Heading_title', 'POSTS FROM CATEGORY - SHOPPING AND FASHION', GlobalVariable.gl_objectWait5)

'Get the number of item of the Shopping and Fashion'
Exp_Value = WebUI.getText(findTestObject('Repo_WebUI_Advance/Page_Blog/lbl_Total_of_ShoppingandFashion'))

'Get the number of item of the posts from category - Shopping and Fashion'
Act_Value = CustomKeywords.'general_utilities.Specified_utilities.countAllItemsInPageList'(Integer.parseInt(Exp_Value))

'Compare Total Post items are match with number of Shopping and Fashion'
WebUI.verifyEqual(Act_Value, Exp_Value.toString())


'Step 5: Clicking on Things to do item under Categories and Posts section and verify that \'+ Heading title is \'Posts from category - Things to do\'\r\n+ Total Post items are match with number of Things to do'
CustomKeywords.'general_utilities.Specified_utilities.clickHyperlinkTextAndVerifyTitleOfPage'('Repo_WebUI_Advance/Page_Blog/lnk_Things_to_do', 'Repo_WebUI_Advance/Page_Blog/lbl_Heading_title', 'POSTS FROM CATEGORY - THINGS TO DO', GlobalVariable.gl_objectWait5)

'Get the number of item of the Things to Do'
Exp_Value = WebUI.getText(findTestObject('Repo_WebUI_Advance/Page_Blog/lbl_Total_of_ThingstoDo'))

'Get the number of item of the posts from category - Things to do'
Act_Value = CustomKeywords.'general_utilities.Specified_utilities.countAllItemsInPageList'(Integer.parseInt(Exp_Value))

'Compare Total Post items are match with number of Things to do'
WebUI.verifyEqual(Act_Value, Exp_Value.toString())

