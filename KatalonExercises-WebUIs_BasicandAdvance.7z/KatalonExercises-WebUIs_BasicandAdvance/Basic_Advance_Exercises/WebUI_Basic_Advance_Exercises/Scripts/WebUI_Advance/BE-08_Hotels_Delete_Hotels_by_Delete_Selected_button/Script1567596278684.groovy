import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.support.Color as Color
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.interactions.Action as Action
import org.openqa.selenium.interactions.Actions as Actions
import org.openqa.selenium.By as By
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import org.openqa.selenium.Keys as Keys
import java.awt.Robot as Robot
import java.awt.event.KeyEvent as KeyEvent

/*
 TC Name: BE-08-Hotels-Delete Hotels by Delete Selected button
 Description Details:
 Actions:
	 1	Navigate and login as Admin to page https://www.phptravels.net/admin/hotels
	 2	Create a new hotel like BE-04
	 3	"Check on the created hotel
		 Click on 'Delete Seleted' button"
	 4	Click on 'OK' button on Confirm Delete

 Expected Results:
	 4	Delete Successful.
		 Verify the Hotel is deleted on list.
*/

'Step 1:Navigate and login as Admin to page https://www.phptravels.net/admin/hotels'
CustomKeywords.'general_utilities.CommonLib.openHomePage'('https://www.phptravels.net/admin')

CustomKeywords.'general_utilities.Specified_utilities.inputUsernameAndPasswordPressingButton'('Repo_WebUI_Advance/Page_Admin/txt_Email', 
    GlobalVariable.gl_AdminEmail, 'Repo_WebUI_Advance/Page_Admin/txt_Password', GlobalVariable.gl_AdminPass, 'Repo_WebUI_Advance/Page_Admin/btn_Login', 
    GlobalVariable.gl_objectWait)

'Setting Hotel Modules is enable by clicking the Module --> Hotel -->Enable'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Modules', 
    GlobalVariable.gl_objectWait)

CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_PrimaryModules/btn_HotelModules', 
    GlobalVariable.gl_objectWait)

CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_PrimaryModules/Confirm_Dlg/btn_Yes', 
    GlobalVariable.gl_objectWait)

WebUI.delay(GlobalVariable.gl_objectWait2)

'Click on \'HOTELS\' of Menu bar on the left side of the screen'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Hotels', GlobalVariable.gl_objectWait)

'Verify the page: Hotels Management is displayed'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_HotelsMenu/mnuitem_Hotels', 
    GlobalVariable.gl_objectWait)

WebUI.verifyElementPresent(findTestObject('Repo_WebUI_Advance/Page_Hotels_Mgt/header_Hotels_Mgt', [('headerNamePara') : 'Hotels Management']), 
    GlobalVariable.gl_objectWait)

'Step 2: Create a new hotel like BE-04'
WebUI.callTestCase(findTestCase('WebUI_Advance/CommonTCs/CommonTC_BE_Create_a_new_hotel_like_BE_04'), [:], FailureHandling.STOP_ON_FAILURE)

'Step 3: Check on the created hotel and Click on the button: Delete for the created hotel row'

'Check on the created hotel'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_Hotels_Mgt/chk_DeleteHotel', GlobalVariable.gl_objectWait2)
WebUI.delay(GlobalVariable.gl_objectWait2)


'Click on the button: Delete for the created hotel row'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_Hotels_Mgt/btn_DeleteHotel', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)

'Delete Successful. Verify the Hotel is deleted on list.'
WebUI.acceptAlert()
//WebUI.delay(GlobalVariable.gl_objectWait2)
WebUI.verifyTextNotPresent('VN Hotel', false)
