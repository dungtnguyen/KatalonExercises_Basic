import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.support.Color

/*
 TC Name: BE-09-Hotels-Search hotel by Name
 Description Details:
 Actions:
	 1	Navigate and login as Admin to page https://www.phptravels.net/admin/hotels
	 2	"Click on 'Search' button
		 Input Hotel Name to Search Pharse
		 Click on 'GO' button"
	 3	"Input invalid value to Search Pharse
		 Ex: @123
		 Click on 'GO' button"
	 4	Click on 'RESET' button

 Expected Results:
	 2	"Search succesful
		 Verify the hotel will be displayed on list"
	 3	"Search succesful
		 'Entries not found' message will be displayed"
	 4	The list displays all hotels

*/

'Step 1:Navigate and login as Admin to page https://www.phptravels.net/admin/hotels'
CustomKeywords.'general_utilities.CommonLib.openHomePage'('https://www.phptravels.net/admin')

CustomKeywords.'general_utilities.Specified_utilities.inputUsernameAndPasswordPressingButton'('Repo_WebUI_Advance/Page_Admin/txt_Email',
	GlobalVariable.gl_AdminEmail, 'Repo_WebUI_Advance/Page_Admin/txt_Password', GlobalVariable.gl_AdminPass, 'Repo_WebUI_Advance/Page_Admin/btn_Login',
	GlobalVariable.gl_objectWait)

'Setting Hotel Modules is enable by clicking the Module --> Hotel -->Enable'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Modules',
	GlobalVariable.gl_objectWait)

CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_PrimaryModules/btn_HotelModules',
	GlobalVariable.gl_objectWait)

CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_PrimaryModules/Confirm_Dlg/btn_Yes',
	GlobalVariable.gl_objectWait)

WebUI.delay(GlobalVariable.gl_objectWait2)

'Click on \'HOTELS\' of Menu bar on the left side of the screen'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Hotels',
	GlobalVariable.gl_objectWait)

'Verify the page: Hotels Management is displayed'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_HotelsMenu/mnuitem_Hotels',
	GlobalVariable.gl_objectWait)

WebUI.verifyElementPresent(findTestObject('Repo_WebUI_Advance/Page_Hotels_Mgt/header_Hotels_Mgt', [('headerNamePara') : 'Hotels Management']),
	GlobalVariable.gl_objectWait)

'Step 2: Click on the button: Search button, Input Hotel Name to Search Pharse, Click on the button: GO, and verify that Search succesful Verify the hotel will be displayed on list'

'Click on the button: Search '
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_Hotels_Mgt/btn_Search', GlobalVariable.gl_objectWait)

'Input Hotel Name to Search Pharse'
WebUI.setText(findTestObject('Repo_WebUI_Advance/Page_Hotels_Mgt/txt_Search'), 'Rendezvous')

'Click on the button: GO '
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_Hotels_Mgt/btn_GO', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)

'Verify that Search succesful Verify the hotel will be displayed on list'
WebUI.verifyElementVisible(findTestObject('Repo_WebUI_Advance/Page_Hotels_Mgt/chk_FoundSearch'))
WebUI.delay(GlobalVariable.gl_objectWait2)

'Step 3: Input invalid value to Search Pharse, Ex: @123, Click on the button: GO button and verify that the Search is unsuccesful, the message:Entries not found will be displayed'
'Click on the button: Reset '
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_Hotels_Mgt/btn_Reset', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)

'Click on the button: Search '
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_Hotels_Mgt/btn_Search', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)

'Input Hotel Name to Search Pharse'
WebUI.setText(findTestObject('Repo_WebUI_Advance/Page_Hotels_Mgt/txt_Search'), '123@')
WebUI.delay(GlobalVariable.gl_objectWait2)

'Click on the button: GO '
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_Hotels_Mgt/btn_GO', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)

'verify that the Search is unsuccesful, the message:Entries not found will be displayed'
WebUI.verifyTextPresent('Entries not found.', false)