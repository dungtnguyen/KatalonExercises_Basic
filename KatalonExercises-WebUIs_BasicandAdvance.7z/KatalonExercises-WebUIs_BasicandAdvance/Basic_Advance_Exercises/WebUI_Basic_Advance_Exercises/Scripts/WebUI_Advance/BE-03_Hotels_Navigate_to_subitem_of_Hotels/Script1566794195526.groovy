import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.support.Color as Color
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.interactions.Action as Action
import org.openqa.selenium.interactions.Actions as Actions
import org.openqa.selenium.By as By
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger

import org.openqa.selenium.Keys as Keys
import java.awt.Robot as Robot
import java.awt.event.KeyEvent as KeyEvent

/*
 TC Name: BE-03-Hotels-Navigate to sub item of Hotels
 Description Details:
 Actions:
	 1	Navigate and login as Admin to page https://www.phptravels.net/admin
	 2	Click on 'HOTELS' of Menu bar on the left side of the screen
	 3	Click on 'HOTELS' option of 'HOTELS'
	 4	Click on 'ROOMS' option of 'HOTELS'
	 5	Click on 'EXTRAS' option of 'HOTELS'
	 6	Click on 'REVIEWS' option of 'HOTELS'
	 7	Click on 'HOTELS SETTINGS' option of 'HOTELS'

 Expected Results:
	 2	The sub list of 'HOTELS' includes 5 items.
	 3	Navigate to Hotels page successful
	 4	Navigate to Rooms page successful
	 5	Navigate to Extras page successful
	 6	Navigate to Reviews page successful
	 7	Navigate to Hotels Settings page successful
*/

'Step 1: Navigate and login as Admin to page https://www.phptravels.net/admin'
CustomKeywords.'general_utilities.CommonLib.openHomePage'('https://www.phptravels.net/admin')

CustomKeywords.'general_utilities.Specified_utilities.inputUsernameAndPasswordPressingButton'('Repo_WebUI_Advance/Page_Admin/txt_Email', 
    GlobalVariable.gl_AdminEmail, 'Repo_WebUI_Advance/Page_Admin/txt_Password', GlobalVariable.gl_AdminPass, 'Repo_WebUI_Advance/Page_Admin/btn_Login', 
    GlobalVariable.gl_objectWait)


'\'Step 2: Click on \'HOTELS\' of Menu bar on the left side of the screen and verify that The sub list of \'HOTELS\' includes 5 items.'

'Setting Hotel Modules is enable by clicking the Module --> Hotel -->Enable'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Modules', GlobalVariable.gl_objectWait)
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_PrimaryModules/btn_HotelModules', GlobalVariable.gl_objectWait)
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_PrimaryModules/Confirm_Dlg/btn_Yes', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)

'Click on \'HOTELS\' of Menu bar on the left side of the screen'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Hotels', GlobalVariable.gl_objectWait)

'verify that The sub list of \'HOTELS\' includes 5 items.'
WebDriver driver = DriverFactory.getWebDriver()
KeywordLogger log = new KeywordLogger()

int localvar_myCount = driver.findElements(By.xpath("//ul[@id='Hotels']/li")).size();

WebUI.verifyEqual(localvar_myCount, 5)

String headerPageTitle = "'Repo_WebUI_Advance/Page_Hotels_Mgt/header_Hotels_Mgt', " + "[('headerNamePara') : 'Hotels Management']"
String headerThu = '\'Repo_WebUI_Advance/Page_Hotels_Mgt/header_Hotels_Mgt\'' + ',' + '[(\'headerNamePara\') : \'Hotels Management\']'

'Step 3: Click on HOTELS option of HOTELS verify that system navigates to Hotels page successful'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_HotelsMenu/mnuitem_Hotels', GlobalVariable.gl_objectWait)
WebUI.verifyElementPresent(findTestObject('Repo_WebUI_Advance/Page_Hotels_Mgt/header_Hotels_Mgt', [('headerNamePara') : 'Hotels Management']), GlobalVariable.gl_objectWait)


'Step 4: Click on Rooms option of HOTELS verify that system navigates to Rooms page successful'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Hotels', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)

CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_HotelsMenu/mnuitem_Rooms', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)
WebUI.verifyElementPresent(findTestObject('Repo_WebUI_Advance/Page_Rooms_Mgt/header_Rooms_Mgt', [('headerNamePara'): 'Rooms Management']), GlobalVariable.gl_objectWait)


'Step 5: Click on Extras option of HOTELS verify that system navigates to Extras page successful'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Hotels', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_HotelsMenu/mnuitem_Extras', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)
WebUI.verifyElementPresent(findTestObject('Repo_WebUI_Advance/Page_Extras_Mgt/header_Extras_Mgt', [('headerNamePara'): 'Extras Management']), GlobalVariable.gl_objectWait)

'Step 6: Click on Reviews option of HOTELS verify that system navigates to Reviews page successful'


CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Hotels', GlobalVariable.gl_objectWait)

'Press the key PgDown'
CustomKeywords.'general_utilities.Specified_utilities.pressPageDownByRobot'(GlobalVariable.gl_objectWait2)

CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_HotelsMenu/mnuitem_Reviews', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)

WebUI.verifyElementPresent(findTestObject('Repo_WebUI_Advance/Page_Reviews_Mgt/header_Reviews_Mgt', [('headerNamePara'): 'Reviews Management']), GlobalVariable.gl_objectWait)


'Step 7: Click on Hotels Setting option of HOTELS verify that system navigates to Hotels Settings page successful'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Hotels', GlobalVariable.gl_objectWait)

'Press the key PgDown'
CustomKeywords.'general_utilities.Specified_utilities.pressPageDownByRobot'(GlobalVariable.gl_objectWait2)
CustomKeywords.'general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle'('Repo_WebUI_Advance/Page_HotelsMenu/mnuitem_HotelsSettings', 'Repo_WebUI_Advance/Page_Hotels_Setting/header_Hotels_Setting',GlobalVariable.gl_objectWait)

