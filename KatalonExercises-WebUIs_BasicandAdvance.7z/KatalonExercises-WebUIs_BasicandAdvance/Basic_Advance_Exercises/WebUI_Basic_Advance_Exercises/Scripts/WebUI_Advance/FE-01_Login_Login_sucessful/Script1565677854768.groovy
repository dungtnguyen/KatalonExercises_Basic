import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.TearDown
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository

import general_utilities.CommonLib
import general_utilities.Specified_utilities
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import java.util.Date
import java.text.DateFormat
import java.text.SimpleDateFormat;
import java.text.Format;

/*
 TC Name: FE-01-Login - Login sucessful
 Description Details:
 Actions:
	 1	Navigate to url 'https://www.phptravels.net/'
	 2	Select MY ACCOUNT -> Login
	 3	"Enter Email 'user@phptravels.com'
		 Enter Password 'demouser'
		 Click on Login button"

 Expected Results:
	 2
		 "Login page is displayed:
		 + Window title is 'Login'
	 3.
		 + URL is 'https://www.phptravels.net/login'"
		 "Main page is displayed:
		 + User name label 'Ex: Hi, Johny Smith'
		 + Current day as format DD MMM YYYY 'Ex: 8 August 2018'
		 + Let menu bar label: Bookings; My Profile; Wishlist; Nesletter
		 + Let menu bar icon: Bookings; My Profile; Wishlist; Nesletter
		 + Bookings menu is selected as default"
*/

'Step 1: Navigate to url \'https://www.phptravels.net/\''
CustomKeywords.'general_utilities.CommonLib.openHomePage'(GlobalVariable.gl_AdvancedUrl)

'Step 2: Select MY ACCOUNT -> Login and verify that Login page is displayed:\r\n+ Window title is \'Login\'\r\n+ URL is \'https://www.phptravels.net/login\''
CustomKeywords.'general_utilities.Specified_utilities.selectSubMenuItemInlevelOneAndVerifyOpeningPage'('Repo_WebUI_Advance/PhpTravels_HomePage/mainmnu_MyAccount', 'Repo_WebUI_Advance/PhpTravels_HomePage/submnu_Login','Repo_WebUI_Advance/LoginPage/lbl_Login', GlobalVariable.gl_objectWait)


'Step 3: Enter Email \'user@phptravels.com\'\r\nEnter Password \'demouser\'\r\nClick on Login button\r\nand verify that Main page is displayed:\r\n+ User name label \'Ex: Hi, Johny Smith\'\r\n+ Current day as format DD MMM YYYY \'Ex: 8 August 2018\'\r\n+ Let menu bar label: Bookings; My Profile; Wishlist; Nesletter\r\n+ Let menu bar icon: Bookings; My Profile; Wishlist; Nesletter\r\n+ Bookings menu is selected as default'
CustomKeywords.'general_utilities.Specified_utilities.inputUsernameAndPasswordPressingButton'('Repo_WebUI_Advance/LoginPage/txt_UserEmail', 'user@phptravels.com', 'Repo_WebUI_Advance/LoginPage/txt_Password', 'demouser','Repo_WebUI_Advance/LoginPage/btn_Login', GlobalVariable.gl_objectWait)

/*
Main page is displayed:
+ User name label 'Ex: Hi, Johny Smith'
+ Current day as format DD MMM YYYY 'Ex: 8 August 2018'
+ Let menu bar label: Bookings; My Profile; Wishlist; Nesletter
+ Bookings menu is selected as default
*/

'+ User name label Ex: Hi, Johny Smith'
String localvar_User = 'Hi, ' + GlobalVariable.gl_UserName + ' User'
CustomKeywords.'general_utilities.Specified_utilities.getTextAndVerify'('Repo_WebUI_Advance/Page_MyAccount/lbl_UserName', localvar_User, GlobalVariable.gl_objectWait)



'+ Current day as format DD MMM YYYY, Ex: 8 August 2018'
WebUI.waitForElementVisible(findTestObject('Repo_WebUI_Advance/Page_MyAccount/lbl_Date'), GlobalVariable.gl_objectWait)
def actText = WebUI.getText(findTestObject('Repo_WebUI_Advance/Page_MyAccount/lbl_Date'))
KeywordLogger log = new KeywordLogger()
log.logInfo('The real value of User: ' + actText)

Date localvar_Date = new Date()
Format formatter = new SimpleDateFormat('dd MMMM yyyy');
String expectDate = formatter.format(localvar_Date);

log.logInfo('The real value of date1: ' + expectDate)
if (!actText.contains(actText)){
	log.logError('The real value of User: ' + actText)
}


'+ Let menu bar label: Bookings; My Profile; Wishlist; Nesletter'
'+ Let menu bar icon: Bookings; My Profile; Wishlist; Nesletter'
CustomKeywords.'general_utilities.Specified_utilities.verifyElementTextAndRelevantIcon'('Repo_WebUI_Advance/Page_MyAccount/lbl_Bookings', 'Bookings', 'Repo_WebUI_Advance/Page_MyAccount/icon_Bookings', GlobalVariable.gl_objectWait)
CustomKeywords.'general_utilities.Specified_utilities.verifyElementTextAndRelevantIcon'('Repo_WebUI_Advance/Page_MyAccount/lbl_MyProfile', 'My Profile', 'Repo_WebUI_Advance/Page_MyAccount/icon_MyProfile', GlobalVariable.gl_objectWait)
CustomKeywords.'general_utilities.Specified_utilities.verifyElementTextAndRelevantIcon'('Repo_WebUI_Advance/Page_MyAccount/lbl_Wishlist', 'Wishlist', 'Repo_WebUI_Advance/Page_MyAccount/icon_Wishlist', GlobalVariable.gl_objectWait)
CustomKeywords.'general_utilities.Specified_utilities.verifyElementTextAndRelevantIcon'('Repo_WebUI_Advance/Page_MyAccount/lbl_Newsletter', 'Newsletter', 'Repo_WebUI_Advance/Page_MyAccount/icon_Newsletter', GlobalVariable.gl_objectWait)


'+ Bookings menu is selected as default'
CustomKeywords.'general_utilities.Specified_utilities.getAttributeAndVerify'('Repo_WebUI_Advance/Page_MyAccount/lbl_Bookings_Active', 'class', 'active')
