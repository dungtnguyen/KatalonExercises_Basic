import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

import org.openqa.selenium.By
import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.driver.WebUIDriverType
import org.openqa.selenium.Keys as Keys
import java.awt.Robot
import java.awt.event.KeyEvent
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import java.util.Random
import org.openqa.selenium.Point


'Step 1: Navigate to url \'https://www.phptravels.net/ and verify that Heading title is Latest Posts'
CustomKeywords.'general_utilities.CommonLib.openHomePage'('https://www.phptravels.net/offers')


'Step 2: Random click on one of the button : Read more and verify that Fullscreen icon is not displayed on Image'
String localvar_xpthReadMore = "//a[@class='btn btn-primary go-right loader']"
CustomKeywords.'general_utilities.Specified_utilities.countAllItemsInPageAndClickAnItemUnderRandom'(localvar_xpthReadMore, 'Repo_WebUI_Advance/Page_Special_Offers/btn_Read_More')

'Verify that Fullscreen icon is not displayed on Image'
//WebUI.verifyElementPresent('Repo_WebUI_Advance/Page_Special_Offers_Packages/icon_FullScreen', GlobalVariable.gl_objectWait2)

'Step 3: Mouse over on image, verify that the icon: Fullscreen is  displayed on Image'
CustomKeywords.'general_utilities.Specified_utilities.movingMouseOverOverTestObjectAndVerifyOtherObjExisting'('Repo_WebUI_Advance/Page_Special_Offers_Packages/img_Overview', 'Repo_WebUI_Advance/Page_Special_Offers_Packages/icon_FullScreen', GlobalVariable.gl_objectWait2)

'Step 4: Clicking Fullscreen icon verify that Image displays as full screen'
CustomKeywords.'general_utilities.Specified_utilities.clickonTestObjectAndVerifyOtherObjExisting'('Repo_WebUI_Advance/Page_Special_Offers_Packages/img_Overview', 'Repo_WebUI_Advance/Page_Special_Offers_Packages/icon_FullScreen', GlobalVariable.gl_objectWait2)

'Step 5: Mouse over on image and clicking on normal icon verify that Image displays as normal size'
CustomKeywords.'general_utilities.Specified_utilities.clickonTestObjectAndVerifyOtherObjExisting'('Repo_WebUI_Advance/Page_Special_Offers_Packages/icon_NormalScreen', 'Repo_WebUI_Advance/Page_Special_Offers_Packages/icon_FullScreen', GlobalVariable.gl_objectWait2)




