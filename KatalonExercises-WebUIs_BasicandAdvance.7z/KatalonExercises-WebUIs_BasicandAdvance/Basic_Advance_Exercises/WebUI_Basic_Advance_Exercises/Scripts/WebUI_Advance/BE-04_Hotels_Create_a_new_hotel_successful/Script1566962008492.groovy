import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.support.Color as Color
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.interactions.Action as Action
import org.openqa.selenium.interactions.Actions as Actions
import org.openqa.selenium.By as By
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import org.openqa.selenium.Keys as Keys
import java.awt.Robot as Robot
import java.awt.event.KeyEvent as KeyEvent

/*
 TC Name: BE-04-Hotels-Create a new hotel successful
 Description Details:
 Actions:
	 1	Navigate and login as Admin to page https://www.phptravels.net/admin/hotels
	 2	Click on 'ADD' button
	 3	"Input all Hotel Information on General tab:
		   + Status; Hotel Name, Hotel Description;…"
	 4	Click on 'SUBMIT' button

 Expected Results:
	 4	The Created Hotel displays on Hotel Management with correct information

*/

'Step 1:Navigate and login as Admin to page https://www.phptravels.net/admin/hotels'
CustomKeywords.'general_utilities.CommonLib.openHomePage'('https://www.phptravels.net/admin')

CustomKeywords.'general_utilities.Specified_utilities.inputUsernameAndPasswordPressingButton'('Repo_WebUI_Advance/Page_Admin/txt_Email', 
    GlobalVariable.gl_AdminEmail, 'Repo_WebUI_Advance/Page_Admin/txt_Password', GlobalVariable.gl_AdminPass, 'Repo_WebUI_Advance/Page_Admin/btn_Login', 
    GlobalVariable.gl_objectWait)

'Setting Hotel Modules is enable by clicking the Module --> Hotel -->Enable'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Modules', 
    GlobalVariable.gl_objectWait)

CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_PrimaryModules/btn_HotelModules', 
    GlobalVariable.gl_objectWait)

CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_PrimaryModules/Confirm_Dlg/btn_Yes', 
    GlobalVariable.gl_objectWait)

WebUI.delay(GlobalVariable.gl_objectWait2)

'Click on \'HOTELS\' of Menu bar on the left side of the screen'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Hotels', 
    GlobalVariable.gl_objectWait)

'Verify the page: Hotels Management is displayed'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_HotelsMenu/mnuitem_Hotels', 
    GlobalVariable.gl_objectWait)

WebUI.verifyElementPresent(findTestObject('Repo_WebUI_Advance/Page_Hotels_Mgt/header_Hotels_Mgt', [('headerNamePara') : 'Hotels Management']), 
    GlobalVariable.gl_objectWait)

'Step 2: Click on the button: ADD on the page: Hotels Management'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_Hotels_Mgt/btn_Add', GlobalVariable.gl_objectWait)

'Step 3: Input all Hotel Information on General tab like Status; Hotel Name, Hotel Description…'
' + Select status'
WebUI.selectOptionByValue(findTestObject('Repo_WebUI_Advance/Page_AddHotel/lst_Status'), 'Yes', false)
WebUI.delay(GlobalVariable.gl_objectWait2)

' + Input Hotel Name'
WebUI.setText(findTestObject('Repo_WebUI_Advance/Page_AddHotel/txt_Hotel_Name'), 'VN Hotel')
WebUI.delay(GlobalVariable.gl_objectWait2)

' + Input Hotel Description'
String localvar_iFrameNewValue = 'VN Hotel Description'
WebUI.switchToFrame(findTestObject('Repo_WebUI_Advance/Page_AddHotel/ifr_DescriptionFrame'), GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)
CustomKeywords.'general_utilities.CommonLib.setTextForIframeAndVerify'('Repo_WebUI_Advance/Page_AddHotel/ifr_DescriptionArea', localvar_iFrameNewValue, GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)

'Switch back to default content'
WebUI.switchToDefaultContent()

'Select Stars'
WebUI.selectOptionByValue(findTestObject('Repo_WebUI_Advance/Page_AddHotel/lst_Stars'), '3', true)
WebUI.delay(GlobalVariable.gl_objectWait2)


'Select Locations:'
'Click on the Location '
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AddHotel/lst_Location', GlobalVariable.gl_objectWait)

WebUI.delay(GlobalVariable.gl_objectWait2)

'Set text for the txt_Search and select a relevant location'
CustomKeywords.'general_utilities.Specified_utilities.inputTextByRobot'('Vien')
CustomKeywords.'general_utilities.Specified_utilities.pressNarrowDownByRobot'(GlobalVariable.gl_objectWait2)
CustomKeywords.'general_utilities.Specified_utilities.pressTABByRobot'(GlobalVariable.gl_objectWait2)

'Step: 4 Click on the button: Submit, verify that the Created Hotel displays on Hotel Management with correct information'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AddHotel/btn_Submit', GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait5)

'Verify that The Created Hotel displays on Hotel Management with correct information'
WebUI.verifyElementPresent(findTestObject('Repo_WebUI_Advance/Page_Hotels_Mgt/header_Hotels_Mgt', [('headerNamePara') : 'Hotels Management']), GlobalVariable.gl_objectWait)
WebUI.delay(GlobalVariable.gl_objectWait2)

WebUI.verifyTextPresent('VN Hotel', false)

'Restore environment'
'Click on \'HOTELS\' of Menu bar on the left side of the screen'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_AdminSideBar/mmenu_Hotels',
	GlobalVariable.gl_objectWait)

'Verify the page: Hotels Management is displayed'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_HotelsMenu/mnuitem_Hotels',
	GlobalVariable.gl_objectWait)

WebUI.verifyElementPresent(findTestObject('Repo_WebUI_Advance/Page_Hotels_Mgt/header_Hotels_Mgt', [('headerNamePara') : 'Hotels Management']),
	GlobalVariable.gl_objectWait)
			
'Check on the created hotel'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_Hotels_Mgt/chk_DeleteHotel', GlobalVariable.gl_objectWait2)
//WebUI.delay(GlobalVariable.gl_objectWait5)


'Click on the button: Delete for the created hotel row'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_Hotels_Mgt/btn_DeleteHotel', GlobalVariable.gl_objectWait)
//WebUI.delay(GlobalVariable.gl_objectWait5)

'Delete Successful. Verify the Hotel is deleted on list.'
WebUI.acceptAlert()
//WebUI.delay(GlobalVariable.gl_objectWait5)
WebUI.verifyTextNotPresent('VN Hotel', false)

