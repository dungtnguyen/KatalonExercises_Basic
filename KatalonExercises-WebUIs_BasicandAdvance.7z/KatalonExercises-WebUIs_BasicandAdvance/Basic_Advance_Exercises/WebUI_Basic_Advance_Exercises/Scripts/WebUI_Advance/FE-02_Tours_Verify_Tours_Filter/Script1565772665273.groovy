import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import java.awt.Robot as Robot
import java.awt.event.KeyEvent as KeyEvent

'Step 1: Navigate to url \'https://www.phptravels.net/\''
CustomKeywords.'general_utilities.CommonLib.openHomePage'('https://www.phptravels.net/tours')

'Step 2: Filter Search:\r\n+ Star grade : 3/5\r\n+ Price range: From 0 to 60\r\n+ Tour Types: Holidays\r\nClicking on \'SEARCH\' button\r\nAnd verify that all of Tours list:\r\n+ Tour Type of each Hotels is \'Holidays\''
'+ Star grade : 3/5'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_ToursListings/opt_StarGrade', 
    GlobalVariable.gl_objectWait)

'+ Price range: From 0 to 60'
String localvar_XpathSlider = '//div[@class=\'slider-track\']/div[@class=\'slider-handle round\'][@style=\'left: 100%;\']'

CustomKeywords.'general_utilities.Specified_utilities.modifyAttributeWebElemntAndClicking'(localvar_XpathSlider)

'+ Tour Types: Holidays'
Robot robot = new Robot()

robot.keyPress(KeyEvent.VK_PAGE_DOWN)

WebUI.delay(GlobalVariable.gl_objectWait2)

CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_ToursListings/opt_Holidays', 
    GlobalVariable.gl_objectWait)

'Clicking on the button: SEARCH'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/Page_ToursListings/button_Search', 
    GlobalVariable.gl_objectWait)

'Verify all of Tours list: + Tour Type of each Hotels is Holidays'