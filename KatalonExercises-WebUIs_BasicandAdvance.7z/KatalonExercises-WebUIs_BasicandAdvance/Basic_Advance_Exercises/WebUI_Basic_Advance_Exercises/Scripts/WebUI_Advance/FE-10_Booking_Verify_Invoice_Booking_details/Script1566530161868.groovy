import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.annotation.TearDown as TearDown
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import general_utilities.CommonLib as CommonLib
import general_utilities.Specified_utilities as Specified_utilities
import java.util.Date as Date
import java.text.DateFormat as DateFormat
import java.text.SimpleDateFormat as SimpleDateFormat
import java.text.Format as Format

import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.By
import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.driver.WebUIDriverType
import org.openqa.selenium.Keys as Keys
import java.awt.Robot
import java.awt.event.KeyEvent
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import java.util.Random
import org.openqa.selenium.support.Color


'Step 1: Navigate and login to url \'https://www.phptravels.net/login\''
CustomKeywords.'general_utilities.CommonLib.openHomePage'(GlobalVariable.gl_AdvancedUrl)

CustomKeywords.'general_utilities.Specified_utilities.selectSubMenuItemInlevelOneAndVerifyOpeningPage'('Repo_WebUI_Advance/PhpTravels_HomePage/mainmnu_MyAccount',
	'Repo_WebUI_Advance/PhpTravels_HomePage/submnu_Login', 'Repo_WebUI_Advance/LoginPage/lbl_Login', GlobalVariable.gl_objectWait)

CustomKeywords.'general_utilities.Specified_utilities.inputUsernameAndPasswordPressingButton'('Repo_WebUI_Advance/LoginPage/txt_UserEmail', 'user@phptravels.com', 'Repo_WebUI_Advance/LoginPage/txt_Password', 'demouser','Repo_WebUI_Advance/LoginPage/btn_Login', GlobalVariable.gl_objectWait)


'Step 2: Get random Booking information (Ex booking index is 4) on Booking list:\r\n+ Hotel name (Redezvous Hotels)\r\n+ Country name (Singepore)\r\n+ Number Start (2/5)\r\n+ USD $ (165)\r\n+ Invoice Date (14/01/2018)\r\n+ Booking ID (107)\r\n+ Due Date (15/01/2018)\r\n+ Booking Code (1905)'
'Verify that Bookings menu is selected as default'
CustomKeywords.'general_utilities.Specified_utilities.getAttributeAndVerify'('Repo_WebUI_Advance/Page_MyAccount/lbl_Bookings_Active', 
    'class', 'active')

'Get all of Bookings list items'
WebDriver driver = DriverFactory.getWebDriver()
KeywordLogger log = new KeywordLogger()

int localvar_myCount = driver.findElements(By.xpath("//div[@id='bookings']/div[@class='row']")).size();
//log.logInfo("The value of localvar_myCount is : " + localvar_myCount)

if (localvar_myCount !=0){
	'For column 01 in Booking list, including: Booking Name, Country/City name, Number Start, Price'	
	String firstTestObjectxPath = "(//div[@id='bookings']/div[@class='row'])[1]/div[@class='col-md-5 offset-0 go-right']"
	String actualFirstColObjectText = driver.findElement(By.xpath(firstTestObjectxPath)).getText()
	String[] subItemFirst = actualFirstColObjectText.split("\\r?\\n");
	WebUI.verifyEqual(subItemFirst.length, 4)
	
	'For column 02 in Booking list, including: Booking ID, Booking Code, Due Date'
	String secondTestObjectxPath = "(//div[@id='bookings']/div[@class='row'])[1]/div[@class='col-md-3 go-right']"
	String actualSecondColObjectText = driver.findElement(By.xpath(secondTestObjectxPath)).getText()
	String[] subItemSecond = actualSecondColObjectText.split("\\r?\\n");
	WebUI.verifyEqual(subItemSecond.length, 3)
}else{
	log.logWarning('There is no any item in the bookings litst')
}

'Step 3:Click on the button INVOICE verify that Invoice page is displayed with the title is Invoice'
CustomKeywords.'general_utilities.Specified_utilities.verifyExistAndClicking'('Repo_WebUI_Advance/PhpTravels_BookingsPage/btn_Invoice',GlobalVariable.gl_objectWait)

'Switch to the current window and verify its title'
WebUI.switchToWindowIndex(1)
String windowTitle = WebUI.getWindowTitle()
WebUI.verifyEqual(windowTitle, 'Invoice')
