import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.driver.WebUIDriverType as WebUIDriverType
import org.openqa.selenium.Keys as Keys
import java.awt.Robot as Robot
import java.awt.event.KeyEvent as KeyEvent
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import java.util.Random as Random
import org.openqa.selenium.support.Color as Color
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.interactions.Action as Action
import org.openqa.selenium.interactions.Actions as Actions
import org.openqa.selenium.By as By

/*
 TC Name: BE-02-Login-Login to page unsuccessful
 Description Details:
 Actions:
	 1	Go to https://www.phptravels.net/admin
	 2	"Click on ""LOGIN"" button with blank 'Email' and 'Password'
	 3	"Click on ""LOGIN"" button with invalid format email and password
		 Ex: abc/123"
	 4	Click on "LOGIN" button with incorrect username or password

 Expected Results:
	 3	Please fill out this field" message is displayed.
		 'The Email field must contain a valid email address' message is displayed
	 4	"Login unsuccessful
		 - 'Invalid Login Credentials' message is displayed"

*/

'Step 1: Go to https://www.phptravels.net/admin'
CustomKeywords.'general_utilities.CommonLib.openHomePage'('https://www.phptravels.net/admin')

'\'Step 2: Click on "LOGIN" button with blank \'Email\' and \'Password\' and verify that\r\n\'\'The Email field must contain a valid email address\' message is displayed\r\n\r\n'
CustomKeywords.'general_utilities.Specified_utilities.inputUsernameAndPasswordPressingButton'('Repo_WebUI_Advance/Page_Admin/txt_Email',
	'', 'Repo_WebUI_Advance/Page_Admin/txt_Password', '', 'Repo_WebUI_Advance/Page_Admin/btn_Login', GlobalVariable.gl_objectWait5)

//WebUI.delay(GlobalVariable.gl_objectWait5)

'\'Step 3: Click on "LOGIN" button with invalid format email and password\r\nEx: abc/123,  and verify that \'\'\'The Email field must contain a valid email address\' message is displayed\r\n\r\n'
'3.1 Email and password is invalid'

CustomKeywords.'general_utilities.Specified_utilities.inputUsernameAndPasswordPressingButton'('Repo_WebUI_Advance/Page_Admin/txt_Email',
	'admin', 'Repo_WebUI_Advance/Page_Admin/txt_Password', 'abc', 'Repo_WebUI_Advance/Page_Admin/btn_Login',
	GlobalVariable.gl_objectWait5)

WebUI.delay(GlobalVariable.gl_objectWait5)

'Verify the relevant message'
String localvar_ErrorMessage = 'The Email field must contain a valid email address'
WebUI.verifyElementVisible(findTestObject('Repo_WebUI_Advance/Page_Admin/lbl_ErrorMessage', [('errorContentPara') : localvar_ErrorMessage]))

'3.2 Email is valid but password is wrong'
CustomKeywords.'general_utilities.Specified_utilities.inputUsernameAndPasswordPressingButton'('Repo_WebUI_Advance/Page_Admin/txt_Email',
	'admin@phptravels.com', 'Repo_WebUI_Advance/Page_Admin/txt_Password', 'abc', 'Repo_WebUI_Advance/Page_Admin/btn_Login',
	GlobalVariable.gl_objectWait5)

WebUI.delay(GlobalVariable.gl_objectWait5)

'Step 4: Verify the relevant message'
String localvar_WarnMessage = 'Invalid Login Credentials'
WebUI.verifyElementVisible(findTestObject('Repo_WebUI_Advance/Page_Admin/lbl_WarnMessage', [('warnContentPara') : localvar_WarnMessage]))