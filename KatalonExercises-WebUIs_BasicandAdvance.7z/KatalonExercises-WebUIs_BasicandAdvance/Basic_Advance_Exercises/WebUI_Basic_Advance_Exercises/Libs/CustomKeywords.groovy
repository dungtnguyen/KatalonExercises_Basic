
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import com.kms.katalon.core.testobject.TestObject

import org.openqa.selenium.Keys


def static "general_utilities.Specified_utilities.selectSubMenuItemInlevelOneAndVerifyOpeningPage"(
    	String mainMenuName	
     , 	String menuItemName	
     , 	String nextTitlePage	
     , 	int timeOut	) {
    (new general_utilities.Specified_utilities()).selectSubMenuItemInlevelOneAndVerifyOpeningPage(
        	mainMenuName
         , 	menuItemName
         , 	nextTitlePage
         , 	timeOut)
}

def static "general_utilities.Specified_utilities.inputUsernameAndPasswordPressingButton"(
    	String userName	
     , 	String userNameData	
     , 	String passwordName	
     , 	String passData	
     , 	String buttonName	
     , 	int timeOut	) {
    (new general_utilities.Specified_utilities()).inputUsernameAndPasswordPressingButton(
        	userName
         , 	userNameData
         , 	passwordName
         , 	passData
         , 	buttonName
         , 	timeOut)
}

def static "general_utilities.Specified_utilities.verifyElementTextAndRelevantIcon"(
    	String elementName	
     , 	String expText	
     , 	String iconObjName	
     , 	int timeOut	) {
    (new general_utilities.Specified_utilities()).verifyElementTextAndRelevantIcon(
        	elementName
         , 	expText
         , 	iconObjName
         , 	timeOut)
}

def static "general_utilities.Specified_utilities.getAttributeAndVerify"(
    	String elementName	
     , 	String attrName	
     , 	String expAttr	) {
    (new general_utilities.Specified_utilities()).getAttributeAndVerify(
        	elementName
         , 	attrName
         , 	expAttr)
}

def static "general_utilities.Specified_utilities.getTextAndVerify"(
    	String elementName	
     , 	String expText	
     , 	int timeOut	) {
    (new general_utilities.Specified_utilities()).getTextAndVerify(
        	elementName
         , 	expText
         , 	timeOut)
}

def static "general_utilities.Specified_utilities.verifyExistAndClicking"(
    	String elementName	
     , 	int timeOut	) {
    (new general_utilities.Specified_utilities()).verifyExistAndClicking(
        	elementName
         , 	timeOut)
}

def static "general_utilities.Specified_utilities.modifyAttributeWebElemntAndClicking"(
    	String xpathValue	) {
    (new general_utilities.Specified_utilities()).modifyAttributeWebElemntAndClicking(
        	xpathValue)
}

def static "general_utilities.Specified_utilities.clickHyperlinkTextAndVerifyTitleOfPage"(
    	String linkTestObject	
     , 	String pageTitleTestObject	
     , 	String expPageTitle	
     , 	int waitTime	) {
    (new general_utilities.Specified_utilities()).clickHyperlinkTextAndVerifyTitleOfPage(
        	linkTestObject
         , 	pageTitleTestObject
         , 	expPageTitle
         , 	waitTime)
}

def static "general_utilities.Specified_utilities.countAllItemsInPageList"(
    	int expValue	) {
    (new general_utilities.Specified_utilities()).countAllItemsInPageList(
        	expValue)
}

def static "general_utilities.Specified_utilities.countAllItemsInPageAndClickAnItemUnderRandom"(
    	String xPathName	
     , 	String objName	) {
    (new general_utilities.Specified_utilities()).countAllItemsInPageAndClickAnItemUnderRandom(
        	xPathName
         , 	objName)
}

def static "general_utilities.Specified_utilities.movingMouseOverOverTestObjectAndVerifyOtherObjExisting"(
    	String firstObjName	
     , 	String secondObjName	
     , 	int timeOut	) {
    (new general_utilities.Specified_utilities()).movingMouseOverOverTestObjectAndVerifyOtherObjExisting(
        	firstObjName
         , 	secondObjName
         , 	timeOut)
}

def static "general_utilities.Specified_utilities.clickonTestObjectAndVerifyOtherObjExisting"(
    	String firstObjName	
     , 	String secondObjName	
     , 	int timeOut	) {
    (new general_utilities.Specified_utilities()).clickonTestObjectAndVerifyOtherObjExisting(
        	firstObjName
         , 	secondObjName
         , 	timeOut)
}

def static "general_utilities.Specified_utilities.verifyBackgroundColorOfTestObjectExisting"(
    	String firstObjName	
     , 	String expColor	) {
    (new general_utilities.Specified_utilities()).verifyBackgroundColorOfTestObjectExisting(
        	firstObjName
         , 	expColor)
}

def static "general_utilities.Specified_utilities.inputTextByRobot"(
    	String inputText	) {
    (new general_utilities.Specified_utilities()).inputTextByRobot(
        	inputText)
}

def static "general_utilities.Specified_utilities.pressEnterByRobot"(
    	int timeOut	) {
    (new general_utilities.Specified_utilities()).pressEnterByRobot(
        	timeOut)
}

def static "general_utilities.Specified_utilities.pressTABByRobot"(
    	int timeOut	) {
    (new general_utilities.Specified_utilities()).pressTABByRobot(
        	timeOut)
}

def static "general_utilities.Specified_utilities.pressNarrowDownByRobot"(
    	int timeOut	) {
    (new general_utilities.Specified_utilities()).pressNarrowDownByRobot(
        	timeOut)
}

def static "general_utilities.Specified_utilities.pressPageDownByRobot"(
    	int timeOut	) {
    (new general_utilities.Specified_utilities()).pressPageDownByRobot(
        	timeOut)
}

def static "general_utilities.Specified_utilities.verifyExistAndChecking"(
    	String elementName	
     , 	int timeOut	) {
    (new general_utilities.Specified_utilities()).verifyExistAndChecking(
        	elementName
         , 	timeOut)
}

def static "general_utilities.CommonLib.dragAndDrop"(
    	String sourceObject	
     , 	String destinationObject	) {
    (new general_utilities.CommonLib()).dragAndDrop(
        	sourceObject
         , 	destinationObject)
}

def static "general_utilities.CommonLib.verifySpecificColSorted"(
    	TestObject to	
     , 	String colIndex	) {
    (new general_utilities.CommonLib()).verifySpecificColSorted(
        	to
         , 	colIndex)
}

def static "general_utilities.CommonLib.openHomePage"(
    	String Url	) {
    (new general_utilities.CommonLib()).openHomePage(
        	Url)
}

def static "general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle"(
    	String linkTestObject	
     , 	String pageTitleTestObject	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).clickHyperlinkTextAndVerifyPageTitle(
        	linkTestObject
         , 	pageTitleTestObject
         , 	waitTime)
}

def static "general_utilities.CommonLib.checkOptionAndVerify"(
    	String testObjectName	
     , 	int verifyStatus	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).checkOptionAndVerify(
        	testObjectName
         , 	verifyStatus
         , 	waitTime)
}

def static "general_utilities.CommonLib.verifyValueOfTwoObjectsAfterDragAndDrop"(
    	String firstTestObjectxPath	
     , 	String secondTestObjectxPath	
     , 	String expectedValFirstTestObject	
     , 	String expectedValSecondTestObject	) {
    (new general_utilities.CommonLib()).verifyValueOfTwoObjectsAfterDragAndDrop(
        	firstTestObjectxPath
         , 	secondTestObjectxPath
         , 	expectedValFirstTestObject
         , 	expectedValSecondTestObject)
}

def static "general_utilities.CommonLib.selectDropdownListByLabelAndVerify"(
    	String testObjectName	
     , 	String selectionItem	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).selectDropdownListByLabelAndVerify(
        	testObjectName
         , 	selectionItem
         , 	waitTime)
}

def static "general_utilities.CommonLib.selectDropdownListByIndexAndVerify"(
    	String testObjectName	
     , 	int indexItem	
     , 	String selectedItem	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).selectDropdownListByIndexAndVerify(
        	testObjectName
         , 	indexItem
         , 	selectedItem
         , 	waitTime)
}

def static "general_utilities.CommonLib.selectDropdownListByValueAndVerify"(
    	String testObjectName	
     , 	String selectionValue	
     , 	String selectedItem	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).selectDropdownListByValueAndVerify(
        	testObjectName
         , 	selectionValue
         , 	selectedItem
         , 	waitTime)
}

def static "general_utilities.CommonLib.selectFileAndUpLoad"(
    	String selectUploadFileTestObjectName	
     , 	String uploadFileButtonTestObjectName	
     , 	String fullUploadingFilePathname	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).selectFileAndUpLoad(
        	selectUploadFileTestObjectName
         , 	uploadFileButtonTestObjectName
         , 	fullUploadingFilePathname
         , 	waitTime)
}

def static "general_utilities.CommonLib.setTextForIframeAndVerify"(
    	String iFrameTestObjectName	
     , 	String textValue	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).setTextForIframeAndVerify(
        	iFrameTestObjectName
         , 	textValue
         , 	waitTime)
}

def static "general_utilities.CommonLib.editContentByJS"(
    	String textObjectName	
     , 	String newContent	) {
    (new general_utilities.CommonLib()).editContentByJS(
        	textObjectName
         , 	newContent)
}

def static "general_utilities.CommonLib.sendNormalKeyFromKeyboard"(
    	String normalKey	) {
    (new general_utilities.CommonLib()).sendNormalKeyFromKeyboard(
        	normalKey)
}

def static "general_utilities.CommonLib.sendSpecialKeyFromKeyboard"(
    	Keys specialKey	) {
    (new general_utilities.CommonLib()).sendSpecialKeyFromKeyboard(
        	specialKey)
}

def static "general_utilities.CommonLib.moveSliderFromKeyboardAndVerify"(
    	String sliderObjectName	
     , 	int loopTimes	
     , 	String labelObjectName	
     , 	String expectedValue	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).moveSliderFromKeyboardAndVerify(
        	sliderObjectName
         , 	loopTimes
         , 	labelObjectName
         , 	expectedValue
         , 	waitTime)
}
