import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import general_utilities.CommonLib
import com.kms.katalon.core.annotation.TearDown as TearDown
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.By
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory


////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: UIB-07 - Verify Key Presses
//	Description Details:
//	Actions:
//	1. 	"Go to https://the-internet.herokuapp.com/
//		Select 'Key Presses' link
//
//	2	Presses 'TAB' key
//	3	Presses 'ENTER' key
//	4	Presses 'G' key
//
//	Expected Results:
//	1	Key Presses header title is displayed
//	2	Message: You entered: TAB
//	3	Message: You entered: ENTER
//	4	Message: You entered: G

///////////////////////////////////////////////////////////////////////////////////////////////////////////


'Step 1: Open Browser and Go to https://the-internet.herokuapp.com/, click on the hyperlink: Challenging DOM and verify that the Key Presses header title is displayed'
CustomKeywords.'general_utilities.CommonLib.openHomePage'(GlobalVariable.gl_Url)
CustomKeywords.'general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle'('MainPage/lnk_KeyPresses', 'KeyPressesPage/lbl_KeyPresses_header', GlobalVariable.gl_objectWait)


'Step 2: Presses the key TAB and verify the message: You entered: TAB'
WebUI.sendKeys(findTestObject('KeyPressesPage/txt_TextBox'), (Keys.TAB) as String)
WebUI.verifyTextPresent('You entered: TAB', false)

'Step 3: Presses the key ENTER and verify the message: You entered: ENTER'
//WebUI.clearText(findTestObject('KeyPressesPage/txt_TextBox'))
//WebUI.sendKeys(findTestObject('KeyPressesPage/txt_TextBox'), Keys.chord(Keys.ENTER))
//WebUI.verifyTextPresent('You entered: ENTER', false)


'Step 4: Presses the key g and verify the message: You entered: G'
WebUI.sendKeys(findTestObject('KeyPressesPage/txt_TextBox'), Keys.chord('g'))
WebUI.verifyTextPresent('You entered: G', false)

@TearDown
def tearDown() {
    'Close browser'
    WebUI.closeBrowser()
}