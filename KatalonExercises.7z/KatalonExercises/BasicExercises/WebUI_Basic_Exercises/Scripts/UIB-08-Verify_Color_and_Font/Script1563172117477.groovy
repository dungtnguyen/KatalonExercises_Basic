import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import general_utilities.CommonLib
import com.kms.katalon.core.annotation.TearDown as TearDown
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.By
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import org.openqa.selenium.support.Color
////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: UIB-08 - Verify Color and Font
//	Description Details:
//	Actions:
//	1	"Go to https://the-internet.herokuapp.com/
//		Select 'Challenging DOM' link"
//	2	Verify font size of 'foo' button'
//	3	Verify background-color of 'qux' button
//	4	Verify border-color of 'baz' button
//
//
//	Expected Results:
//	1	Challenging DOM header title is displayed
//	2	Font size is 16px
//	3	Background-color is Red color
//	4	Border-color is Green color
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////


'Step 1: Open Browser and Go to https://the-internet.herokuapp.com/, click on the hyperlink: ChallengingDOM and verify that the page Key Presses header title is displayed'
CustomKeywords.'general_utilities.CommonLib.openHomePage'(GlobalVariable.gl_Url)
CustomKeywords.'general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle'('MainPage/lnk_ChallengingDOM', 'Challenging_DOMPage/lbl_ChallengingDOM_header', GlobalVariable.gl_objectWait)


'Step 2: Verify font size of the button:foo: Font size is 16px'
String var_returnFontSize = WebUI.getCSSValue(findTestObject('Challenging_DOMPage/btn_foo'), 'font-size')
WebUI.verifyEqual(var_returnFontSize, '16px')

'Step 3: Verify background-color of the button: qux - Background-color is Red color'
String var_returnBgColor = WebUI.getCSSValue(findTestObject('Challenging_DOMPage/btn_foo'), 'background-color')
String var_Hex = Color.fromString(var_returnBgColor).asHex()
WebUI.verifyEqual(var_Hex, '#c60f13')


'Step 4: Verify border-color of the button baz - Border-color is Green color'
String var_returnBorderColor = WebUI.getCSSValue(findTestObject('Challenging_DOMPage/btn_baz'), 'border-top-color')
var_Hex = Color.fromString(var_returnBorderColor).asHex()
WebUI.verifyEqual(var_Hex, '#457a1a')
