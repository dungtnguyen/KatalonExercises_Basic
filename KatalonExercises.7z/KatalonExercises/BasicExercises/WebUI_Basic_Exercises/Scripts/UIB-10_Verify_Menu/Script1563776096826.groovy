import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.TearDown
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import general_utilities.CommonLib as CommonLib
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.By as By
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper


////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: UIB-10 - Verify Menu
//	Description Details:
//	Actions:
//	1	Go to https://the-internet.herokuapp.com/
//		Select 'JQuery UI Menus' link
//
//	2	Select Enabled -> JQuery UI menu
//	3	Click on 'Menu' link
//	4	Select Enabled -> Downloads -> CSV menu
//
//	Expected Results:
//	1	'JQueryUI - Menu header title is displayed
//	2	JQuery UI header title is displayed
//	3	'JQueryUI - Menu header title is displayed
//	4	The menu.csv file is saved to local successful
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////

'Step 1: Go to https://the-internet.herokuapp.com/, click on the hyperlink: JQuery UI Menus and verify that the JQuery UI Menus page is displayed'
CustomKeywords.'general_utilities.CommonLib.openHomePage'(GlobalVariable.gl_Url)
CustomKeywords.'general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle'('MainPage/lnk_JQuery_UI_Menus', 'JQueryUI_MenuPage/lbl_JQueryUI_Menu_header', GlobalVariable.gl_objectWait)


'Step 2: Select Enabled -> JQuery UI menu and verify that JQuery UI header title is displayed'
WebUI.mouseOver(findTestObject('JQueryUI_MenuPage/mnu_Enabled'))
WebUI.click(findTestObject('JQueryUI_MenuPage/mnu_Enabled'))
WebUI.delay(GlobalVariable.gl_objectWait2)

WebUI.click(findTestObject('JQueryUI_MenuPage/mnu_Enabled'))
WebUI.delay(GlobalVariable.gl_objectWait2)
WebUI.mouseOver(findTestObject('JQueryUI_MenuPage/mnuitem_Back_to_JQuery_UI'))
WebUI.delay(GlobalVariable.gl_objectWait2)
WebUI.click(findTestObject('JQueryUI_MenuPage/mnuitem_Back_to_JQuery_UI'))

WebUI.verifyElementPresent(findTestObject('JQuery_UI_SubMenuPage/lbl_JQueryUI_header'), GlobalVariable.gl_objectWait)

'Step 3: Click on the hyperlink: Menu and verify that JQueryUI - Menu header title is displayed'
WebUI.click(findTestObject('JQuery_UI_SubMenuPage/lnk_MenuItem'))
WebUI.verifyElementPresent(findTestObject('JQueryUI_MenuPage/lbl_JQueryUI_Menu_header'), GlobalVariable.gl_objectWait)

'Step 4: Select Enabled -> Downloads -> CSV menu and verify that The menu.csv file is saved to local successful'
WebUI.mouseOver(findTestObject('JQueryUI_MenuPage/mnu_Enabled'))
WebUI.delay(GlobalVariable.gl_objectWait2)
WebUI.mouseOver(findTestObject('JQueryUI_MenuPage/mnu_Downloads'))
WebUI.delay(GlobalVariable.gl_objectWait2)
WebUI.mouseOver(findTestObject('JQueryUI_MenuPage/mnuitem_CSV'))

File downloadedFolder = new File(GlobalVariable.gl_DownloadPathname)
List namesOfFiles = Arrays.asList(downloadedFolder.list())
KeywordLogger log = new KeywordLogger()
boolean returnValue = namesOfFiles.contains(GlobalVariable.gl_DownloadsFilename)
WebUI.verifyEqual(returnValue, true)
