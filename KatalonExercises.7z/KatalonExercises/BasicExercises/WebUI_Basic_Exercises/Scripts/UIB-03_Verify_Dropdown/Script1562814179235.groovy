import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.TearDown
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import general_utilities.CommonLib

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: UIB-03 - Verify Dropdown
//	Description Details:
//	Actions:
//	1	"Go to https://the-internet.herokuapp.com/
//		Select 'Dropdown' link"
//	2	Select item by label ''Option 2'
//	3	Select item by index 1
//	4	Select item by value 2
//
//	Expected Results:
//	1.	Dropdown List header title is displayed
//	2.	The current item is 'Option 2'
//	3.	The current item is 'Option 1'
//	4.	The current item is 'Option 2'
///////////////////////////////////////////////////////////////////////////////////////////////////////////


'Step 1: Open Browser and Go to https://the-internet.herokuapp.com/, click on the hyperlink: Dropdown and verify that Dropdown List header title is displayed'
CustomKeywords.'general_utilities.CommonLib.openHomePage'(GlobalVariable.gl_Url)
CustomKeywords.'general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle'('MainPage/lnk_Dropdown', 'DropDownPage/lbl_Dropdown_header', GlobalVariable.gl_objectWait)

'Step 2: Select item by label: Option 2 and verify that the current item is Option 2' 
CustomKeywords.'general_utilities.CommonLib.selectDropdownListByLabelAndVerify'('DropDownPage/lst_DropdownList','Option 2', GlobalVariable.gl_objectWait )


'Step 3: Select item by index 1 and verify that the current item is Option 1'
CustomKeywords.'general_utilities.CommonLib.selectDropdownListByIndexAndVerify'('DropDownPage/lst_DropdownList', 1, 'Option 1', GlobalVariable.gl_objectWait)



'Step 4: Select item by value 2 and verify that the current item is Option 2' 
CustomKeywords.'general_utilities.CommonLib.selectDropdownListByValueAndVerify'('DropDownPage/lst_DropdownList', '2', 'Option 2', GlobalVariable.gl_objectWait )


@TearDown
def tearDown() {
	'Close browser'
	WebUI.closeBrowser()
}