import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import general_utilities.CommonLib
import org.openqa.selenium.WebDriver as WebDriver
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.annotation.TearDown as TearDown

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: UIB-06 - Verify Alerts
//	Description Details:
//	Actions:
//	1	"Go to https://the-internet.herokuapp.com/
//		Select 'JavaScript Alerts' link"
//	2	Click 'Click for JS Alert' button
//	3	Click 'OK' button to close Alert
//	4	"Click 'I am a JS Confirm' button
//		Click 'Cancel' button to close Alert"
//	5	"Click 'Click for JS Prompt' button
//		Set text ""Hello'
//		Click 'OK' button to close Alert"
//
//	Expected Results:
//	1	JavaScript Alerts header title is displayed
//	2	I am a JS Alert' messge is displayed
//	3	Result message: You successfuly clicked an alert
//	4	Result message: You clicked: Cancel
//	5	Result message: You entered: Hello
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////

'Step 1: Open Browser and Go to https://the-internet.herokuapp.com/, click on the hyperlink: JavaScript Alerts and verify that the page: JavaScriptAlerts Page is displayed'
CustomKeywords.'general_utilities.CommonLib.openHomePage'(GlobalVariable.gl_Url)
CustomKeywords.'general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle'('MainPage/lnk_Javascript_Alerts', 'JavaScriptAlertsPage/lbl_JavaScriptAlerts_header', GlobalVariable.gl_objectWait)


'Step 2: Click on the button: Click for JS Alert, verify that the message:I am a JS Alert message is displayed'
WebUI.click(findTestObject('JavaScriptAlertsPage/btn_Click_for_JS_Alert'))
WebDriver driver = DriverFactory.getWebDriver()
String ActualAlertText = driver.switchTo().alert().getText()
WebUI.verifyEqual(ActualAlertText, localvar_AlertExpectedValue)

'Step 3: Click on the button: OK to close AlertClose the alert, and verify that the result message: You successfuly clicked an alert is displayed'
WebUI.acceptAlert()
WebUI.verifyTextPresent('You successfuly clicked an alert', false)

'Step 4: Click on the button: I am a JS Confirm, click on Cancel button and verify that the message: You clicked: Cancel is displayed.'
WebUI.click(findTestObject('JavaScriptAlertsPage/btn_Click_for_JS_Confirm'))
WebUI.dismissAlert()
WebUI.verifyTextPresent('You clicked: Cancel', false)


'Step 5: Click on the button: Click for JS Prompt, Set the text Hello, Click on the button: OK button to close Alert and verify that the message: You entered: Hello is displayed'
WebUI.click(findTestObject('JavaScriptAlertsPage/btn_Click_for_JS_Prompt'))
driver.switchTo().alert().sendKeys('Hello')
WebUI.acceptAlert()
WebUI.verifyTextPresent('You entered: Hello', false)

@TearDown
def tearDown() {
	'Close browser'
	WebUI.closeBrowser()
}
