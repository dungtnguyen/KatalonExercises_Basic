import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.TearDown
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger
import general_utilities.CommonLib
import com.kms.katalon.core.annotation.TearDown as TearDown

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: UIB-01 - Verify Checkboxes
//	Description Details:
//	Actions:
//	1. 	"Go to https://the-internet.herokuapp.com/
//		Select ' Checkboxes' link"
//
//	2	" Check 'checkbox 1'
//	 	Uncheck 'checkbox 2'"
//
//	Expected Results:
//	1.	Checkboxe header title is displayed
//	2.	"checkbox 1 is checked
//	checkbox 2 is un-checked"
///////////////////////////////////////////////////////////////////////////////////////////////////////////

'Step 1: Open Browser and Go to https://the-internet.herokuapp.com/, Click on the hyperlink: Checkboxes and verify that the CheckBoxesPage is displayed'
CustomKeywords.'general_utilities.CommonLib.openHomePage'(GlobalVariable.gl_Url)
CustomKeywords.'general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle'('MainPage/lnk_Checkboxes', 'CheckBoxesPage/lbl_Checkboxes_header', GlobalVariable.gl_objectWait)
//WebUI.click(findTestObject('MainPage/lnk_Functions', ['linkName' : 'Checkboxes']))


'Step 2: Check checkbox 1, Uncheck checkbox 2 and verify checkbox 1 is checked, checkbox 2 is un-checked'
CustomKeywords.'general_utilities.CommonLib.checkOptionAndVerify'('CheckBoxesPage/chk_Checkbox1', 1, GlobalVariable.gl_objectWait)
CustomKeywords.'general_utilities.CommonLib.checkOptionAndVerify'('CheckBoxesPage/chk_Checkbox2', 0, GlobalVariable.gl_objectWait)


@TearDown
def tearDown() {
	'Close browser'
	WebUI.closeBrowser()
}