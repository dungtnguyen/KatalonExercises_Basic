import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.TearDown
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import general_utilities.CommonLib as CommonLib
import com.kms.katalon.core.annotation.TearDown as TearDown
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.By as By
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: UIB-09 - Verify Slider
//	Description Details:
//	Actions:
//	1	"Go to https://the-internet.herokuapp.com/
//		Select 'Horizontal Slider' link"
//
//	2	Set Slider to 1
//	3	Set Slider to 2.5
//	4	Set Slider to 4.5
//
//	Expected Results:
//	1	Horizontal Slider header title is displayed
//	2	SSlider value is 1
//	3	Slider value is 2.5
//	4	Slider value is 4.5
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////
'Step 1: Go to https://the-internet.herokuapp.com/\r\n\tSelect \'Horizontal Slider\' link, and verify Horizontal Slider header title is displayed'
CustomKeywords.'general_utilities.CommonLib.openHomePage'(GlobalVariable.gl_Url)
CustomKeywords.'general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle'('MainPage/lnk_Horizontal_Slider', 'Horizontal_SliderPage/lbl_HorizontalSlider_header', GlobalVariable.gl_objectWait)

'Step 2: Set Slider to 1 and verify that Slider value is 1'
WebUI.focus(findTestObject('Horizontal_SliderPage/sld_HorizontalSlider'))
for (i = 1; i <= 2; i++) {
	WebUI.sendKeys(findTestObject('Horizontal_SliderPage/sld_HorizontalSlider'), (Keys.RIGHT) as String)
}
WebUI.verifyTextPresent('1', false)

'Step 3: Set Slider to 2.5 and verify that Slider value is 2.5'
for (i = 1; i <= 3; i++) {
	WebUI.sendKeys(findTestObject('Horizontal_SliderPage/sld_HorizontalSlider'), (Keys.RIGHT) as String)
}
WebUI.verifyTextPresent('2.5', false)

'Step 4: Set Slider to 4.5 and verify that Slider value is 4.5'
for (i = 1; i <= 4; i++) {
	WebUI.sendKeys(findTestObject('Horizontal_SliderPage/sld_HorizontalSlider'), (Keys.RIGHT) as String)
}
WebUI.verifyTextPresent('4.5', false)

@TearDown
def tearDown() {
	'Close browser'
	WebUI.closeBrowser()
}

