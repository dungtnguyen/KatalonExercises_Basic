package general_utilities

import org.openqa.selenium.By
import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.interactions.Action
import org.openqa.selenium.interactions.Actions

import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.webui.common.WebUiCommonHelper

import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.model.FailureHandling as FailureHandling

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.driver.WebUIDriverType
import org.openqa.selenium.Keys as Keys
import java.awt.Robot
import java.awt.event.KeyEvent


////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// The function list and meanings:
// 1. openHomePage(String Url):
//				Launch a browser with specified URL and maximizi it
//
// 2. clickHyperlinkTextAndVerifyPageTitle(TestObject linkTestObject, TestObject pageTitleTestObject, int waitTime):
//				click on a hyperlink text and verify existence the title of next page
//
//	3. checkOptionAndVerify(String testObjectName, int verifyStatus, int waitTime){
//				Check an option and verify its relevant status.
//
//	4. verifyValueOfTwoObjectsAfterDragAndDrop(String firstTestObjectxPath, String secondTestObjectxPath, String expectedValFirstTestObject, String expectedValSecondTestObject)
//				verify the values of 2 test objects right after dragging And dropping
//
//	6. selectDropdownListByLabelAndVerify(String testObjectName, String selectionItem, int waitTime)
//				Select an item in the dropdown list by label and verify selected item
//
//	7. selectDropdownListByIndexAndVerify(String testObjectName, int indexItem, String selectedItem , int waitTime)
//				Select an item in the dropdown list by index and verify selected item
//
//	8. selectDropdownListByValueAndVerify(String testObjectName, String selectionValue, String selectedItem, int waitTime)
//				Select an item in the dropdown list by value and verify selected item
//
//	9. selectFileAndUpLoad(String selectUploadFileTestObjectName, String uploadFileButtonTestObjectName, String fullUploadingFilePathname, int waitTime)
//				Select a file and upload it to
//
//	10. setTextForIframeAndVerify(String iFrameTestObjectName, String textValue, int waitTime)
//				Set a text paragraph for iFrame
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

public class CommonLib {
	private static String getJsDndHelper() {
		return '''
		function simulateDragDrop(sourceNode, destinationNode) {
		    var EVENT_TYPES = {
		        DRAG_END: 'dragend',
		        DRAG_START: 'dragstart',
		        DROP: 'drop'
		    }
		
		    function createCustomEvent(type) {
		        var event = new CustomEvent("CustomEvent")
		        event.initCustomEvent(type, true, true, null)
		        event.dataTransfer = {
		            data: {
		            },
		            setData: function(type, val) {
		                this.data[type] = val
		            },
		            getData: function(type) {
		                return this.data[type]
		            }
		        }
		        return event
		    }
		
		    function dispatchEvent(node, type, event) {
		        if (node.dispatchEvent) {
		            return node.dispatchEvent(event)
		        }
		        if (node.fireEvent) {
		            return node.fireEvent("on" + type, event)
		        }
		    }
		
		    var event = createCustomEvent(EVENT_TYPES.DRAG_START)
		    dispatchEvent(sourceNode, EVENT_TYPES.DRAG_START, event)
		
		    var dropEvent = createCustomEvent(EVENT_TYPES.DROP)
		    dropEvent.dataTransfer = event.dataTransfer
		    dispatchEvent(destinationNode, EVENT_TYPES.DROP, dropEvent)
		
		    var dragEndEvent = createCustomEvent(EVENT_TYPES.DRAG_END)
		    dragEndEvent.dataTransfer = event.dataTransfer
		    dispatchEvent(sourceNode, EVENT_TYPES.DRAG_END, dragEndEvent)
		}
		''';
	}

	@Keyword
	public void dragAndDrop(TestObject sourceObject, TestObject destinationObject) {
		WebElement sourceElement = WebUiBuiltInKeywords.findWebElement(sourceObject);
		WebElement destinationElement = WebUiBuiltInKeywords.findWebElement(destinationObject);
		WebDriver webDriver = DriverFactory.getWebDriver();
		((JavascriptExecutor) webDriver).executeScript(getJsDndHelper() + "simulateDragDrop(arguments[0], arguments[1])", sourceElement, destinationElement)
	}
	public static WebElement getElementByTestObject(TestObject testObject, int timeout = 5){
		WebElement webElement = WebUiCommonHelper.findWebElement(testObject, timeout)
		return webElement
	}

	@Keyword
	public void verifySpecificColSorted(TestObject to, String colIndex) {
		WebElement table = getElementByTestObject(to)
		List<WebElement> rows = table.findElements(By.xpath("./tbody/tr"))
		ArrayList<String> rowsdata = new ArrayList<>();
		for(WebElement row : rows){
			rowsdata.add((row.findElement(By.xpath(String.format("./td[%s]", colIndex))).getText()).toString());
		}

		ArrayList<String> sortedList = new ArrayList<>();
		for(String s : rowsdata){
			sortedList.add(s);
		}

		Collections.sort(sortedList);
		if (!sortedList.equals(rowsdata)){
			println "Data doesn't sort as expected."
		} else {
			println "Data is sorted as expected."
		}
	}

	@Keyword
	public void openHomePage(String Url){
		WebUI.openBrowser('')
		WebUI.navigateToUrl(Url)
		WebUI.maximizeWindow()
	}

	@Keyword
	public boolean clickHyperlinkTextAndVerifyPageTitle(String linkTestObject, String pageTitleTestObject, int waitTime){
		boolean returnValue = true

		returnValue = WebUI.verifyElementPresent(findTestObject(linkTestObject), waitTime)
		if(returnValue){
			WebUI.click(findTestObject(linkTestObject))

			'Wait and verify the header title of page is displayed '
			returnValue = WebUI.verifyElementPresent(findTestObject(pageTitleTestObject), waitTime)
			return returnValue

		} else {
			return false
		}

	}

	@Keyword
	public boolean checkOptionAndVerify(String testObjectName, int verifyStatus, int waitTime){
		boolean returnValue = true

		returnValue = WebUI.verifyElementPresent(findTestObject(testObjectName), waitTime)

		if(returnValue) {
			'Check option and verify '
			if(verifyStatus == 1) {
				WebUI.check(findTestObject(testObjectName))
				returnValue = WebUI.verifyElementChecked(findTestObject(testObjectName), waitTime)
				return returnValue
			}

			'Uncheck option and verify '
			if(verifyStatus == 0){
				WebUI.uncheck(findTestObject(testObjectName))
				returnValue = WebUI.verifyElementNotChecked(findTestObject(testObjectName), waitTime)
				return returnValue
			}

		} else {
			return false
		}
	}


	@Keyword
	public void verifyValueOfTwoObjectsAfterDragAndDrop(String firstTestObjectxPath, String secondTestObjectxPath, String expectedValFirstTestObject, String expectedValSecondTestObject){

		WebDriver driver = DriverFactory.getWebDriver()
		String actualFirstObjectText = driver.findElement(By.xpath(firstTestObjectxPath)).getText()
		String actualSecondObjectText = driver.findElement(By.xpath(secondTestObjectxPath)).getText()

		WebUI.verifyEqual(actualFirstObjectText, expectedValFirstTestObject)
		WebUI.verifyEqual(actualSecondObjectText, expectedValSecondTestObject)

	}
	@Keyword
	public boolean selectDropdownListByLabelAndVerify(String testObjectName, String selectionItem, int waitTime) {
		boolean returnValue = true

		returnValue = WebUI.verifyElementPresent(findTestObject(testObjectName), waitTime)
		if(returnValue){
			WebUI.selectOptionByLabel(findTestObject(testObjectName), selectionItem, false)
			returnValue = WebUI.verifyOptionSelectedByLabel(findTestObject(testObjectName), selectionItem, false, waitTime)
			return returnValue

		} else {
			return false
		}
	}

	@Keyword
	public boolean selectDropdownListByIndexAndVerify(String testObjectName, int indexItem, String selectedItem , int waitTime) {
		boolean returnValue = true
		String
		returnValue = WebUI.verifyElementPresent(findTestObject(testObjectName), waitTime)
		if(returnValue){
			WebUI.selectOptionByIndex(findTestObject(testObjectName), indexItem)
			returnValue = WebUI.verifyOptionSelectedByLabel(findTestObject(testObjectName), selectedItem, false, waitTime)
			return returnValue

		} else {
			return false
		}
	}

	@Keyword
	public boolean selectDropdownListByValueAndVerify(String testObjectName, String selectionValue, String selectedItem, int waitTime) {
		boolean returnValue = true

		returnValue = WebUI.verifyElementPresent(findTestObject(testObjectName), waitTime)
		if(returnValue){
			WebUI.selectOptionByValue(findTestObject(testObjectName), selectionValue, false)
			returnValue = WebUI.verifyOptionSelectedByLabel(findTestObject(testObjectName), selectedItem, false, waitTime)
			return returnValue

		} else {
			return false
		}
	}

	@Keyword
	public boolean selectFileAndUpLoad(String selectUploadFileTestObjectName, String uploadFileButtonTestObjectName, String fullUploadingFilePathname, int waitTime) {
		boolean returnValue = true

		returnValue = WebUI.verifyElementPresent(findTestObject(selectUploadFileTestObjectName), waitTime)
		if(returnValue){
			WebUI.uploadFile(findTestObject(selectUploadFileTestObjectName), fullUploadingFilePathname)
			returnValue = WebUI.click(findTestObject(uploadFileButtonTestObjectName))
			return returnValue
		} else {
			return false
		}
	}

	@Keyword
	public boolean setTextForIframeAndVerify(String iFrameTestObjectName, String textValue, int waitTime) {
		boolean returnValue = true

		returnValue = WebUI.verifyElementPresent(findTestObject(iFrameTestObjectName), waitTime)
		if(returnValue){
			'Clear default content'
			WebUI.clearText(findTestObject(iFrameTestObjectName))			
			//WebUI.setText(findTestObject(iFrameTestObjectName), textValue)
			
			'Get Browser type before set data for Iframe'
			WebUIDriverType executedBrowser = DriverFactory.getExecutedBrowser()
			
			
			if ((executedBrowser == WebUIDriverType.EDGE_DRIVER) || (executedBrowser == WebUIDriverType.IE_DRIVER)) {	
				'Set data for Browser types: EDGE or IE'				
				WebUI.executeJavaScript("arguments[0].innerText = arguments[1]", Arrays.asList(WebUiCommonHelper.findWebElement(findTestObject(iFrameTestObjectName), GlobalVariable.gl_objectWait5), textValue))
				returnValue = WebUI.verifyTextPresent(textValue, false)
				return returnValue
			} else {
				'For others cases'
				WebUI.sendKeys(findTestObject(iFrameTestObjectName), textValue)
				returnValue = WebUI.verifyTextPresent(textValue, false)
				return returnValue
			}
		} else {
			return false
		}
	}
	
	@Keyword
	public void editContentByJS(String textObjectName, String newContent) {
		WebUI.executeJavaScript("arguments[0].innerText = arguments[1]", Arrays.asList(WebUiCommonHelper.findWebElement(findTestObject(textObjectName), GlobalVariable.gl_objectWait5), newContent))
	}
	
	@Keyword
	public void sendNormalKeyFromKeyboard (String normalKey) {
		WebDriver driver = DriverFactory.getWebDriver()
		Actions sendKeysOperation = new Actions(driver).sendKeys(normalKey).build().perform()
	}
	@Keyword
	public void sendSpecialKeyFromKeyboard (Keys specialKey) {
		WebDriver driver = DriverFactory.getWebDriver()
		Actions sendKeysOperation = new Actions(driver).sendKeys(specialKey).build().perform()
	}
	
	@Keyword
	public boolean moveSliderFromKeyboardAndVerify (String sliderObjectName, int loopTimes, String labelObjectName, String expectedValue, int waitTime) {
		boolean returnValue = true
		
		
		returnValue = WebUI.verifyElementPresent(findTestObject(sliderObjectName), waitTime)
		if(returnValue){
			WebUI.focus(findTestObject(sliderObjectName))	
			
			'Get Browser type befor emoving slider '
			WebUIDriverType executedBrowser = DriverFactory.getExecutedBrowser()	
			if ((executedBrowser == WebUIDriverType.EDGE_DRIVER) || (executedBrowser == WebUIDriverType.IE_DRIVER)) {
				Robot robotKey = new Robot()
				for (int i = 1; i <= loopTimes; i++) {
					WebUI.click(findTestObject(sliderObjectName))
					robotKey.keyPress(KeyEvent.VK_RIGHT)
				}
				
				returnValue = WebUI.verifyElementText(findTestObject(labelObjectName), expectedValue)
				return returnValue
			
			}else{
				for (int j = 1; j <= loopTimes; j++) {
					WebUI.sendKeys(findTestObject(sliderObjectName), (Keys.RIGHT) as String)
				}
				
				returnValue = WebUI.verifyElementText(findTestObject(labelObjectName), expectedValue)
				return returnValue
			}			
		}else{
			return false
		}
		
	}
}
