<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Dropdown_header</name>
   <tag></tag>
   <elementGuidId>37ebd584-3dc9-48ee-a11d-c72ae9190f99</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[text()='Dropdown List']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='checkboxes']/input[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[text()='Dropdown List']</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <value>//form[@id='checkboxes']/input[1]</value>
   </webElementXpaths>
</WebElementEntity>
