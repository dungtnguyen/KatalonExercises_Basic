<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_Horizontal_Slider</name>
   <tag></tag>
   <elementGuidId>e0621e9d-65c9-4f8f-9132-2744b6708ce9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(@href, '/horizontal_slider')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/ul/li[6]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(@href, '/horizontal_slider')]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <value>//a[contains(@href, '/checkboxes')]</value>
   </webElementXpaths>
</WebElementEntity>
