<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_ChallengingDOM</name>
   <tag></tag>
   <elementGuidId>23a9c9ce-ac47-4dee-9ebd-f7577a1fafe6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(@href, '/challenging_dom')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/ul/li[6]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(@href, '/challenging_dom')]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <value>//a[contains(@href, '/checkboxes')]</value>
   </webElementXpaths>
</WebElementEntity>
