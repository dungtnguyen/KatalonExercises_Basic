<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_Drag_and_Drop</name>
   <tag></tag>
   <elementGuidId>e9627cfd-c6b9-4813-a30a-f1e858f38aff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(@href, '//drag_and_drop')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/ul/li[6]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(@href, '/drag_and_drop')]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <value>//a[contains(@href, '/checkboxes')]</value>
   </webElementXpaths>
</WebElementEntity>
