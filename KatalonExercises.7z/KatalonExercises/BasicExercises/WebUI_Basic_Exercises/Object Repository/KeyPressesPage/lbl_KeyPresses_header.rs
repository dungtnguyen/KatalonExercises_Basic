<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_KeyPresses_header</name>
   <tag></tag>
   <elementGuidId>4c9362cf-6c10-447a-ae4a-96624132338a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='checkboxes']/input[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[text()='Key Presses']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[text()='Key Presses']</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <value>//form[@id='checkboxes']/input[1]</value>
   </webElementXpaths>
</WebElementEntity>
