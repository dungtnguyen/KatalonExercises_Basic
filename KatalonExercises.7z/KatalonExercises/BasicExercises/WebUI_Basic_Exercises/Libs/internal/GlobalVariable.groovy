package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object gl_isOpenBrowser
     
    /**
     * <p></p>
     */
    public static Object gl_Url
     
    /**
     * <p></p>
     */
    public static Object gl_objectWait
     
    /**
     * <p></p>
     */
    public static Object gl_UploadingFilename
     
    /**
     * <p></p>
     */
    public static Object gl_Pathname
     
    /**
     * <p></p>
     */
    public static Object gl_objectWait5
     
    /**
     * <p></p>
     */
    public static Object gl_DownloadPathname
     
    /**
     * <p></p>
     */
    public static Object gl_DownloadsFilename
     
    /**
     * <p></p>
     */
    public static Object gl_objectWait2
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            gl_isOpenBrowser = selectedVariables['gl_isOpenBrowser']
            gl_Url = selectedVariables['gl_Url']
            gl_objectWait = selectedVariables['gl_objectWait']
            gl_UploadingFilename = selectedVariables['gl_UploadingFilename']
            gl_Pathname = selectedVariables['gl_Pathname']
            gl_objectWait5 = selectedVariables['gl_objectWait5']
            gl_DownloadPathname = selectedVariables['gl_DownloadPathname']
            gl_DownloadsFilename = selectedVariables['gl_DownloadsFilename']
            gl_objectWait2 = selectedVariables['gl_objectWait2']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
