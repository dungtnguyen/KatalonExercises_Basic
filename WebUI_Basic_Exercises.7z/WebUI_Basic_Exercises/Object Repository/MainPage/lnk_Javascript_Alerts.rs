<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_Javascript_Alerts</name>
   <tag></tag>
   <elementGuidId>f4087509-f0a2-4eed-a931-99b25a33963a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(@href, '/javascript_alerts')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/ul/li[6]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(@href, '/javascript_alerts')]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <value>//a[contains(@href, '/checkboxes')]</value>
   </webElementXpaths>
</WebElementEntity>
