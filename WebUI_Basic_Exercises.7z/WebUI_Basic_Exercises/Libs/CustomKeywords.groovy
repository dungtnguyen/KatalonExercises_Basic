
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import com.kms.katalon.core.testobject.TestObject

import org.openqa.selenium.Keys


def static "general_utilities.CommonLib.dragAndDrop"(
    	String sourceObject	
     , 	String destinationObject	) {
    (new general_utilities.CommonLib()).dragAndDrop(
        	sourceObject
         , 	destinationObject)
}

def static "general_utilities.CommonLib.verifySpecificColSorted"(
    	TestObject to	
     , 	String colIndex	) {
    (new general_utilities.CommonLib()).verifySpecificColSorted(
        	to
         , 	colIndex)
}

def static "general_utilities.CommonLib.openHomePage"(
    	String Url	) {
    (new general_utilities.CommonLib()).openHomePage(
        	Url)
}

def static "general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle"(
    	String linkTestObject	
     , 	String pageTitleTestObject	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).clickHyperlinkTextAndVerifyPageTitle(
        	linkTestObject
         , 	pageTitleTestObject
         , 	waitTime)
}

def static "general_utilities.CommonLib.checkOptionAndVerify"(
    	String testObjectName	
     , 	int verifyStatus	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).checkOptionAndVerify(
        	testObjectName
         , 	verifyStatus
         , 	waitTime)
}

def static "general_utilities.CommonLib.verifyValueOfTwoObjectsAfterDragAndDrop"(
    	String firstTestObjectxPath	
     , 	String secondTestObjectxPath	
     , 	String expectedValFirstTestObject	
     , 	String expectedValSecondTestObject	) {
    (new general_utilities.CommonLib()).verifyValueOfTwoObjectsAfterDragAndDrop(
        	firstTestObjectxPath
         , 	secondTestObjectxPath
         , 	expectedValFirstTestObject
         , 	expectedValSecondTestObject)
}

def static "general_utilities.CommonLib.selectDropdownListByLabelAndVerify"(
    	String testObjectName	
     , 	String selectionItem	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).selectDropdownListByLabelAndVerify(
        	testObjectName
         , 	selectionItem
         , 	waitTime)
}

def static "general_utilities.CommonLib.selectDropdownListByIndexAndVerify"(
    	String testObjectName	
     , 	int indexItem	
     , 	String selectedItem	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).selectDropdownListByIndexAndVerify(
        	testObjectName
         , 	indexItem
         , 	selectedItem
         , 	waitTime)
}

def static "general_utilities.CommonLib.selectDropdownListByValueAndVerify"(
    	String testObjectName	
     , 	String selectionValue	
     , 	String selectedItem	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).selectDropdownListByValueAndVerify(
        	testObjectName
         , 	selectionValue
         , 	selectedItem
         , 	waitTime)
}

def static "general_utilities.CommonLib.selectFileAndUpLoad"(
    	String selectUploadFileTestObjectName	
     , 	String uploadFileButtonTestObjectName	
     , 	String fullUploadingFilePathname	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).selectFileAndUpLoad(
        	selectUploadFileTestObjectName
         , 	uploadFileButtonTestObjectName
         , 	fullUploadingFilePathname
         , 	waitTime)
}

def static "general_utilities.CommonLib.setTextForIframeAndVerify"(
    	String iFrameTestObjectName	
     , 	String textValue	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).setTextForIframeAndVerify(
        	iFrameTestObjectName
         , 	textValue
         , 	waitTime)
}

def static "general_utilities.CommonLib.editContentByJS"(
    	String textObjectName	
     , 	String newContent	) {
    (new general_utilities.CommonLib()).editContentByJS(
        	textObjectName
         , 	newContent)
}

def static "general_utilities.CommonLib.sendNormalKeyFromKeyboard"(
    	String normalKey	) {
    (new general_utilities.CommonLib()).sendNormalKeyFromKeyboard(
        	normalKey)
}

def static "general_utilities.CommonLib.sendSpecialKeyFromKeyboard"(
    	Keys specialKey	) {
    (new general_utilities.CommonLib()).sendSpecialKeyFromKeyboard(
        	specialKey)
}

def static "general_utilities.CommonLib.moveSliderFromKeyboardAndVerify"(
    	String sliderObjectName	
     , 	int loopTimes	
     , 	String labelObjectName	
     , 	String expectedValue	
     , 	int waitTime	) {
    (new general_utilities.CommonLib()).moveSliderFromKeyboardAndVerify(
        	sliderObjectName
         , 	loopTimes
         , 	labelObjectName
         , 	expectedValue
         , 	waitTime)
}
