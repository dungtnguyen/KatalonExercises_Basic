import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.TearDown
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import general_utilities.CommonLib as CommonLib
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.By as By
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory


////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: UIB-11 - Verify Table
//	Description Details:
//	Actions:
//	1	Go to https://the-internet.herokuapp.com/
//		Select 'Sortable Data Tables' link
//
//	2	Verify header at column 3 on Table 1
//	3	Verify cell value (row 3, column 2) on Table 1
//	4	Verify cell value (row 2, column 4) on Table 1
//	5	Click on 'Email' header column on Table 2
//
//	Expected Results:
//	1	'Data Tables header title is displayed
//	2	The header name is 'Email'
//	3	Cell value is 'Jason'
//	4	Cell value is '$51.00'
//	5	The Email column sort by alphabetical from A-Z
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////

'Step 1: Go to https://the-internet.herokuapp.com/, click on the hyperlink: Sortable Data Tables and verify that the page: Data Tables header title is displayed '
CustomKeywords.'general_utilities.CommonLib.openHomePage'(GlobalVariable.gl_Url)
CustomKeywords.'general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle'('MainPage/lnk_Sortable_Data_Tables', 'Sortable_Data_TablesPage/lbl_Data_Tables_header', GlobalVariable.gl_objectWait)


'Step 2: Verify header at column 3 on Table 1 and verify that The header name is Email'
String ExpectedHeaderText_Name = "Email"
WebDriver driver = DriverFactory.getWebDriver()

'To locate table'
WebElement Header_Table = driver.findElement(By.xpath("//table[@id='table1']/thead/tr"))

'To locate header of table it will capture all the header available in the table'
List<WebElement> HeaderCount_Table = Header_Table.findElements(By.tagName('th'))

'Count no of header in table, get text and compare'
String AtualHeaderText_Name = HeaderCount_Table.get(2).getText()
WebUI.verifyEqual(AtualHeaderText_Name, ExpectedHeaderText_Name)
KeywordLogger log = new KeywordLogger()
log.logInfo("The header name (1,3) is : " + AtualHeaderText_Name)


'Step 3: Verify cell value (row 3, column 2) on Table 1 and verify that Cell value is Jason'
String ExpectedCellText = "Jason"
WebElement Row_Table = driver.findElement(By.xpath("//table[@id='table1']/tbody"))

'To locate cell of table it will capture '
List<WebElement> RowCount_Table = Row_Table.findElements(By.tagName('tr'))
List<WebElement> Columns_row = RowCount_Table.get(2).findElements(By.tagName('td'))
String ActualCellText = Columns_row.get(1).getText()
WebUI.verifyEqual(ActualCellText, ExpectedCellText)
log.logInfo("The value of cell(3,2) is : " + ActualCellText)


'Step 4: Verify cell value (row 2, column 4) on Table 1 and verify that Cell value is $51.00'
ExpectedCellText = "\$51.00"
Columns_row = RowCount_Table.get(1).findElements(By.tagName('td'))
ActualCellText = Columns_row.get(3).getText()
WebUI.verifyEqual(ActualCellText, ExpectedCellText)
log.logInfo("The value of cell(2,4) is : " + ActualCellText)

'Step 5: Click on Email header column on Table 2 and verify that The Email column sort by alphabetical from A-Z'
WebElement Table02 = driver.findElement(By.xpath("//table[@id='table2']/thead/tr"))
Table02.findElement(By.xpath("./th[3]")).click()

CustomKeywords.'general_utilities.CommonLib.verifySpecificColSorted'(findTestObject('Sortable_Data_TablesPage/tbl_Table2'), "3")



