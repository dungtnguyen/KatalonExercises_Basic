import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.configuration.RunConfiguration as RunConfiguration
import com.kms.katalon.core.annotation.SetUp
import com.kms.katalon.core.annotation.TearDown
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import general_utilities.CommonLib


////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: UIB-04 - Verify File Upload
//	Description Details:
//	Actions:
//	1	"Go to https://the-internet.herokuapp.com/
//		Select 'File Upload' link"
//	2	"Click on 'Choose File' button and upload a png file 'Ex: c:\abc.png'
//		Click on 'Upload' button"
//
//	Expected Results:
//	1.	File Uploader header title is displayed
//	2.	The png file is upload successful
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////

'Step 1: Open Browser and Go to https://the-internet.herokuapp.com/, Select the link: File Upload and verify thatFile Uploader header title is displayed'
CustomKeywords.'general_utilities.CommonLib.openHomePage'(GlobalVariable.gl_Url)
CustomKeywords.'general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle'('MainPage/lnk_FileUpload', 'FileUpLoadPage/lbl_File_Uploader_header', GlobalVariable.gl_objectWait)


'Step 2: Click on the button: Choose File and upload a png file: D:\\KatalonExercises\\BasicExercises\\WebUI_Basic_Exercises\\AngularJS.png, Click on the button: Upload button and verify that the png file is uploaded successful'
localvar_fullUploadingFilePathname = GlobalVariable.gl_Pathname + '\\' + GlobalVariable.gl_UploadingFilename
CustomKeywords.'general_utilities.CommonLib.selectFileAndUpLoad'('FileUpLoadPage/btn_ChooseFileUpload', 'FileUpLoadPage/btn_Upload', localvar_fullUploadingFilePathname, GlobalVariable.gl_objectWait)

'Verify the png file is uploaded successful'
WebUI.verifyElementPresent(findTestObject('FileUpLoadPage/lbl_File_Uploaded_header'), GlobalVariable.gl_objectWait)
WebUI.verifyTextPresent(GlobalVariable.gl_UploadingFilename, false)

@SetUp
def setUp() {
	'Get the relative path name location'
	GlobalVariable.gl_Pathname = RunConfiguration.getProjectDir().replace('/', '\\') + '\\Data Files\\Images'	
}
