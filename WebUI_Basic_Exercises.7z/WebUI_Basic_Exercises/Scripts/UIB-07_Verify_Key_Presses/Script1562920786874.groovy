import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import general_utilities.CommonLib
import com.kms.katalon.core.annotation.TearDown as TearDown
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.By
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory


////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: UIB-07 - Verify Key Presses
//	Description Details:
//	Actions:
//	1. 	"Go to https://the-internet.herokuapp.com/
//		Select 'Key Presses' link
//
//	2	Presses 'G' key
//	3	Presses 'ENTER' key
//	4	Presses 'TAB' key
//
//	Expected Results:
//	1	Key Presses header title is displayed
//	2	Message: You entered: G
//	3	Message: You entered: ENTER
//	4	Message: You entered: TAB

///////////////////////////////////////////////////////////////////////////////////////////////////////////


'Step 1: Open Browser and Go to https://the-internet.herokuapp.com/, click on the hyperlink: Challenging DOM and verify that the Key Presses header title is displayed'
CustomKeywords.'general_utilities.CommonLib.openHomePage'(GlobalVariable.gl_Url)
CustomKeywords.'general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle'('MainPage/lnk_KeyPresses', 'KeyPressesPage/lbl_KeyPresses_header', GlobalVariable.gl_objectWait)


'Step 2: Presses the key g and verify the message: You entered: G'
String lcalvar_CharKey = 'g'
CustomKeywords.'general_utilities.CommonLib.sendNormalKeyFromKeyboard'(lcalvar_CharKey)
WebUI.verifyElementText(findTestObject('KeyPressesPage/lbl_Result'), 'You entered: G')

'Step 3: Presses the key ENTER and verify the message: You entered: ENTER'
Keys lcalvar_EnterKey = Keys.ENTER
CustomKeywords.'general_utilities.CommonLib.sendSpecialKeyFromKeyboard'(lcalvar_EnterKey)
WebUI.verifyElementText(findTestObject('KeyPressesPage/lbl_Result'), 'You entered: ENTER') 

'Step 4: Presses the key TAB and verify the message: You entered: TAB'
Keys lcalvar_TabKey = Keys.TAB
CustomKeywords.'general_utilities.CommonLib.sendSpecialKeyFromKeyboard'(lcalvar_TabKey)
WebUI.verifyElementText(findTestObject('KeyPressesPage/lbl_Result'), 'You entered: TAB')
