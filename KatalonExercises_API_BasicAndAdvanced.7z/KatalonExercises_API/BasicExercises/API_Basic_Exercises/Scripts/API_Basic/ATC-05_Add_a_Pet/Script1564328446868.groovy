import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

import com.kms.katalon.core.testobject.RequestObject as RequestObject
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject
import groovy.json.JsonSlurper
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: ATC-05 - Add a Pet
//	Description Details:
//	Actions:
//	1. 	 Send POST request: https://petstore.swagger.io/v2/pet
//		Body:
//			{
//			  "id": 2,
//			  "category": {
//				"id": 2,
//				"name": "name2"
//			  },
//			  "name": "name2",
//			  "photoUrls": [
//				"ArrayItem2"
//			  ],
//			  "tags": [
//				{
//				  "id": 2,
//				  "name": "name2"
//				}
//			  ],
//			  "status": "available;pending;sold"
//			}
//
//	2	Verify Response Status Code is correctly
//
//	3	Verify Id node matches with Id value in body
//
//	4	Verify Name node matches with Name value in body
//
//	Expected Results:
//	2.	Status code is 200 OK
//	3.	Id value is 2
//	4.	Name value is name2
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////

def jsonSlurper = new JsonSlurper()

'Step 1: Send POST request: https://petstore.swagger.io/v2/pet\r\nBody:\r\n{\r\n  "id": 2,\r\n  "category": {\r\n    "id": 2,\r\n    "name": "name2"\r\n  },\r\n  "name": "name2",\r\n  "photoUrls": [\r\n    "ArrayItem2"\r\n  ],\r\n  "tags": [\r\n    {\r\n      "id": 2,\r\n      "name": "name2"\r\n    }\r\n  ],\r\n  "status": "available;pending;sold"\r\n}'
ResponseObject ResponseOutPut = WS.sendRequest(findTestObject('ORepo_API_Basic/05_Add_a_Pet', [('idPara') : idActValue]))

'Step 2: Verify Response Status Code is correctly, Status code is 200 OK'
WS.verifyResponseStatusCode(ResponseOutPut, 200)

'Step 3: Verify Id node matches with Id value in body,\tId value is 2'
def jsonParserText = jsonSlurper.parseText(ResponseOutPut.getResponseText())
KeywordLogger log = new KeywordLogger()
if (jsonParserText.id != idExpValue) {
    log.logError("The Id node doesn't matche with the Id value in body. The Id value in body is: " + jsonParserText.id)
}

'Step 4: Verify Name node matches with Name value in body\tName value is name2'
if (jsonParserText.name != petNameExpValue) {
    log.logError("The Id node doesn't matche with the Id value in body. The name value in body is: " + jsonParserText.name)
}

