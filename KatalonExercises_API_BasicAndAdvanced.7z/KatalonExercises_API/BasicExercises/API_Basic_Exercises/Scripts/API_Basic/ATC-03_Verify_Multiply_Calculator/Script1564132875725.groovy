import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testobject.RequestObject as RequestObject
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: ATC-03 - Verify Multiply Calculator
//	Description Details:
//	Actions:
//	1. 	Send a SOAP to call operation 'Multiply': Ex: n1 = 12; n2 = 2, http://webservice.toscacloud.com/Soap11.svc?wsdl
//		Body:
//		<?xml version="1.0" encoding="utf-8"?>
//		<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
//			<s:Body>
//				<Multiply xmlns="http://CalculatorService">
//					<n1>1</n1>
//					<n2>1</n2>
//				</Multiply>
//			</s:Body>
//		</s:Envelope>
//
//	2	Verify Response Status Code is correctly
//
//	3	Verify DivideResult value is correctly value is correctly
//
//
//	Expected Results:
//	2.	Status code is 200 OK
//	3.	'MultiplyResult is 24
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////

'Step 1:   Send a SOAP to call operation \'Multiply\': Ex: n1 = 12; n2 = 2 \r\n http://webservice.toscacloud.com/Soap11.svc?wsdl\r\nBody:\r\n<?xml version="1.0" encoding="utf-8"?>\r\n<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">\r\n  <s:Body>\r\n    <Multiply xmlns="http://CalculatorService">\r\n      <n1>1</n1>\r\n      <n2>1</n2>\r\n    </Multiply>\r\n  </s:Body>\r\n</s:Envelope>'
ResponseObject ResponseOutPut = WS.sendRequest(findTestObject('ORepo_API_Basic/03_Request_Multiple', [('multiplePara01') : multipleActValue01, ('multiplePara02') : multipleActValue02]))

'Step2: Verify Response Status Code is correctly and verify that Status code is 200 OK'
WS.verifyEqual(ResponseOutPut.getStatusCode(), 200)

'Step 3: Verify MultiplyResult value is correctly and verify that MultiplyResult is 24'
WS.verifyElementText(ResponseOutPut, 'MultiplyResponse.MultiplyResult', (multipleActValue01 * multipleActValue02).toString())
KeywordLogger log = new KeywordLogger()
log.logInfo("The Multiply Result is: " + (multipleActValue01 * multipleActValue02).toString())