import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testobject.RequestObject as RequestObject
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import groovy.json.JsonSlurper as JsonSlurper

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: API-05 - Get Coffee info with not existing Id
//	Description Details:
//	Actions:
//	1	SeSend GET request (Token get at API-01: Bearer {TokenKeys}) http://webservice.toscacloud.com/rest/api/Coffees_V2/{id}  (Ex: 100)
//	
//	2	Verify Response Status Code is correctly
//
//	3	Verify null content
//
//	Expected Results:
//	2.	Status code is 200 OK
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////
def jsonSlurper = new JsonSlurper()

GlobalVariable.gl_ID_No_Existing = GlobalVariable.gl_ID + 100

'Step 1:  Send GET request (Token get at API-01: Bearer {TokenKeys}) http://webservice.toscacloud.com/rest/api/Coffees_V2/{id}  (Ex: 100)'
ResponseObject ResponseOutPut = WS.sendRequest(findTestObject('ORepo_API_Advance/05-Get_Coffee_info_with_no_existing_Id', [
            ('bearerTokenPara') : GlobalVariable.gl_Token, ('idPara') : GlobalVariable.gl_ID_No_Existing]))

'Step2: Verify Response Status Code is correctly and verify that Status code is 200 OK'
WS.verifyEqual(ResponseOutPut.getStatusCode(), 200)

'Step 3: Verify null content'
KeywordLogger log = new KeywordLogger()

if (ResponseOutPut.responseText != 'null1') {
    log.logError('The contents of Body  response is not null. It\'s actual value is: ' + ResponseOutPut.responseText)
}

