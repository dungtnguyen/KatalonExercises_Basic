import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testobject.RequestObject as RequestObject
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import groovy.json.JsonSlurper as JsonSlurper

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: API-03 - Get Coffee info with existing Id
//	Description Details:
//	Actions:
//	1	Send GET request (Token get at API-01: Bearer {TokenKeys}) http://webservice.toscacloud.com/rest/api/Coffees_V2/{id}
//	
//	2	Verify Response Status Code is correctly
//
//	3	Verify Description and Name value are correctly
//
//	Expected Results:
//	2.	Status code is 200 OK
//
//	3.	"Description": "DescriptionXX"
//		"Name": "NameXX"
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////
def jsonSlurper = new JsonSlurper()

'Step 1:  Send GET request (Token get at API-01: Bearer {TokenKeys}) http://webservice.toscacloud.com/rest/api/Coffees_V2'
ResponseObject ResponseOutPut = WS.sendRequest(findTestObject('ORepo_API_Advance/06_Get_All_Coffees', [('bearerTokenPara') : GlobalVariable.gl_Token]))

'Step2: Verify Response Status Code is correctly and verify that Status code is 200 OK'
WS.verifyEqual(ResponseOutPut.getStatusCode(), 200)

'Step 3: Get the latest Coffee:  Id, Description and Name'
def jsonParserContent   = jsonSlurper.parseText(ResponseOutPut.getResponseBodyContent())
int  totalItems = jsonParserContent.size()
KeywordLogger log = new KeywordLogger()

if (totalItems != 0){
	String descriptionName = jsonParserContent.Description[totalItems-1]
	int idName = jsonParserContent.Id[totalItems-1]
	String nameName = jsonParserContent.Name[totalItems-1]
	log.logInfo('The value of descriptionName, Id and Name are: ' + descriptionName + ", " + idName + ", " + nameName)
	
'Step 4: Send GET request (Token get at API-01: Bearer {TokenKeys}) http://webservice.toscacloud.com/rest/api/Coffees_V2/{ latest id} and verify that Description and Name value are the same values at step 3'
	ResponseOutPut = WS.sendRequest(findTestObject('ORepo_API_Advance/03-Get_Coffee_info_with_existing_Id', [('bearerTokenPara') : GlobalVariable.gl_Token
            , ('idPara') : idName]))
	
	WS.verifyEqual(ResponseOutPut.getStatusCode(), 200)
	
	def jsonParserText = jsonSlurper.parseText(ResponseOutPut.getResponseText())
	String actDescriptionName = jsonParserText.Description
	String actnameName = jsonParserText.Name
	
	if ((actDescriptionName != descriptionName) && (actnameName != nameName )) {
		log.logError('The Description and Name value are not the same values at step 3. Its values is: ' + actDescriptionName  + ", " + actnameName)	
	}else {
		log.logInfo('The Description and Name value are the same values at step 3. Its values is: ' + actDescriptionName  + ", " + actnameName)
	}
	
}else{
	log.logError('The value of totalItems is empty')
}




//KeywordLogger log = new KeywordLogger()
//
//if (jsonParserText.Description != 'DescriptionXX') {
//    log.logError('The Description attribute is not expectation. It\'s actual value is: ' + jsonParserText.Description)
//}
//
//if (jsonParserText.Name != 'NameXX') {
//    log.logError('The Name attribute is not expectation. It\'s actual value is: ' + jsonParserText.Name)
//}
//
//'Step 4: Send GET request (Token get at API-01: Bearer {TokenKeys}) http://webservice.toscacloud.com/rest/api/Coffees_V2/{ latest id} and verify that Description and Name value are the same values at step 3'
//gl_ID = jsonParserText.Id
//
//log.logInfo('The value of the coffee Id is: ' + jsonParserText.Id)
//
