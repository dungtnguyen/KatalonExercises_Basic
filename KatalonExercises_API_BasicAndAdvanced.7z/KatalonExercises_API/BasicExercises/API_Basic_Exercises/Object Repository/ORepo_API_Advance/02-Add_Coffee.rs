<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>02-Add_Coffee</name>
   <tag></tag>
   <elementGuidId>42684fbf-6565-475b-9910-cf78d0354aef</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;{\n  \&quot;Description\&quot;: \&quot;${descriptionPara}\&quot;,\n  \&quot;Id\&quot;: 0,\n  \&quot;Name\&quot;: \&quot;${namePara}\&quot;\n}&quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>${bearerTokenPara}</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>GET</restRequestMethod>
   <restUrl>http://webservice.toscacloud.com/rest/api/Coffees_V2</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <variables>
      <defaultValue>'Bearer f00b5b74-3e11-4e77-af8b-94efd7f88d64'</defaultValue>
      <description></description>
      <id>ba2922df-a224-4f77-9383-0a3c3cb2f714</id>
      <masked>false</masked>
      <name>bearerTokenPara</name>
   </variables>
   <variables>
      <defaultValue>'DescriptionXX'</defaultValue>
      <description></description>
      <id>850e5772-bdb8-4652-8113-4a7f1140a191</id>
      <masked>false</masked>
      <name>descriptionPara</name>
   </variables>
   <variables>
      <defaultValue>'NameXX'</defaultValue>
      <description></description>
      <id>16b3de9b-864c-4ac0-9ff2-f677413f9896</id>
      <masked>false</masked>
      <name>namePara</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()



WS.verifyResponseStatusCode(response, 200)

assertThat(response.getStatusCode()).isEqualTo(200)
</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
