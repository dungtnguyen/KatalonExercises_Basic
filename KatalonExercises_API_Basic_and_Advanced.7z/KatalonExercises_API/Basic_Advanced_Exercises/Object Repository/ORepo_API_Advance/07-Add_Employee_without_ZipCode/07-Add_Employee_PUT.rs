<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>07-Add_Employee_PUT</name>
   <tag></tag>
   <elementGuidId>9b528dc9-4782-4070-94c4-17f6110896eb</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;{\n  \&quot;Address\&quot;: {\n    \&quot;City\&quot;: \&quot;${cityXPara}\&quot;,\n    \&quot;Country\&quot;: \&quot;${countryXPara}\&quot;,\n    \&quot;Street\&quot;: \&quot;${streetXPara}\&quot;\n  },\n  \&quot;FirstName\&quot;: \&quot;${firstNameXPara}\&quot;,\n  \&quot;LastName\&quot;: \&quot;${lastNameXPara}\&quot;\n}&quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>${bearerTokenPara}</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>PUT</restRequestMethod>
   <restUrl>http://webservice.toscacloud.com/rest/api/Employee_V2/</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>ba2922df-a224-4f77-9383-0a3c3cb2f714</id>
      <masked>false</masked>
      <name>bearerTokenPara</name>
   </variables>
   <variables>
      <defaultValue>'CityX'</defaultValue>
      <description></description>
      <id>7486840e-bca7-405e-bdad-0b59e102f5c7</id>
      <masked>false</masked>
      <name>cityXPara</name>
   </variables>
   <variables>
      <defaultValue>'CountryX'</defaultValue>
      <description></description>
      <id>bb5477d5-f196-484b-a64e-5452e75ff883</id>
      <masked>false</masked>
      <name>countryPara</name>
   </variables>
   <variables>
      <defaultValue>'StreetX'</defaultValue>
      <description></description>
      <id>162718c6-2d48-4eec-92af-a07bb7459664</id>
      <masked>false</masked>
      <name>streetPara</name>
   </variables>
   <variables>
      <defaultValue>'FirstNameX'</defaultValue>
      <description></description>
      <id>23557dda-c8c7-421b-ae37-80bbe06a157a</id>
      <masked>false</masked>
      <name>firstNamePara</name>
   </variables>
   <variables>
      <defaultValue>'LastNameX'</defaultValue>
      <description></description>
      <id>90af057e-a1e5-4b85-9828-4d4a16081e4e</id>
      <masked>false</masked>
      <name>lastNamePara</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()



WS.verifyResponseStatusCode(response, 200)

assertThat(response.getStatusCode()).isEqualTo(200)

</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
