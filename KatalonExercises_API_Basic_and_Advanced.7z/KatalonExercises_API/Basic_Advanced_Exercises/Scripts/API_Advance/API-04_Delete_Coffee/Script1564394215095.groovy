import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testobject.RequestObject as RequestObject
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import groovy.json.JsonSlurper as JsonSlurper

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: API-04 - Delete Coffee info with existing Id
//	Description Details:
//	Actions:
//	1	Send DELETE request (Token get at API-01: Bearer {TokenKeys}) http://webservice.toscacloud.com/rest/api/Coffees_V2/{id}
//	
//	2	Verify Response Status Code is correctly
//
//	Expected Results:
//	2.	Status code is 204 No Content
//
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////
'Step 1:  Send DELETE request (Token get at API-01: Bearer {TokenKeys}) http://webservice.toscacloud.com/rest/api/Coffees_V2/{id}'
ResponseObject ResponseOutPut = WS.sendRequest(findTestObject('ORepo_API_Advance/04-Delete_Coffee', [('bearerTokenPara') : GlobalVariable.gl_Token
            , ('idPara') : GlobalVariable.gl_ID]))

'Step2: Verify Response Status Code is correctly and verify that Status code is 204'
WS.verifyEqual(ResponseOutPut.getStatusCode(), 204)

'Step 3: Verify null content'
KeywordLogger log = new KeywordLogger()
if (ResponseOutPut.responseText != "") {	
	log.logError('The contents of Body  response is not null. It\'s actual value is: ' + ResponseOutPut.responseText)
}