import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testobject.RequestObject as RequestObject
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import groovy.json.JsonSlurper as JsonSlurper

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: API-07 - Add Employee without ZipCode 
//	Description Details:
//	Actions:
//	1	Send PUT request (Token get at API-01: Bearer {TokenKeys}) http://webservice.toscacloud.com/rest/api/Employee_V2
//		Body:
//		{
//		  "Address": {
//			"City": "CityX",
//			"Country": "CountryX",
//			"Street": "StreetX"
//		  },
//	
//	2	Send GET request (Token get at API-01: Bearer {TokenKeys}) http://webservice.toscacloud.com/rest/api/Employee_V2
//
//	3	Verify Response Status Code is correctly
//
//	4	Verify above Emplyee did not exist
//
//	Expected Results:
//	3.	Status code is 200 OK
//
//	4.	'"FirstName": "FirstNameX", "LastName": "LastNameX" did not exist
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////
def jsonSlurper = new JsonSlurper()

'Step 1:  Send PUT request (Token get at API-01: Bearer {TokenKeys}) http://webservice.toscacloud.com/rest/api/Employee_V2\r\nBody:\r\n{\r\n  "Address": {\r\n    "City": "CityX",\r\n    "Country": "CountryX",\r\n    "Street": "StreetX"\r\n  },\r\n'
ResponseObject ResponseOutPut = WS.sendRequest(findTestObject('ORepo_API_Advance/07-Add_Employee_without_ZipCode/07-Add_Employee_PUT', [
		('bearerTokenPara') : GlobalVariable.gl_Token, ('cityXPara') : cityXActValue, 
		('cityXPara') : cityXActValue, ('countryXPara') : countryXActValue, 
		('streetXPara') : streetXActValue, ('firstNameXPara') : firstNameXActValue, 
		('lastNameXPara') : lastNameXActValue]))

'Verify Response Status Code is correctly and verify that Status code is 200 OK'
WS.verifyEqual(ResponseOutPut.getStatusCode(), 200)

'Step2: Send GET request (Token get at API-01: Bearer {TokenKeys}) http://webservice.toscacloud.com/rest/api/Employee_V2'
ResponseOutPut = WS.sendRequest(findTestObject('ORepo_API_Advance/07-Add_Employee_without_ZipCode/07-Add_Employee_GET', [('bearerTokenPara') : GlobalVariable.gl_Token]))

'Step 3: Verify Response Status Code is correctly and verify that Status code is 200 OK'
WS.verifyEqual(ResponseOutPut.getStatusCode(), 200)


'Step 4: Verify above Emplyee did not exist verify that: \"FirstName\": \"FirstNameX\", \"LastName\": \"LastNameX\" did not exist'
def jsonParserContent   = jsonSlurper.parseText(ResponseOutPut.getResponseBodyContent())

KeywordLogger log = new KeywordLogger()
if (jsonParserContent != null) {	
	'Get total Employee item from relevant returned page and verify first name and lasst name accordingly'
	int totalItems = jsonParserContent.size()
		
	for(int i=0;i<= totalItems-1; i++){
		if ((jsonParserContent.FirstName[i] == 'FirstNameX') || (jsonParserContent.LastName[i] == 'LastNameX')){
			log.logError('The Emplyee list exists one. It\'s actual value is: ' + jsonParserContent.FirstName[i] + ', ' + jsonParserContent.LastName[i])
		}
	}
} else {
	log.logError('The contents of Body  response is null. It\'s actual value is: ')
}