import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testobject.RequestObject as RequestObject
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import groovy.json.JsonSlurper as JsonSlurper

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: API-02 - Add Coffee
//	Description Details:
//	Actions:
//	Send POST request (Token get at API-01: Bearer {TokenKeys}) http://webservice.toscacloud.com/rest/api/Coffees_V2
//	Body:
//	{
//	  "Description": "DescriptionXX",
//	  "Name": "NameXX"
//	}
//
//	2	Verify Response Status Code is correctly
//
//	3	Verify Description and Name value are correctly
//
//	4	Get Id value to use for below test cases
//
//	Expected Results:
//	2.	Status code is 200 OK
//
//	3.	"Description": "DescriptionXX"
//		"Name": "NameXX"
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////
def jsonSlurper = new JsonSlurper()

'Step 1:  Send POST request (Token get at API-01: Bearer {TokenKeys}) http://webservice.toscacloud.com/rest/api/Coffees_V2\r\nBody:\r\n{\r\n  "Description": "DescriptionXX",\r\n  "Name": "NameXX"\r\n}'
ResponseObject ResponseOutPut = WS.sendRequest(findTestObject('ORepo_API_Advance/02-Add_Coffee', [('bearerTokenPara') : GlobalVariable.gl_Token , ('descriptionPara') :
		descriptionActValue, ('namePara') : nameActValue]))

//ResponseObject ResponseOutPut = WS.sendRequest(findTestObject('ORepo_API_Advance/02-Add_Coffee', [('descriptionPara') : descriptionActValue, ('namePara') : nameActValue]))

'Step2: Verify Response Status Code is correctly and verify that Status code is 200 OK'
WS.verifyEqual(ResponseOutPut.getStatusCode(), 200)

'Step 3: Verify Description and Name value are correctly verify that \'"Description": "DescriptionXX"\r\n "Name": "NameXX"'
def jsonParserText = jsonSlurper.parseText(ResponseOutPut.getResponseText())
KeywordLogger log = new KeywordLogger()

if ((jsonParserText.Description == '') || (jsonParserText.Description != 'DescriptionXX')) {
    log.logError('The Description attribute is not expectation. It\'s actual value is: ' + jsonParserText.Description)
} 

if ((jsonParserText.Name == '') || (jsonParserText.Name != 'NameXX')) {
	log.logError('The Name attribute is not expectation. It\'s actual value is: ' + jsonParserText.Name)
}


'Step 4: Get ID value to use for below test cases'
GlobalVariable.gl_ID = jsonParserText.Id
log.logInfo('The value of the coffee Id is: ' + jsonParserText.Id)