import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testobject.RequestObject as RequestObject
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject
import groovy.json.JsonSlurper as JsonSlurper
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: ATC-07 - Delete a Pet
//	Description Details:
//	Actions:
//	1. 	 Send DELETE request: https://petstore.swagger.io/v2/pet/{petId}
//			Ex: petId = 2
//
//	2	Verify Response Status Code is correctly
//
//	3	Send GET request to get deleted PET above : https://petstore.swagger.io/v2/pet/{petId}
//
//
//	4	Verify Response Status Code is correctly
//
//	5	Verify Response message
//
//	Expected Results:
//	2.	Status code is 200 OK
//	3.
//	4.	Status code is 404 Not found
//	5.	Message value is Pet not found
///////////////////////////////////////////////////////////////////////////////////////////////////////////

def jsonSlurper = new JsonSlurper()

'Step 1: Send DELETE request: https://petstore.swagger.io/v2/pet/{petId}\r\nEx: petId = 2'
ResponseObject ResponseOutPut = WS.sendRequest(findTestObject('07_Delete_a_Pet', [('petIdPara') : petIdActValue]))

'Step 2: Verify Response Status Code is correctly, Status code is 200 OK'
WS.verifyResponseStatusCode(ResponseOutPut, 200)

'Step 3: Send GET request to get deleted PET above : https://petstore.swagger.io/v2/pet/{petId}\r\n\r\n'
ResponseOutPut = WS.sendRequest(findTestObject('06_Get_a_Pet', [('petIdPara') : petIdActValue]))

'Step 4: Verify Response Status Code is correctly\tStatus code is 404 Not found\r\n\r\n'
WS.verifyResponseStatusCode(ResponseOutPut, 404)

def jsonParserText = jsonSlurper.parseText(ResponseOutPut.getResponseText())

KeywordLogger log = new KeywordLogger()
if (jsonParserText.message != responeExpectMessage) {
    log.logError('The actual message value is : ' + jsonParserText.message)
}