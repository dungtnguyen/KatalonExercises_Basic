<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_File_Uploader_header</name>
   <tag></tag>
   <elementGuidId>11d47f82-bcc3-4ed6-88ec-9bbdd422a5a7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[text()='File Uploader']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='checkboxes']/input[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[text()='File Uploader']</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <value>//form[@id='checkboxes']/input[1]</value>
   </webElementXpaths>
</WebElementEntity>
