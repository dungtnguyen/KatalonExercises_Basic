import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.TearDown
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import general_utilities.CommonLib
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.By
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.annotation.TearDown as TearDown

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	TC Name: UIB-02 - Verify Drag and Drop
//	Description Details:
//	Actions:
//	1. 	"Go to https://the-internet.herokuapp.com/
//		Select 'Drag and Drop' link"
//
//	2	Drag and Drop column A to column B
//
//	Expected Results:
//	1.	Drag and Drop header title is displayed
//	2.	"Column A changed to column B
//		Column B changed to column A"
///////////////////////////////////////////////////////////////////////////////////////////////////////////


'Step1: Open Browser and Go to https://the-internet.herokuapp.com/, click on the hyperlink: Drag and Drop and verify that the Drag and Drop page is displayed'
CustomKeywords.'general_utilities.CommonLib.openHomePage'(GlobalVariable.gl_Url)
CustomKeywords.'general_utilities.CommonLib.clickHyperlinkTextAndVerifyPageTitle'('MainPage/lnk_Drag_and_Drop', 'DragAndDropPage/lbl_Drag_and_Drop_header', GlobalVariable.gl_objectWait)


'Step2: Drag column A drop to coulumn B and verify that Column A changed to column B and Column B changed to column A'
CustomKeywords.'general_utilities.CommonLib.dragAndDrop'(findTestObject('DragAndDropPage/tbl_A'), findTestObject('DragAndDropPage/tbl_B'))

String var_xPathNameColumnA = "//div[@id='column-a'" + "]" + "/header"
String var_xPathNameColumnB = "//div[@id='column-b'" + "]" + "/header"

CustomKeywords.'general_utilities.CommonLib.verifyValueOfTwoObjectsAfterDragAndDrop'(var_xPathNameColumnA, var_xPathNameColumnB, 'B', 'A')

@TearDown
def tearDown() {
	'Close browser'
	WebUI.closeBrowser()
}