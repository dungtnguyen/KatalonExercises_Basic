import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testobject.RequestObject as RequestObject
import com.kms.katalon.core.testobject.ResponseObject as ResponseObject

'Step 1:  Send a SOAP to call operation \'Add\': Ex: n1 = 12; n2 = 2 \r\n http://webservice.toscacloud.com/Soap11.svc?wsdl\r\nBody:\r\n<?xml version="1.0" encoding="utf-8"?>\r\n<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">\r\n  <s:Body>\r\n    <Add xmlns="http://CalculatorService">\r\n      <n1>12</n1>\r\n      <n2>3</n2>\r\n    </Add>\r\n  </s:Body>\r\n</s:Envelope>'
ResponseObject ResponseOutPut = WS.sendRequest(findTestObject('ATC_01_Request_Add', [('addPara01') : addActValue01
            , ('addPara02') : addActValue02]))

'Step2: Verify Response Status Code is correctly and verify that Status code is 200 OK'
WS.verifyEqual(ResponseOutPut.getStatusCode(), 200)

'Step 3: Verify AddResult value is correctly and verify that AddResult is expectation'
WS.verifyElementText(ResponseOutPut, 'AddResponse.AddResult', (addActValue01 + addActValue02).toString())

